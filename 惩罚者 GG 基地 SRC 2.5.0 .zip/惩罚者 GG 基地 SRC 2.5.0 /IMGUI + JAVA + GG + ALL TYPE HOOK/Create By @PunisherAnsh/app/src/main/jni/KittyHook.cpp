//------------------------- ＣＲＥＡＴＥ ＢＹ @PunisherAnsh ------------------------------//

#include <jni.h>
#include <string>
#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <Include/Utils.h>
#include "KittyMemory/MemoryPatch.h"
#include "Include/Logger.h"
#include "Include/Utils.h"
#include "obfuscate.h"
#include "Substrate/SubstrateHook.h"
#include "Include/Macros.h"
 
using namespace std;
bool isBypaas = true;
bool bypass = true;
bool 
button1,button3,button4,button5,
button0 = false;

//------------------------- ＣＲＥＡＴＥ ＢＹ @PunisherAnsh ------------------------------//

int (*osub_E2172)(int a1, int a2, int a3);
int hsub_E2172(int a1, int a2, int a3)
{
    while(true)
    {
        return 0;
    }
    return osub_E2172(a1,a2,a3);
}


//----------- Hook Your Normal Values For This Method -------------------//

int (*osub_3FA5A4C)(int result, int a2);
int sub_3FA5A4C(int result, int a2)
{
    return 0;
}

//------------------------- ＣＲＥＡＴＥ ＢＹ @PunisherAnsh ------------------------------//

//--------- Add Your Hook Strings 👇 -----------//

int (*old_IsEnable)(int a1, char *a2, int a3);
int IsEnable(int a1, char *NameOfThread, int a3)
{
if (
strstr(NameOfThread, "blur_exit") ||
strstr(NameOfThread, "9003_cert_md5") ||
strstr(NameOfThread, "crash_various_opcode")          
   ){
        LOGI(OBFUSCATE("BLOCKED|%s"),NameOfThread);
        return 0;
    } else {
        LOGI(OBFUSCATE("ALLOWED|%s"),NameOfThread);
        return old_IsEnable(a1, NameOfThread, a3);
    }
}
//------------------------- ＣＲＥＡＴＥ ＢＹ @PunisherAnsh ------------------------------//

//-------------------------------------------------------------------------//

 void *kitty_thread(void *) {
    LOGI(OBFUSCATE("pthread created"));
    do {    
   sleep(1);
    } while (!isLibraryLoaded("libanort.so"));
//----------- Crash Fix -------------//
MSHookFunction((void*)getAbsoluteAddress("libanort.so", 0xE2173), (void*)hsub_E2172, (void**)&osub_E2172);//CrashFix
return NULL;
}


void *anogs_thread(void *) {
    LOGI(OBFUSCATE("pthread created"));
    do {    
   sleep(1);
    } while (!isLibraryLoaded("libanogs.so"));	
//----------- 👇 Normal Bypaas Patch Method 👇 -------------//
//--- Hint ---// PATCH_LIB("libanogs.so", "0x2945", "00 27 00 47");
//----------- 👇 HOOK Bypaas Patch Method 👇 -------------//
//--- Hint ---// MSHookFunction((void*)getAbsoluteAddress("libanogs.so", 0xAddYourOffset), (void*)IsEnable, (void**)&old_IsEnable);//Report Ban
return NULL;
  }


__attribute__((constructor))
void lib_main() {
    pthread_t ptid;
    pthread_create(&ptid, NULL, kitty_thread, NULL);
    pthread_create(&ptid, NULL, anogs_thread, NULL);
}

//------------------------- ＣＲＥＡＴＥ ＢＹ @PunisherAnsh ------------------------------//
