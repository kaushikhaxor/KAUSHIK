//------------------------- ＣＲＥＡＴＥ ＢＹ @PunisherAnsh ------------------------------//

package com.punisher.modz;

import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends Activity {
	static{   
	System.loadLibrary("PunisherModz");

    }
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        startup.Start(this);
    }
}

//------------------------- ＣＲＥＡＴＥ ＢＹ @PunisherAnsh ------------------------------//
