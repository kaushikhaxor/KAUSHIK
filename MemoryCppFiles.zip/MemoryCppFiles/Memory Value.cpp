#include "MemoryTools.h"
#include "obfuscate.h"
#include "Includes.h"
#include "Log.h"
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <string>
#include <string_view>
#include <sstream>
#include <memory>
#include <stdexcept>

static int handle = -1;
static int32_t pid = -1;
static std::string packages[] = {
    OBFUSCATE("com.tencent.ig"),
    OBFUSCATE("com.pubg.imobile"),
    OBFUSCATE("com.pubg.krmobile"),
    OBFUSCATE("com.vng.pubgmobile"),
    OBFUSCATE("com.rekoo.pubgm"),
    OBFUSCATE("com.blackhole.mrerror"),
};

std::string exec(std::string_view cmd) {
    std::unique_ptr<FILE, decltype(&pclose)> pipe(popen(cmd.data(), "r"), &pclose);
    if (!pipe) {
        throw std::runtime_error("Could not open pipe");
    }

    char buffer[1024] = { 0 };
    std::ostringstream stream;

    while (fgets(buffer, sizeof(buffer), pipe.get())) {
        stream << buffer;
    }

    return stream.str();
}

int32_t find_pid(std::string_view package_name) {
    char cmd[128] = { 0 };
    sprintf(cmd, "toybox pidof %s", package_name.data());

    std::string output = exec(cmd);

    if (isdigit(output[0])) {
        return std::stoi(output);
    }
    return 0;
}

uintptr_t find_base(std::string_view lib_name) {
    char filename[32] = { 0 };
    sprintf(filename, "/proc/%d/maps", pid);
    std::unique_ptr<FILE, decltype(&fclose)> file(fopen(filename, "r"), &fclose);

    if (file) {
        char line[1024] = { 0 };
        while (fgets(line, sizeof(line), file.get())) {
            if (strstr(line, lib_name.data())) {
                return std::stoul(line, nullptr, 16);
            }
        }
    }
    return 0;
}

template <typename T>
void write(uintptr_t addr, T value) {
    int error = pwrite64(handle, &value, sizeof(T), addr);
    if (error == -1) {
        throw std::runtime_error(std::strerror(errno));
    }
}



int main(int argc,char **argv)
{
  int gs;
  void *jg;
  char *bm;
  char* process_name = OBFUSCATE("com.tencent.ig");
  char* process_name1 = OBFUSCATE("com.pubg.imobile");
  char* process_name2 = OBFUSCATE("com.pubg.krmobile");
  char* process_name3 = OBFUSCATE("com.vng.pubgmobile");
  char* process_name4 = OBFUSCATE("com.rekoo.pubgm");
  char* process_name5 = OBFUSCATE("com.blackhole.mrerror");

    if (argc < 2) {
        throw std::runtime_error("argc < 2");
    }

    int val = std::stoi(argv[1]);

    for (const auto& name : packages) {
        pid = find_pid(name);
        if (pid > 1) {
         
     break;
        }
    }

    if (pid < 1) {
        throw std::runtime_error("Could not find pid");
    }

    uintptr_t base = find_base("libUE4.so");
    if (base < 1) {
        throw std::runtime_error("Could not find base");
    }

    char mem_path[32] = { 0 };
    sprintf(mem_path, "/proc/%d/mem", pid);

    handle = open(mem_path, O_RDWR);
    if (handle == -1) {
        throw std::runtime_error(std::strerror(errno));
    }
 
int	pid = getPID(process_name);
	bm = process_name;
	    if (pid == 0) {
        pid = getPID(process_name1);
        bm = process_name1;
			if (pid == 0) {
        pid = getPID(process_name2);
        bm = process_name2;
			   		if (pid == 0) {
			    		        pid = getPID(process_name3);
			    		        	bm = process_name3;
			    		        if (pid == 0) {
			    		               pid = getPID(process_name4);
			    		               	bm = process_name4;
			    		               	if (pid == 0) {
			    		                pid = getPID(process_name5);
			    		               	bm = process_name5;
			    		               	exit(0);
			    		               if (pid == 0) {
			    		               puts(OBFUSCATE("PUBGM IS NOT RUNNING "));
			    		               exit(0);
			    		               }
                  		}
                }
        }
    }
}

     switch (val)  {

     case 110:
     //LESS RECOIL ON
     write<float>(base + 0x142FCC8, 0.0f);
     write<float>(base + 0x3E2ABE0, 0.0f);
     break;
     case 220:
	 //LESS RECOIL OFF
     write<float>(base + 0x142FCC8, -2.78698203e28f);
     write<float>(base + 0x3E2ABE0, -1.11445016e28f);
     break;
     case 330:
     //SMALL CROSSHAIR ON
     write<float>(base + 0x143046C, 0.0f);
     break;
     case 440:
     //SMALL CROSSHAIR OFF
     write<float>(base + 0x143046C, -1.11445016e28f);
     break;
     case 550:
     //ANTISHAKE ON
     write<float>(base + 0x3EF5E10, 0.0f);
     break;
     case 660:
     //ANTISHAKE OFF
     write<float>(base + 0x3EF5E10, -1.11445016e28f);
     break;
     case 770:
     //BLACK BODY ON
     write<float>(base + 0x32BBFB4, 10.0f);
     break;
     case 880:
     //BLACK BODY OFF
     write<float>(base + 0x32BBFB4, 0.0001f);
     break;
     case 990:
     //NIGHT MODE ON
     write<float>(base + 0x34980B0, 0.0f);
     break;
     case 000:
     //NIGHT MODE OFF
     write<float>(base + 0x34980B0, -2.74149666e28f);
     break;          
     case 1110:
     //STATIC HIT X EFFECT ON
     write<float>(base + 0x1C595B4, 0.0f);
     write<float>(base + 0x1C5959C, 0.0f);
     break;
     case 2220:
     //STATIC HIT X EFFECT OFF
     write<float>(base + 0x1C595B4, -1.30013986e28f);
     write<float>(base + 0x1C5959C, -5.91535088e21f);
     break;          
     case 3330:
     //DESERT MAP ON
     write<float>(base + 0x3879E00, 0.0f);
     break;
     case 4440:
     //DESERT MAP OFF
     write<float>(base + 0x3879E00, -2.11566861e24f);
     break;
     case 5550:
     //FOG OFF
	 write<float>(base + 0x32311A4, -1.36204395e28f);//nofog
     write<float>(base + 0x32311A8, -1.39782048e24f);//purple
     write<float>(base + 0x32311B4, -1.39782048e24f);//green
     write<float>(base + 0x3231198, -1.39782048e24f);//cyan
     break;
     case 6660:
     //NOFOG
	 write<float>(base + 0x32311A8, -1.39782048e24f);//purple
     write<float>(base + 0x32311B4, -1.39782048e24f);//green
     write<float>(base + 0x3231198, -1.39782048e24f);//cyan
     write<float>(base + 0x32311A4, 0.0f);//nofog
     break;
     case 7770:
     //PURPLE FOG
	 write<float>(base + 0x32311A4, -1.36204395e28f);//nofog
     write<float>(base + 0x32311B4, -1.39782048e24f);//green
     write<float>(base + 0x3231198, -1.39782048e24f);//cyan
     write<float>(base + 0x32311A8, 0.0f);//purple
     break;
     case 8880:
     //GREEN FOG
	 write<float>(base + 0x32311A4, -1.36204395e28f);//nofog
     write<float>(base + 0x32311A8, -1.39782048e24f);//purple
     write<float>(base + 0x3231198, -1.39782048e24f);//cyan
     write<float>(base + 0x32311B4, 0.0f);//green
     break;
     case 9990:
     //BLUE FOG
	 write<float>(base + 0x32311A4, -1.36204395e28f);//nofog
     write<float>(base + 0x32311A8, 0.0f);//purple
     write<float>(base + 0x32311B4, -1.39782048e24f);//green
     write<float>(base + 0x3231198, 0.0f);//cyan
     break;
     case 10000:
     //RED FOG
	 write<float>(base + 0x32311A4, -1.36204395e28f);//nofog
     write<float>(base + 0x32311A8, 0.0f);//purple
     write<float>(base + 0x32311B4, 0.0f);//green
     write<float>(base + 0x3231198, -1.39782048e24f);//cyan
     break;
     case 999990:
     //CYAN FOG
	 write<float>(base + 0x32311A4, -1.36204395e28f);//nofog
     write<float>(base + 0x32311A8, -1.39782048e24f);//purple
     write<float>(base + 0x3231198, 0.0f);//cyan
     write<float>(base + 0x32311B4, -1.39782048e24f);//green
     break;
     case 11110:
     //BLACKSKY ON
     write<float>(base + 0x41BDC10, -0.00001000024f);
     break;
     case 22220:
     //BLACKSKY OFF
     write<float>(base + 0x41BDC10, 0.0f);
     break;
     case 33330:
     //NO GRASS ON
     write<float>(base + 0x2A03B88, 0.0f);
     break;
     case 44440:
     //NO GRASS OFF
     write<float>(base + 0x2A03B88, -3.892263e21f);
     break;
     case 55550:
     //WIDE VIEW ON 1
     write<float>(base + 0x3EF90E4, 300.0f);
     break;
     case 66660:
     //WIDE VIEW ON 2
     write<float>(base + 0x3EF90E4, 280.0f);
     break;
     case 77770:
     //WIDE VIEW ON 3
     write<float>(base + 0x3EF90E4, 240.0f);
     break;
     case 88880:
     //WIDE VIEW ON 4
     write<float>(base + 0x3EF90E4, 200.0f);
     break;
     case 99990:
     //WIDE VIEW ON 5
     write<float>(base + 0x3EF90E4, 180.0f);
     break;
     case 100000:
     //WIDE VIEW OFF
     write<float>(base + 0x3EF90E4, 360.0f);
     break;
     case 111110:
     //CAR SPEED ON
     write<float>(base + 0x4DDBBDC, 0.0f);
     break;
     case 222220:
     //CAR SPEED OFF
     write<float>(base + 0x4DDBBDC, -1.41959378e28f);
     break;
     case 333330:
     //AIMBOT 100M ON
     write<float>(base + 0x2A399E0, 99998.0f);
     write<float>(base + 0x2A398AC, 0.0f);
     break;
     case 444440:
     //AIMBOT 100M OFF
     write<float>(base + 0x2A399E0, 0.0001f);
     write<float>(base + 0x2A398AC, 2015175168.0f);
     break;
     case 555550:
     //AIMBOT 360M ON
     write<float>(base + 0xFD7B20, -5.9029581e21f);
     write<float>(base + 0xFD8020, -5.9029581e21f);
     write<float>(base + 0x11D290, 1.6615351e35f);
     write<float>(base + 0xC71CB0, 1.6615351e35f);
     write<float>(base + 0xFD4004, 1.6615351e35f);
     write<float>(base + 0xFD4230, 1.6615351e35f);
     write<float>(base + 0xFD78B8, 1.6615351e35f);
     write<float>(base + 0xFDA874, 1.6615351e35f);
     write<float>(base + 0xFDBED8, 1.6615351e35f);
     write<float>(base + 0xFDCEF0, 1.6615351e35f);
     write<float>(base + 0xFDCF38, 1.6615351e35f);
     write<float>(base + 0xFDD4CC, 1.6615351e35f);
     write<float>(base + 0xFDD514, 1.6615351e35f);
     write<float>(base + 0xFDD5A4, 1.6615351e35f);
     break;
     case 666660:
     //AIMBOT 360M OFF
     write<float>(base + 0xFD7B20, -2.95220033e20f);
     write<float>(base + 0xFD8020, -2.95220033e20f);
     write<float>(base + 0x11D290, 1.6615354e35f);
     write<float>(base + 0xC71CB0, 1.6615354e35f);
     write<float>(base + 0xFD4004, 1.6615354e35f);
     write<float>(base + 0xFD4230, 1.6615354e35f);
     write<float>(base + 0xFD78B8, 1.6615354e35f);
     write<float>(base + 0xFDA874, 1.6615354e35f);
     write<float>(base + 0xFDBED8, 1.6615354e35f);
     write<float>(base + 0xFDCEF0, 1.6615354e35f);
     write<float>(base + 0xFDCF38, 1.6615354e35f);
     write<float>(base + 0xFDD4CC, 1.6615354e35f);
     write<float>(base + 0xFDD514, 1.6615354e35f);
     write<float>(base + 0xFDD5A4, 1.6615354e35f);
     break;
     case 777770:
     //FIXSTUK ON
	 write<float>(base + 0x139C704, 0.0f);
     write<float>(base + 0x139C708, 0.0f);
     break;
     case 888880:
     //FIX STUK OFF
	 write<float>(base + 0x139C704, -6.15262313e27f); 
     write<float>(base + 0x139C708, -9.98393277e27f); 
     break;
     case 970:
     //SLOW-MOTION ON
	 write<float>(base + 0x3F240D8, 0.0f);
     break;
	 case 960:
     //SLOW MOTION OFF
	 write<float>(base + 0x3F240D8, -5.84305429e27f);
     break;
     case 950:
     //STABLE MAN ON
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("4000"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("0.30000001192"),4,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("5"),16,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("0"),-4,FLOAT);
     ClearResults();
     break;
     case 940:
     ///STABLE MAN OFF
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("4000"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("0.30000001192"),4,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("5"),16,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("-980"),-4,FLOAT);
     ClearResults();
     break;
     case 930:
     //INSTANT HIT ON
     ClearResults();
     SetSearchRange(CODE_APP);
     MemorySearch(bm,OBFUSCATE("-1.42781105e28"),&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("0"),0,FLOAT);
     ClearResults();
     SetSearchRange(CODE_APP);
     MemorySearch(bm,OBFUSCATE("0.9986295104"),&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("1224995"),0,FLOAT);
     ClearResults();
     break;
     case 920:
     //INSTANT HIT OFF
     ClearResults();
     SetSearchRange(CODE_APP);
     MemorySearch(bm,OBFUSCATE("0.9986295104"),&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("1224995"),0,FLOAT);
     ClearResults();
     break;
     case 910:
     // NO TREE ON
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("0.000005"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("0.000005"),-4,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("1"),0,FLOAT);
     ClearResults();
     break;
	 case 900:
     // NO TREE OFF
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("1"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("0.000005"),-4,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("0.000005"),0,FLOAT);
     ClearResults();
     break;
	 case 890:
     //MAGIC BULLET
     ClearResults();
     SetSearchRange(CODE_APP);
     MemorySearch(bm,OBFUSCATE("0.10000000149"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("64.50088500977"),188,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("40"),0,FLOAT);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("23.0"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("25.0"),4,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("30.5"),8,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("-400"),0,FLOAT);
     MemoryWrite(bm,OBFUSCATE("400"),4,FLOAT);
     MemoryWrite(bm,OBFUSCATE("400"),8,FLOAT);
     ClearResults();
     break;
     case 1880:
     //MAGIC OFF
     ClearResults();
     SetSearchRange(CODE_APP);
     MemorySearch(bm,OBFUSCATE("40"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("64.50088500977"),188,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("0.10000000149"),0,FLOAT);
     ClearResults();
     break;
     
 	 case 870:
     //SKY JUMP ON
     ClearResults();
	 SetSearchRange(CODE_APP);
     MemorySearch(bm,OBFUSCATE("-481296383"),&gs,DWORD);
     MemoryOffset(bm,OBFUSCATE("93978660"),4,&gs,DWORD);
     MemoryOffset(bm,OBFUSCATE("55574528"),8,&gs,DWORD);
     MemoryWrite(bm,OBFUSCATE("-481296384"),0,DWORD);
     ClearResults();    
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("1"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("55"),16,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("0.57357645035"),20,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("-9"),0,FLOAT);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("1028443341"),&gs,DWORD);
     MemoryOffset(bm,OBFUSCATE("1133903872"),-8,&gs,DWORD);
     MemoryOffset(bm,OBFUSCATE("1103626240"),8,&gs,DWORD);
     MemoryOffset(bm,OBFUSCATE("1109393408"),16,&gs,DWORD);
     MemoryWrite(bm,OBFUSCATE("1074287084"),0,DWORD);
     ClearResults();
     
     break;
	 case 860:
     // SKYJUMP OFF
     ClearResults();
	 SetSearchRange(CODE_APP);
     MemorySearch(bm,OBFUSCATE("-481296384"),&gs,DWORD);
     MemoryOffset(bm,OBFUSCATE("93978660"),4,&gs,DWORD);
     MemoryOffset(bm,OBFUSCATE("55574528"),8,&gs,DWORD);
     MemoryWrite(bm,OBFUSCATE("-481296383"),0,DWORD);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("-9"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("55"),16,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("0.57357645035"),20,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("1"),0,FLOAT);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("1074287084"),&gs,DWORD);
     MemoryOffset(bm,OBFUSCATE("1133903872"),-8,&gs,DWORD);
     MemoryOffset(bm,OBFUSCATE("1103626240"),8,&gs,DWORD);
     MemoryOffset(bm,OBFUSCATE("1109393408"),16,&gs,DWORD);
     MemoryWrite(bm,OBFUSCATE("1028443341"),0,DWORD);
     ClearResults();
     break;
	 case 850:
     // HEADSHOT
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("23.0"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("25.0"),4,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("30.5"),8,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("-430"),0,FLOAT);
     MemoryWrite(bm,OBFUSCATE("430"),4,FLOAT);
     MemoryWrite(bm,OBFUSCATE("430"),8,FLOAT);
     ClearResults();
     SetSearchRange(CODE_APP);
     MemorySearch(bm,OBFUSCATE("-298284466"),&gs,DWORD);
     MemoryWrite(bm,OBFUSCATE("0"),0,DWORD);
     ClearResults();
     SetSearchRange(CODE_APP);
     MemorySearch(bm,OBFUSCATE("0.9986295104"),&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("1224995"),0,FLOAT);
     SetSearchRange(CODE_APP);
     MemorySearch(bm,OBFUSCATE("0.0001"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("360.0"),-464,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("1478828160.0"),-360,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("250"),0,FLOAT);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("26"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("-88.66608428955"),-8,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("-460"),0,FLOAT);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("28"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("-88.73961639404"),-8,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("-560"),0,FLOAT);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("27.25"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("90.4850692749"),-12,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("-660"),0,FLOAT);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("18"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("90.4850692749"),-8,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("-660"),0,FLOAT);
     ClearResults();
     SetSearchRange(CODE_APP);
     MemorySearch(bm,OBFUSCATE("0.10000000149"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("64.50088500977"),188,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("8"),0,FLOAT);
     ClearResults();
     break;
     case 840:
     //HEADSHOT
     ClearResults();
     SetSearchRange(CODE_APP);
     MemorySearch(bm,OBFUSCATE("0.0001"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("360.0"),-464,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("1478828160.0"),-360,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("250"),0,FLOAT);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("26"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("-88.66608428955"),-8,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("-460"),0,FLOAT);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("28"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("-88.73961639404"),-8,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("-560"),0,FLOAT);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("27.25"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("90.4850692749"),-12,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("-660"),0,FLOAT);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("18"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("90.4850692749"),-8,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("-660"),0,FLOAT);
     ClearResults();
     SetSearchRange(CODE_APP);
     MemorySearch(bm,OBFUSCATE("0.10000000149"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("64.50088500977"),188,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("8"),0,FLOAT);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("25.0"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("23.0"),-4,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("9.20161819458"),-28,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("700"),0,FLOAT);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("30.5"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("9.20161819458"),-32,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("700"),0,FLOAT);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("25"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("9.20161819458"),-28,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("250"),0,FLOAT);
     ClearResults();
     SetSearchRange(B_BAD);
     MemorySearch(bm,OBFUSCATE("26"),&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("-460"),0,FLOAT);
     ClearResults();
     SetSearchRange(B_BAD);
     MemorySearch(bm,OBFUSCATE("28"),&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("-560"),0,FLOAT);
     ClearResults();
     SetSearchRange(CODE_APP);
     MemorySearch(bm,OBFUSCATE("-298284466"),&gs,DWORD);
     MemoryWrite(bm,OBFUSCATE("0"),0,DWORD);
     ClearResults();
     break;
	 case 830:
     //SIT FLY ON
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("2500000000"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("3600000000"),-8,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("50"),48,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("-74"),44,FLOAT);
     ClearResults();
     break;
	 case 820:
     // SIT FLY OFF
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("2500000000"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("3600000000"),-8,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("50"),48,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("60"),44,FLOAT);
     ClearResults();
     break;
     case 810:
     //FLASH V1
	 write<float>(base + 0x4598B5C, 23.0f);
     write<float>(base + 0x3F47534, 0.28f);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("750"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("100"),-4,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("20"),60,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("0.40000000596"),68,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("0.08"),64,FLOAT);
     ClearResults();
     break;
     case 800:
     //FLASH V1 OFF
     write<float>(base + 0x4598B5C, 25.72529029846f);
     write<float>(base + 0x3F47534, 9.99999997e-7f);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("750"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("100"),-4,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("20"),60,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("0.40000000596"),68,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("0.00050000002"),64,FLOAT);
     ClearResults();
     break;
     case 790:
     //FLASH V2 ON
     write<float>(base + 0x4598B5C, 23.0f);
     write<float>(base + 0x3F47534, 0.28f);
     write<float>(base + 0x3F240D8, 0.0f);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("750"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("100"),-4,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("20"),60,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("0.40000000596"),68,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("0.12"),64,FLOAT);
     ClearResults();
     break;
     case 780:
     //FLASH V2 OFF
     write<float>(base + 0x4598B5C, 25.72529029846f);
     write<float>(base + 0x3F47534, 9.99999997e-7f);
     write<float>(base + 0x3F240D8, -5.84305429e27f);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("750"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("100"),-4,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("20"),60,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("0.40000000596"),68,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("0.00050000002"),64,FLOAT);
     ClearResults();
     break;
	 case 1770:
	 write<float>(base + 0x3F47534, 0.27500000596f);
     write<float>(base + 0x3F240D8, 0.0f);
     write<float>(base + 0x4598B5C, 23.0f);
     ClearResults(); //FLASH V3 ON
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("0.0001"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("20"),4,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("0.40000000596"),12,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("0.10"),8,FLOAT);
     ClearResults();
     break;
	 case 760:  
     //FLASH V3 OFF
     write<float>(base + 0x4598B5C, 25.72529029846f);
	 write<float>(base + 0x3F240D8, -5.84305429e27f);
     write<float>(base + 0x3F47534, 9.99999997e-7f);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);	// 
     MemorySearch(bm,OBFUSCATE("0.0001"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("20"),4,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("0.40000000596"),12,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("0.00050000002"),8,FLOAT);
     ClearResults();
     break;
	 case 750:    
     //FLASH V4 ON
	 write<float>(base + 0x3F240D8, 0.0f);
     write<float>(base + 0x3F5505C, 0.0f);
     write<float>(base + 0x4598B5C, 23.0f);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("0.0001"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("20"),4,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("0.40000000596"),12,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("0.1099999994"),8,FLOAT);
     ClearResults();
     break;
	 case 740:
     //FLASH V4 OFF
	 write<float>(base + 0x3F240D8, -5.84305429e27f);
     write<float>(base + 0x3F5505C, -1.86389771e-20f);  
     write<float>(base + 0x4598B5C, 25.72529029846f);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("0.0001"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("20"),4,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("0.40000000596"),12,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("0.00050000002"),8,FLOAT);
     ClearResults();
     break;
	 case 730:
     //FLASH V5 ON
	 write<float>(base + 0x3F5505C, 0.0f);
     break;
	 case 720:
     //FLASH V5 OFF
	 write<float>(base + 0x3F5505C, -1.86389771e-20f);
     break;
	 case 710:
     //FLASH V6 ON
	 ClearResults();
     SetSearchRange(CODE_APP);
     MemorySearch(bm,OBFUSCATE("-1.05303672e28"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("-5.84545857e27"),4,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("0"),12,FLOAT);
     MemoryWrite(bm,OBFUSCATE("0"),16,FLOAT);
     MemoryWrite(bm,OBFUSCATE("0"),308,FLOAT);
     ClearResults();
     break;
	 case 700:
     //FLASH V6 OFF
     ClearResults();
     SetSearchRange(CODE_APP);	// 
     MemorySearch(bm,OBFUSCATE("-1.05303672e28"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("-5.84545857e27"),4,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("-2.78601512e28"),12,FLOAT);
     MemoryWrite(bm,OBFUSCATE("-3.74440972e28"),16,FLOAT);
     MemoryWrite(bm,OBFUSCATE("-2.79375201e28"),308,FLOAT);
     ClearResults();
     break;
     case 690:
     write<float>(base + 0x3F47534, 0.27500000596f);
     write<float>(base + 0x4598B5C, 23.0f);
     ClearResults();  // FLASH LOW ON
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("0.0001"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("20"),4,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("0.40000000596"),12,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("0.05000000075"),8,FLOAT);
     ClearResults();
     break;
	 case 680:
	 write<float>(base + 0x3F47534, 9.99999997e-7f);
	 write<float>(base + 0x4598B5C, 25.72529029846f);
     ClearResults();// FLASH lOW OFF
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("0.0001"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("20"),4,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("0.40000000596"),12,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("0.00050000002"),8,FLOAT);
     ClearResults();
     break;
	 case 670:
     //SPEED PRONE KNOCK ON
	 write<float>(base + 0x12136E8, -2.73959308e28f);
     break;
	 case 1660:
     //SPEED PRONE KNOCK OFF
	 write<float>(base + 0x12136E8, -2.73959284e28f);
     break;
	 case 650:
     //FAST PARACHUTE V1 ON
	 write<float>(base + 0x3F240D8, 0.0f);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("0.00050000002"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("20"),-4,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("0.40000000596"),4,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("0.07999999821"),0,FLOAT);
     ClearResults();
     break;
	 case 640:
     //FAST PARACHUTE V1 OFF
	 write<float>(base + 0x3F240D8, -5.84305429e27f);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("0.07999999821"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("20"),-4,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("0.40000000596"),4,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("0.00050000002"),0,FLOAT);
     ClearResults();
     break;
     case 630:
     //FAST PARACHUTE V2 ON
	 write<float>(base + 0x3F240D8, 0.0f);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("0.00050000002"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("20"),-4,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("0.40000000596"),4,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("0.09000000358"),0,FLOAT);
     ClearResults();
     break;
     case 620:
     //FAST PARACHUTE V2 OFF
	 write<float>(base + 0x3F240D8, -5.84305429e27f);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("0.09000000358"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("20"),-4,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("0.40000000596"),4,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("0.00050000002"),0,FLOAT);
     ClearResults();
     break;
	 case 610:
     // FAST SCOPE ON
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("6.16031837463"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("1"),16,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("-12"),12,FLOAT);
     ClearResults();
     break;
	 case 600:
     // FAST SCOPE OFF
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("6.16031837463"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("1"),16,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("0.37999999523"),12,FLOAT);
     ClearResults();
     break;
     case 590:
     //STAND FRONT SCOPE ON
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("1224979106148981430"),&gs,QWORD);
     MemoryOffset(bm,OBFUSCATE("4138667321167981973"),28,&gs,QWORD);
     MemoryOffset(bm,OBFUSCATE("4307569899241177088"),32,&gs,QWORD);
     MemoryWrite(bm,OBFUSCATE("4848124999984742400"),28,QWORD);
     MemoryWrite(bm,OBFUSCATE("4307569899406360576"),32,QWORD);
     ClearResults();
     break;
     case 580:
     //STAND FRONT SCOPE OFF
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("1224979106148981430"),&gs,QWORD);
     MemoryOffset(bm,OBFUSCATE("4848124999984742400"),28,&gs,QWORD);
     MemoryOffset(bm,OBFUSCATE("4307569899406360576"),32,&gs,QWORD);
     MemoryWrite(bm,OBFUSCATE("4138667321167981973"),28,QWORD);
     MemoryWrite(bm,OBFUSCATE("4307569899241177088"),32,QWORD);
     ClearResults();
     break;
     case 570:
     //SIT SCOPE ON
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("18.38787841797"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("0.53867292404"),4,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("-3.42232513428"),8,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("1.77635705e-15"),12,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("130.5419921875"),0,FLOAT);
     ClearResults();
     break;
     case 560:
     //SIT SCOPE OFF
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("130.5419921875"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("0.53867292404"),4,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("-3.42232513428"),8,&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("1.77635705e-15"),12,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("18.38787841797"),0,FLOAT);
     ClearResults();
     break;
     case 1550:
     //PRONE SCOPE ON
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("4542111809939904211"),&gs,QWORD);
     MemoryOffset(bm,OBFUSCATE("-4585985877963386208"),4,&gs,QWORD);
     MemoryOffset(bm,OBFUSCATE("2810246175001366052"),8,&gs,QWORD);
     MemoryWrite(bm,OBFUSCATE("4542111809971159040"),0,QWORD);
     ClearResults();
     break;
     case 540:
     //PRONE SCOPE OFF
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("4542111809971159040"),&gs,QWORD);
     MemoryOffset(bm,OBFUSCATE("-4585985877963386208"),4,&gs,QWORD);
     MemoryOffset(bm,OBFUSCATE("2810246175001366052"),8,&gs,QWORD);
     MemoryWrite(bm,OBFUSCATE("4542111809939904211"),0,QWORD);
     ClearResults();
     break;
     case 530:
     //HIT X EFFECT ON
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("46"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("10"),-4,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("9999"),-4,FLOAT);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("45"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("10"),-4,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("9999"),-4,FLOAT);
     ClearResults();
     break;
     case 520:
     //HIT X EFFECT OFF
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("9999"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("46"),4,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("10"),0,FLOAT);
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("9999"),&gs,FLOAT);
     MemoryOffset(bm,OBFUSCATE("45"),4,&gs,FLOAT);
     MemoryWrite(bm,OBFUSCATE("10"),0,FLOAT);
     ClearResults();
     break;
     case 510:
     //CAR JUMP ON
     ClearResults();
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("5006313939071729664"),&gs,QWORD);
     MemoryWrite(bm,OBFUSCATE("5006313936970041344"),0,QWORD);
     ClearResults();
     sleep(9);
     SetSearchRange(A_ANONMYOUS);
     MemorySearch(bm,OBFUSCATE("5006313936970041344"),&gs,QWORD);
     MemoryWrite(bm,OBFUSCATE("5006313939071729664"),0,QWORD);
     ClearResults();
     break;
     case 500:
     //RAINBOW HIT X EFFECT ON
     system(OBFUSCATE("rm -rf /sdcard/offeffect"));
     while (true) 
     {
     int pid = getPID(bm);
     write<float>(base + 0x1C595A4, 0.0f);
     write<float>(base + 0x1C595B8, 0.0f);
     sleep(1);
     write<float>(base + 0x1C595A4, -8.32319975e22f);
     sleep(0.5);
     write<float>(base + 0x1C595B8, -8.34901799e22f);
     write<float>(base + 0x1C595A4, 0.0f);
     sleep(1);
     write<float>(base + 0x1C595A4, -8.32319975e22f);
     write<float>(base + 0x1C595B8, 0.0f);
     write<float>(base + 0x1C595B0, 0.0f);
     sleep(1);
     write<float>(base + 0x1C595B8, -8.34901799e22f);
     write<float>(base + 0x1C595B0, -8.34533224e22f);
     sleep(0.5);
     write<float>(base + 0x1C595B0, 0.0f);
     sleep(1);
     write<float>(base + 0x1C595B0, -8.34533224e22f);
     write<float>(base + 0x1C595B8, 0.0f);
     sleep(1);
     write<float>(base + 0x1C595B8, -8.34533224e22f);
     write<float>(base + 0x1C595A4, 0.0f);
     write<float>(base + 0x1C595B0, 0.0f);
     sleep(1);
     write<float>(base + 0x1C595A4, -8.32319975e22f);
     write<float>(base + 0x1C595B0, -8.34533224e22f);
     FILE *file;
     if (file = fopen(OBFUSCATE("/sdcard/offeffect"), "r"))
     {
     fclose(file);
     system(OBFUSCATE("rm -rf /sdcard/offeffect"));
     break;
     }
     if (pid == 0) {
     break;
     exit(0);
     }
     }
     break;
     case 490:
     system(OBFUSCATE("touch /sdcard/offeffect"));
     sleep(8);
     write<float>(base + 0x1C595A4, -8.32319975e22f);
     write<float>(base + 0x1C595B8, -8.34901799e22f);
     write<float>(base + 0x1C595B0, -8.34533224e22f);
     break;
     case 480:
     //RAINBOW FOG ON
     system(OBFUSCATE("rm -rf /sdcard/offfog"));
     while (true) 
     {
     int pid = getPID(bm);
     write<float>(base + 0x32311A4, -1.36204395e28f);
     write<float>(base + 0x32311B4, -1.39782048e24f);
     write<float>(base + 0x3231198, -1.39782048e24f);
     write<float>(base + 0x32311A8, 0.0f);
     sleep(1);
     write<float>(base + 0x32311A4, -1.36204395e28f);
     write<float>(base + 0x32311A8, -1.39782048e24f);
     write<float>(base + 0x3231198, -1.39782048e24f);
     write<float>(base + 0x32311B4, 0.0f);
     sleep(1);
     write<float>(base + 0x32311A4, -1.36204395e28f);
     write<float>(base + 0x32311A8, 0.0f);
     write<float>(base + 0x32311B4, -1.39782048e24f);
     write<float>(base + 0x3231198, 0.0f);
     sleep(1);
     write<float>(base + 0x32311A4, -1.36204395e28f);
     write<float>(base + 0x32311A8, 0.0f);
     write<float>(base + 0x32311B4, 0.0f);
     write<float>(base + 0x3231198, -1.39782048e24f);
     sleep(1);
     write<float>(base + 0x32311A4, -1.36204395e28f);
     write<float>(base + 0x32311A8, -1.39782048e24f);
     write<float>(base + 0x3231198, 0.0f);
     write<float>(base + 0x32311B4, -1.39782048e24f);
     FILE *file2;
     if (file2 = fopen(OBFUSCATE("/sdcard/offfog"), "r"))
     {
     fclose(file2);
     system(OBFUSCATE("rm -rf /sdcard/offfog"));
     break;
     }
     if (pid == 0) {
     break;
     exit(0);
     }
     }
     break;
     case 470:
     system(OBFUSCATE("touch /sdcard/offfog"));
     write<float>(base + 0x32311A4, -1.36204395e28f);
     write<float>(base + 0x32311A8, -1.39782048e24f);
     write<float>(base + 0x32311B4, -1.39782048e24f);
     write<float>(base + 0x3231198, -1.39782048e24f);
     break;
     
    }
    
    if (close(handle) == -1) {
    throw std::runtime_error(std::strerror(errno));
    }
}