package com.Tg.Mrkaushikhaxor.data

data class database(
  var serverstatus :String,
  var noticemode : String,
  var dataclearmode : String,
  var servermeassage: String,
  var opentime: String,
  var libs: String,
  var notice_title: String,
  var notice_body: String
)
