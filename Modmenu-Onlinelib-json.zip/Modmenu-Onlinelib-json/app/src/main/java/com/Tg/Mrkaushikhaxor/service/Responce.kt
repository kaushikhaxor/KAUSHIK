package com.Tg.Mrkaushikhaxor.service

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.util.Log
import android.widget.Toast
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.Tg.Mrkaushikhaxor.data.database
import com.Tg.Mrkaushikhaxor.download.Downloader
import com.Tg.Mrkaushikhaxor.enc.KaushikEnc
import com.Tg.Mrkaushikhaxor.util.KaushikUntil
import org.json.JSONException
import java.util.Locale


class Responce : Service(){



    override fun onCreate() {
        super.onCreate()
        Databse(this)
    }


    fun Databse (context: Context )
    {
        val kaushikEnc = KaushikEnc()
        val status = kaushikEnc.decryptString("qxQ5smJt+2BMkMBxX6PR4Q==","o7MI0du63dHq4uotpxRk7A==")
        val notice = kaushikEnc.decryptString("Jcebe/+HCVemTV45lpmv/w==","dbhZG/590pEhDHngs97SpA==")
        val clearmode = kaushikEnc.decryptString("SQXGilUukhON/cc8aAsy8Q==","w1KUoqfXP0ozRPB9HfAStA==")
        val meassage = kaushikEnc.decryptString("CVH9zAoA9k/P7nzg1gNIqQ==","uE4lq49KHZV4gexVTyAC1w==")
        val time = kaushikEnc.decryptString("vmdCVAcDIIUkd6rca63L9g==","PtiNFNLSW2zoaqza3UG05Q==")
        val libs = kaushikEnc.decryptString("tpsTf7qiq9PQbnLds99b6A==","qiJD+NRLjgR5QOF21wUNdw==")
        val title = kaushikEnc.decryptString("j9UJJDqfiboPnY4WIksgtQ==","IFkwon1JRBgbaqiIKB+ZYQ==")
        val body = kaushikEnc.decryptString("jfSxNbrBf+nro8CFkYavDg==","fCSgCp5SBR6ayuMsYAYCDQ==")
        
        
        val jsondata = kaushikEnc.decryptString("FSTSTb9CNhep3kQjBTYOlq96HMn9wRvDfwidhiSqnZMhRPpeKQQZ7bfV5M9GXaq+mESOgrwoUp70EGIm7E+1g00TXx2aRE+P/IyN1Fz/3yo=","MpLnqNy5aYrggXtRJI8kGw==")

        /*val jsondata = "https://raw.githubusercontent.com/kaushik5402/lib_online/main/bot9tion-testing"*/
        val requestQueue = Volley.newRequestQueue(context)
        val jsonObjectRequest= JsonObjectRequest(
            com.android.volley.Request.Method.GET, jsondata, null,
            { response ->
                try {
                    val database = database(
                        response.getString(status),
                        response.getString(notice),
                        response.getString(clearmode),
                        response.getString(meassage),
                        response.getString(time),
                        response.getString(libs),
                        response.getString(title),
                        response.getString(body)
                    )
                    showdialog(database,this)
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            },
            {
                Toast.makeText(context,"Something Wrong Internet Error",Toast.LENGTH_LONG).show()
            }
        )
        requestQueue.add(jsonObjectRequest)
    }

    fun showdialog (database: database , context: Context )
    {
        val noticemode = database.noticemode.toBoolean()
        val serverstatus = database.serverstatus.toBoolean()
        val dataclear = database.dataclearmode.toBoolean()
        val libmode = database.libs
        if (noticemode)
        {
           Toast.makeText(
               context,
               database.notice_title+database.notice_body,
               Toast.LENGTH_LONG)
               .show()
        }
           if(!serverstatus)
           {
               Toast.makeText(
                   context,
                   database.servermeassage + database.opentime,
                   Toast.LENGTH_LONG
               ).show()
               Thread.sleep(6000)
               System.exit(1)
           } else {
                   val Downloader = Downloader(this,libmode,"BhylRv1KNpCqt/UFibYX8ddsR6kbexz7LErJiX5B/Ls=","Zni9j0g4+V5YofRfECRdpw==")
                   Downloader.execute()
           }

            if (dataclear)
            {
                KaushikUntil.clearlogs(this)
            }
    }

    fun downloadagain (link:String)
    {
      
        Toast.makeText(this,"download failed dowloading again ...",Toast.LENGTH_LONG ).show()
        Databse(this)
    }
    @SuppressLint("UnsafeDynamicallyLoadedCode")
    fun loadlib() {
        val files = this.cacheDir.listFiles()
        try {
            if (files != null) {
                for (file in files) {
                    val filename = file.name.lowercase(Locale.getDefault())
                    if (filename.endsWith(".so")) {
                       System.load(file.toString())
                    }
                }
            }
            if (files != null) {
                for (file in files) {
                    val filename = file.name.lowercase(Locale.getDefault())
                    if (filename.endsWith(".zip") || filename.endsWith(".so")) {
                        file.delete()
                    }
                }
            }
            Toast.makeText(this, "LIB Load Done Open Game ", Toast.LENGTH_LONG).show()
            Toast.makeText(this, "LIB Load Done Open Game ", Toast.LENGTH_LONG).show()
        } catch (err: Exception) {
            if (files != null) {
                for (file in files) {
                    val filename = file.name.lowercase(Locale.getDefault())
                    if (filename.endsWith(".zip") || filename.endsWith(".so")) {
                        file.delete()
                    }
                }
            }
            err.printStackTrace()
        }
    }
    override fun onBind(intent: Intent?): IBinder? {
        return null
    }



}
