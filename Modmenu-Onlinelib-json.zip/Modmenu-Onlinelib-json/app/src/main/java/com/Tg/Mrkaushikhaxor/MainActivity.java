package com.Tg.Mrkaushikhaxor;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.Tg.Mrkaushikhaxor.initialise.initmanager;

public class MainActivity extends AppCompatActivity

{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initmanager.Startservice(this);
    }
    

}
