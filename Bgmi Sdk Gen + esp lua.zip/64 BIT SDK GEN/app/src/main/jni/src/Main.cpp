#include "Main.h"
#include <fstream>
#include <unordered_set>
#include <unordered_map>
#include <chrono>
#include "../utils.h"
#include "cpplinq.hpp"
#include "Logger.hpp"
#include "log.h"
#include "IGenerator.hpp"
#include "ObjectsStore.hpp"
#include "NamesStore.hpp"
#include "Package.hpp"
#include "NameValidator.hpp"
#include "PrintHelper.hpp"
#include "json.hpp"
bool hpp = true;
bool ijson = true;    

extern IGenerator* generator;

/// <summary>
/// Dumps the objects and names to files.
/// </summary>
/// <param name="path">The path where to create the dumps.</param>
void Dump(std::string path)
{
	{
		std::ofstream o(path + "/" + "Kaushik_NamesDump.txt");
		tfm::format(o, "Address: %P\n\n", NamesStore::GetAddress());
		for (auto name : NamesStore())
		{
			tfm::format(o, "[%06i] %s\n", name.Index, name.NamePrivate);
		}
	}

	{
		std::ofstream o(path + "/" + "Kaushik_ObjectsDump.txt");
		tfm::format(o, "Address: %P\n\n", ObjectsStore::GetAddress());
		for (auto obj : ObjectsStore())
		{

			tfm::format(o, "[%06i] %-100s 0x%P\n", obj.GetIndex(), obj.GetFullName(), obj.GetAddress());
		}
	}
}




/// <summary>
/// Generates the sdk header.
/// </summary>
/// <param name="path">The path where to create the sdk header.</param>
/// <param name="processedObjects">The list of processed objects.</param>
/// <param name="packageOrder">The package order info.</param>

void SaveSDKHeader(std::string path, const std::unordered_map<UEObject, bool>& processedObjects, const std::vector<std::unique_ptr<Package>>& packages)
{
	std::ofstream os(path + "/" +  "SDK.hpp");

    os << "#pragma once\n\n"
<< tfm::format("// %s (%s) TELEGRAM Kaushik:-@Kaushik  \n// GENERATE ON %s \n", generator->GetGameName(), generator->GetGameVersion(), generator->CurrTime());

	//Includes
	os << "#include <set>\n";
	os << "#include <string>\n";
	for (auto&& i : generator->GetIncludes())
	{
		os << "#include " << i << "\n";
	}

	{
		{
			std::ofstream os2(path + "/SDK" + "/" + tfm::format("%s_Basic.hpp", generator->GetGameNameShort()));
			std::vector<std::string> incs = {
					"<iostream>",
					"<string>",
					"<unordered_set>",
					"<codecvt>"
			};
			PrintFileHeader(os2, incs, true);

			os2 << generator->GetBasicDeclarations() << "\n";

			PrintFileFooter(os2);

			os << "\n#include \"SDK/" << tfm::format("%s_Basic.hpp", generator->GetGameNameShort()) << "\"\n";
		}
		{
			std::ofstream os2(path + "/SDK" +  "/" +  tfm::format("%s_Basic.cpp", generator->GetGameNameShort()));

			PrintFileHeader(os2, { "\"../SDK.hpp\"" }, false);

			os2 << generator->GetBasicDefinitions() << "\n";

			PrintFileFooter(os2);
		}
	}

	using namespace cpplinq;

	//check for missing structs
	const auto missing = from(processedObjects) >> where([](auto&& kv) { return kv.second == false; });
	if (missing >> any())
	{
		std::ofstream os2(path + "/SDK" + "/" + tfm::format("%s_MISSING.hpp", generator->GetGameNameShort()));

		PrintFileHeader(os2, true);

		for (auto&& s : missing >> select([](auto&& kv) { return kv.first.template Cast<UEStruct>(); }) >> experimental::container())
		{
			os2 << "// " << s.GetFullName() << "\n// ";
			os2 << tfm::format("0x%04X\n", s.GetPropertySize());

			os2 << "struct " << MakeValidName(s.GetNameCPP()) << "\n{\n";
			os2 << "\tunsigned char UnknownData[0x" << tfm::format("%X", s.GetPropertySize()) << "];\n};\n\n";
		}

		PrintFileFooter(os2);

		os << "\n#include \"SDK/" << tfm::format("%s_MISSING.hpp", generator->GetGameNameShort()) << "\"\n";
	}

	os << "\n";

	for (auto&& package : packages)
	{
		os << R"(#include "SDK/)" << GenerateFileName(FileContentType::Structs, *package) << "\"\n";
		os << R"(#include "SDK/)" << GenerateFileName(FileContentType::Classes, *package) << "\"\n";
		if (generator->ShouldGenerateFunctionParametersFile())
		{
			os << R"(#include "SDK/)" << GenerateFileName(FileContentType::FunctionParameters, *package) << "\"\n";
		}
	}
}






/// <summary>
/// Process the packages.
/// </summary>
/// <param name="path">The path where to create the package files.</param>
void ProcessPackages(std::string path)
{
	using namespace cpplinq;

	const auto sdkPath = path + "/SDK";
	mkdir(sdkPath.c_str(), 0777);

	std::vector<std::unique_ptr<Package>> packages;

	std::unordered_map<UEObject, bool> processedObjects;

	auto packageObjects = from(ObjectsStore())
			>> select([](auto&& o) { return o.GetPackageObject(); })
			>> where([](auto&& o) { return o.IsValid(); })
			>> distinct()
			>> to_vector();


	for (auto obj : packageObjects)
	{
		auto package = std::make_unique<Package>(obj);

		package->Process(processedObjects);
		if (package->Save(sdkPath))
		{
			Package::PackageMap[obj] = package.get();

			packages.emplace_back(std::move(package));
		}
	}

	if (!packages.empty())
	{

		const PackageDependencyComparer comparer;
		for (auto i = 0u; i < packages.size() - 1; ++i)
		{
			for (auto j = 0u; j < packages.size() - i - 1; ++j)
			{
				if (!comparer(packages[j], packages[j + 1]))
				{
					std::swap(packages[j], packages[j + 1]);
				}
			}
		}
	}

	SaveSDKHeader(path, processedObjects, packages);
}


void GenerateOffset(std::string path)
{
	
	std::ofstream o, js;
	
    ObjectsStore* Objects;

    if (hpp)
    {
        o = std::ofstream(path + "/" + "Kaushik_Offsets.hpp");
    }
    if (ijson)
    {
        js = std::ofstream(path + "/" + "Kaushik_Offsets.json");
    }
	
	std::unordered_map<std::string, bool> names;
    names =
    {
        
        std::pair<std::string,bool>("Engine.Engine.GameViewport",false),
        std::pair<std::string,bool>("Engine.GameViewportClient.World",false),
        std::pair<std::string,bool>("Engine.LocalPlayer",false),
        
        std::pair<std::string,bool>("Engine.World.LevelCollections",false),
        std::pair<std::string,bool>("Engine.World.NetDriver",false),
        std::pair<std::string,bool>("Engine.World.PersistentLevel",false),
        std::pair<std::string,bool>("Engine.NetDriver.ServerConnection",false),
        
        std::pair<std::string,bool>("Engine.Actor.RootComponent",false),
        std::pair<std::string,bool>("Engine.Actor.bHidden",false),

        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraWeapon.WeaponEntityComp",false),

        std::pair<std::string,bool>("Engine.Character.Mesh",false),
        
        std::pair<std::string,bool>("Engine.StaticMeshComponent.StaticMesh",false),
        std::pair<std::string,bool>("Engine.StaticMeshComponent.MinLOD",false),
        std::pair<std::string,bool>("Engine.SkeletalMeshComponent.CachedBoneSpaceTransforms",false),
        std::pair<std::string,bool>("Engine.SkeletalMeshComponent.CachedComponentSpaceTransforms",false),
        
        std::pair<std::string,bool>("ShadowTrackerExtra.PickUpListWrapperActor.PickUpDataList",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.PickUpWrapperActor.Count",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.PickUpWrapperActor.bCanBePickUp",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.PickUpWrapperActor.DefineID",false),
        
        std::pair<std::string,bool>("ShadowTrackerExtra.ShootWeaponEntity.BulletTemplate",false),
        
        std::pair<std::string,bool>("Gameplay.WeaponAttrReloadTableStruct.AccessoriesVRecoilFactor",false),
        std::pair<std::string,bool>("Gameplay.WeaponAttrReloadTableStruct.AccessoriesHRecoilFactor",false),
        std::pair<std::string,bool>("Gameplay.WeaponAttrReloadTableStruct.AccessoriesRecoveryFactor",false),
        std::pair<std::string,bool>("Gameplay.WeaponAttrReloadTableStruct.RecoilKickADS",false),
        
        std::pair<std::string,bool>("ShadowTrackerExtra.ShootWeaponEntity.ShotGunCenterPerc",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.ShootWeaponEntity.ShotGunVerticalSpread",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.ShootWeaponEntity.ShotGunHorizontalSpread",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.ShootWeaponEntity.GameDeviationFactor",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.ShootWeaponEntity.GameDeviationAccuracy",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.ShootWeaponEntity.AccessoriesDeviationFactor",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.ShootWeaponEntity.RecoilInfo",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraShootWeaponBulletBase.PMComp",false),
        
        std::pair<std::string,bool>("Gameplay.UAECharacter.bIsAI",false),
		std::pair<std::string,bool>("Gameplay.UAECharacter.bEnsure",false),
        std::pair<std::string,bool>("Gameplay.UAECharacter.TeamID",false),
        std::pair<std::string,bool>("Gameplay.UAECharacter.PlayerKey",false),
        std::pair<std::string,bool>("Gameplay.UAECharacter.PlayerName",false),
        std::pair<std::string,bool>("Gameplay.UAECharacter.PlayerUID",false),
        std::pair<std::string,bool>("Gameplay.UAECharacter.Nation",false),

        std::pair<std::string,bool>("Gameplay.UAEPlayerController.TeamID",false),
        std::pair<std::string,bool>("Gameplay.UAEPlayerController.PlayerKey",false),
        std::pair<std::string,bool>("Gameplay.UAEPlayerController.PlayerName",false),
        std::pair<std::string,bool>("Gameplay.UAEPlayerController.UId",false),
        
        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraCharacter.Health",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraCharacter.HealthMax",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraCharacter.bDead",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraCharacter.CurrentVehicle",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraCharacter.bIsGunADS",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraCharacter.PartHitComponent",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraCharacter.CurrentStates",false),
        
        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraBaseCharacter.VehicleSeatIdx",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraBaseCharacter.bIsWeaponFiring",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraBaseCharacter.STCharacterMovement",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraBaseCharacter.WeaponManagerComponent",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraBaseCharacter.NearDeatchComponent",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraBaseCharacter.NearDeathBreath",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.STCharacterNearDeathComp.BreathMax",false),

        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraPlayerCharacter.STPlayerController",false),
        
        std::pair<std::string,bool>("ShadowTrackerExtra.ShootWeaponEntity.BulletFireSpeed",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.ShootWeaponEntity.bHasAutoFireMode",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.WeaponManagerComponent.CurrentWeaponReplicated",false),

        std::pair<std::string,bool>("Engine.PrimitiveComponent.LastRenderTime",false),
        std::pair<std::string,bool>("Engine.SceneComponent.RelativeLocation",false),
        std::pair<std::string,bool>("Engine.SceneComponent.ComponentVelocity",false),
        
        std::pair<std::string,bool>("Engine.CharacterMovementComponent.LastUpdateVelocity",false),
        std::pair<std::string,bool>("Engine.CharacterMovementComponent.LastUpdateRotation",false),
        std::pair<std::string,bool>("Engine.CharacterMovementComponent.LastUpdateLocation",false),
        
        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraPlayerCharacter.STPlayerController",false),
        
        std::pair<std::string,bool>("ShadowTrackerExtra.WeaponManagerComponent.CurrentWeaponReplicated",false),

        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraVehicleBase.VehicleShapeType",false),
        
        std::pair<std::string,bool>("Engine.PlayerController.AcknowledgedPawn",false),
        std::pair<std::string,bool>("Engine.PlayerController.MyHUD",false),
        std::pair<std::string,bool>("Engine.PlayerController.PlayerCameraManager",false),

        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraPlayerController.bIsPressingFireBtn",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraPlayerController.CurCameraMode",false),
        
        std::pair<std::string,bool>("Engine.MovementComponent.Velocity",false),
        
        std::pair<std::string,bool>("Engine.Controller.TransformComponent",false),
        std::pair<std::string,bool>("Engine.Controller.ControlRotation",false),
        
        
        std::pair<std::string,bool>("Engine.Controller.TransformComponent",false),
        
        std::pair<std::string,bool>("Engine.CharacterMovementComponent.JumpZVelocity",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.STCharacterMovementComponent.WalkSpeedCurveScale",false),

        std::pair<std::string,bool>("Engine.PlayerCameraManager.CameraCache",false),
        std::pair<std::string,bool>("Engine.CameraCacheEntry.POV",false),
        std::pair<std::string,bool>("Engine.MinimalViewInfo.Location",false),
        std::pair<std::string,bool>("Engine.MinimalViewInfo.Rotation",false),
        std::pair<std::string,bool>("Engine.MinimalViewInfo.FOV",false),
        
        std::pair<std::string,bool>("Engine.LocalPlayer.AspectRatioAxisConstraint",false),
        

        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraPlayerController.STExtraBaseCharacter",false),         
        std::pair<std::string,bool>("ShadowTrackerExtra.CharacterOverrideAttrs.GameModeOverride_SpeedScaleModifier",false),            
        std::pair<std::string,bool>("ShadowTrackerExtra.PetEntityComponent.FixAttachInfoList",false),
		
		std::pair<std::string,bool>("ShadowTrackerExtra.STExtraGameStateBase.GameID",false),         
        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraGameStateBase.PlayerNumPerTeam",false),            
        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraGameStateBase.AlivePlayerNum",false),
		std::pair<std::string,bool>("ShadowTrackerExtra.STExtraGameStateBase.PlayerNum",false),         
        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraGameStateBase.AliveTeamNum",false),            
        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraGameStateBase.ElapsedTime",false),
        std::pair<std::string,bool>("ShadowTrackerExtra.STExtraPlayerController.BroadcastFatalDamageToClientWithStruct",false),
		
    };
	
	if (hpp)
    {
        tfm::format(o, "#pragma once\n\n");
        tfm::format(o, generator->GetAuthorNotes().c_str(), generator->GetGameName(), generator->GetGameVersion(), generator->CurrTime());
        tfm::format(o, "#define GWorld 0x0; // World\n#define GName 0x0; // TStaticIndirectArrayThreadSafeRead\n#define GObjectArray 0x0; // FUObjectArray\n\n\n\n");
    }
    int count = 0;
    int total = names.size();
    
    std::string jsonDef = "\t{\n\t\t\"Index\" : %06i,\n\t\t\"Category\" : \"%s\",\n\t\t\"Name\" : \"%s\",\n\t\t\"Offset\" : %d\n\t},\n";

    std::string jsonDefEnd = "\t{\n\t\t\"Index\" : %06i,\n\t\t\"Category\" : \"%s\",\n\t\t\"Name\" : \"%s\",\n\t\t\"Offset\" : %d\n\t}\n";

    if (ijson)
    {
        tfm::format(js, "[\n");
    }
    
    int tt;
    
    for (int i = 0; i < Objects->GetObjectsNum(); i++)
    {
        auto obj = Objects->GetById(i);
        if (obj.IsValid())
        {
            std::string name = obj.GetFullPath();
            
            if (names.count(name) == 1)
            {
                tt++;
                UEProperty prop = obj.Cast<UEProperty>();
               
                if (ijson)
                {
                    if (tt == 86)
                        tfm::format(js, jsonDefEnd.c_str(), tt, prop.GetOuter().GetName().c_str(), prop.GetName().c_str(), (int) prop.GetOffset());
                    else
                        tfm::format(js, jsonDef.c_str(), tt, prop.GetOuter().GetName().c_str(), prop.GetName().c_str(), (int) prop.GetOffset());
                }
                if (hpp)
                {
                    tfm::format(o, "#define %s_%s 0x%p; // %s\n", prop.GetOuter().GetName().c_str(), prop.GetName().c_str(), prop.GetOffset(), prop.GetOuter().GetName().c_str());
                }
                names[name] = true;
            }
        }
    }
    
    if (hpp)
        tfm::format(o, "\n\n");
    if (ijson)
        tfm::format(js, "]\n");
        
    for (auto i : names)
    {
        if (i.second == true)
        {
            count++;
        }
        else
        {
            if (hpp)
                tfm::format(o, "// %s Not Found\n", i.first.c_str());
        }
    }
    if (hpp)
        tfm::format(o, "// Found %d offsets of %d\n", count, total);
}

void* main_thread (void *)
{
	LOGI("Attaching Dumper...");

sleep(7);
	uintptr_t UE4 = Tools::GetBaseAddress("libUE4.so");
	while (!UE4) {
		UE4 = Tools::GetBaseAddress("libUE4.so");
		sleep(1);
	}
	LOGI("libUE4 Base Address; %zu",UE4);

	if (!ObjectsStore::Initialize())
	{
		return 0;
	}
	LOGI("ObjectsStore::Initialized...");
	if (!NamesStore::Initialize())
	{
		return 0;
	}
	LOGI("NamesStore::Initialized...");
	if (!generator->Initialize())
	{
		return 0;
	}
	LOGI("Generator::Initialized...");



	
	


	std::string outputDirectory = generator->GetOutputDirectory(pkgName);

	outputDirectory += "/" + generator->GetGameNameShort() + "_(v" + generator->GetGameVersion() + ")_64Bit";


	mkdir(outputDirectory.c_str(), 0777);
	LOGI("Directories Created...");

	std::ofstream log2(outputDirectory + "/Kaushik.log");
	Logger::SetStream(&log2);

	Logger::Log("Checking LOGs");

	Logger::Log("Dumping GNames & GObjects...");
	LOGI("Dumping GNames & GObjects...");
	Dump(outputDirectory);
	
	Logger::Log("Dumping Offset Infos...");
	LOGI("Dumping GenerateOffset Infos...");
	GenerateOffset(outputDirectory);

	const auto begin = std::chrono::system_clock::now();

	Logger::Log("Dumping SDK...");
	LOGI("Dumping SDK...");
	ProcessPackages(outputDirectory);

	Logger::Log("Finished, took %d seconds.", std::chrono::duration_cast<std::chrono::seconds>(std::chrono::system_clock::now() - begin).count());


	return 0;
}
extern "C"
JNIEXPORT int JNI_OnLoad(JavaVM* vm, void* reserved) {
    JNIEnv* env;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        return JNI_ERR;
    }
    
     //Media_Folder = "/storage/emulated/0/Android/data/com.tencent.igce/" + pkgName;
    Media_Folder = "/storage/emulated/0/Android/media/" + pkgName;
    //Media_Folder = "/storage/emulated/0/Android/data/com.pubg.imobile/" + pkgName;
    
    struct stat info;
    if( stat( Media_Folder.c_str(), &info ) != 0 ){
    LOGE( "cannot access %s\n", Media_Folder.c_str() );
    mkdir(Media_Folder.c_str(), 0777);
    }
   
   pthread_t m_thread;
   pthread_create(&m_thread, 0, main_thread, 0);
    
   return JNI_VERSION_1_6;
}

extern "C"
{
void __attribute__ ((visibility ("default"))) OnLoad() 
{
    
    //Media_Folder = "/storage/emulated/0/Android/data/com.tencent.igce/" + pkgName;
    Media_Folder = "/storage/emulated/0/Android/media/" + pkgName;
    //Media_Folder = "/storage/emulated/0/Android/data/com.pubg.imobile/" + pkgName;
    
    struct stat info;
    if( stat( Media_Folder.c_str(), &info ) != 0 ){
    LOGE( "cannot access %s\n", Media_Folder.c_str() );
    mkdir(Media_Folder.c_str(), 0777);
    }

      pthread_t thread;
      pthread_create(&thread, 0, main_thread, 0);
      
}
}


