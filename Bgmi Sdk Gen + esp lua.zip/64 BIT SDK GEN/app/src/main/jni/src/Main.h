#pragma once

#ifndef PARTH_H
#define PARTH_H

#include "log.h"
#include <cstdint>
#include "types.h"
#include "Logger.h"

using namespace std;

static std::string Media_Folder;
static char* lib_name = "libUE4.so";
static uintptr_t UE4 = 0;
static std::string pkgName = "com.pubg.imobile";
static std::string gameVersion = "3.8.0";
static std::string gameShortName = "BGMI";
static std::string gameFullName = "Battlegrounds India";





#endif
