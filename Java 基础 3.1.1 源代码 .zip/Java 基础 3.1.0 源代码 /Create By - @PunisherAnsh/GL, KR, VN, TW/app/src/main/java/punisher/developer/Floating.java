package punisher.developer;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.text.Html;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import android.animation.ArgbEvaluator;
import android.animation.TimeAnimator;
import android.animation.ValueAnimator;
import android.animation.ArgbEvaluator;
import android.animation.TimeAnimator;
import punisher.developer.animation.Titanic;
import punisher.developer.animation.TitanicTextView;

import org.json.JSONArray;
import org.json.JSONObject;
import android.view.WindowManager.LayoutParams;
import java.io.File;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import java.io.ByteArrayOutputStream;
import android.content.res.AssetManager;
import android.view.ViewConfiguration;
import android.util.DisplayMetrics;
import android.net.Uri;
import android.os.Bundle;

public class Floating extends Service {
	private int btn;
	static {
        System.loadLibrary("XoroEsp");
    }

    WindowManager windowManager;

	GradientDrawable gdMenuBody, gdAnimation = new GradientDrawable();

    int screenWidth, screenHeight,type;
    float density;

    WindowManager.LayoutParams iconLayoutParams, mainLayoutParams, canvasLayoutParams;
    RelativeLayout iconLayout;
    LinearLayout mainLayout;
    CanvasView canvasLayout;
	//ESPView canvasLayout;
    RelativeLayout closeLayout, maximizeLayout, minimizeLayout;
    RelativeLayout.LayoutParams closeLayoutParams, maximizeLayoutParams, minimizeLayoutParams;

    ImageView iconImg;

    String[] listTab = {"ESP", "ITEM", "SDK"};
    LinearLayout[] pageLayouts = new LinearLayout[listTab.length];
    int lastSelectedPage = 0;

    SharedPreferences configPrefs;
    long sleepTime = 1000 / 60;

    boolean isMaximized = false;
    int lastMaximizedX = 0, lastMaximizedY = 0;
    int lastMaximizedW = 0, lastMaximizedH = 0;

    int layoutWidth = 270;
    int layoutHeight = 354;
    int iconSize = 40;
    int menuButtonSize = 30;
    int tabWidth = 30;
    int tabHeight = 135;
    float mediumSize = 5.0f;

    String titleName = " XoroEsp™ 3.8.0";
    TextView textTitle;
    long lastUpdateTitle = 0;
    Random random = new Random();

    private native void onSendConfig(String s, String v);
	//public static native void DrawOn(ESPView espView, Canvas canvas);
    private native void onCanvasDraw(Canvas canvas, int w, int h, float d);
	//private native String hehe();
    // static native void Range(int num, float size);
   // public native void Range(int range);  
    private native String hehehe();
	
	
	void CreateCanvas() {
        final int FLAGS = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
			WindowManager.LayoutParams.FLAG_FULLSCREEN |
			WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR |
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
			WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS |
			WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS |
			WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;

        canvasLayoutParams = new WindowManager.LayoutParams(screenWidth, screenHeight, type, FLAGS, PixelFormat.RGBA_8888);

        canvasLayoutParams.x = 0;
        canvasLayoutParams.y = 0;
        canvasLayoutParams.gravity = Gravity.START | Gravity.TOP;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            canvasLayoutParams.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
		RecorderFakeUtils.setFakeRecorderWindowLayoutParams(mainLayoutParams);
		RecorderFakeUtils.setFakeRecorderWindowLayoutParams(iconLayoutParams);
		RecorderFakeUtils.setFakeRecorderWindowLayoutParams(canvasLayoutParams);
        canvasLayout = new CanvasView(this);
        windowManager.addView(canvasLayout, canvasLayoutParams);
    }

    private class CanvasView extends View {
        public CanvasView(Context context) {
            super(context);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            if (canvas != null) {
                onCanvasDraw(canvas, screenWidth, screenHeight, density);
            }
        }
    }

    private void UpdateConfiguration(String s, Object v) {
        try {
            onSendConfig(s, v.toString());

            SharedPreferences.Editor configEditor = configPrefs.edit();
            configEditor.putString(s, v.toString());
            configEditor.apply();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (mUpdateCanvas.isAlive()) {
            mUpdateCanvas.interrupt();
        }
        if (mUpdateThread.isAlive()) {
            mUpdateThread.interrupt();
        }

        if (iconLayout != null) {
            windowManager.removeView(iconLayout);
        }
        if (mainLayout != null) {
            windowManager.removeView(mainLayout);
        }
        if (canvasLayout != null) {
            windowManager.removeView(canvasLayout);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

	private void startAnimation() {
        //Credit: Octowolve
        //https://github.com/Octowolve/Hooking-Template-With-Mod-Menu/blob/27f68f4f7b4f8f40763aa2d2ebf9c85e7ae04fa5/app/src/main/java/com/dark/force/MenuService.java#L505


        final int start = Color.parseColor("#000000");
		//   final int middle = Color.parseColor("#B21F1F");
        final int end = Color.parseColor("#CC0000");

        final ArgbEvaluator evaluator = new ArgbEvaluator();
        gdAnimation.setStroke(5,Color.WHITE);
        gdAnimation.setCornerRadius(50);
        gdAnimation.setOrientation(GradientDrawable.Orientation.TL_BR);
        final GradientDrawable gradient = gdAnimation;

        ValueAnimator animator = TimeAnimator.ofFloat(0.4f, 0.6f);
        animator.setDuration(1700);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setRepeatMode(ValueAnimator.REVERSE);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    Float fraction = valueAnimator.getAnimatedFraction();
                    int newStart = (int) evaluator.evaluate(fraction, start, end);
					// int newMiddle = (int) evaluator.evaluate(fraction, middle, end);
                    int newEnd = (int) evaluator.evaluate(fraction, end, start);
                    int[] newArray = {newStart, newEnd};
                    gradient.setColors(newArray);
                }
            });

        animator.start();
    }
	
	
    @Override
    public void onCreate() {
        super.onCreate();
        configPrefs = getSharedPreferences("config", MODE_PRIVATE);
		windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        Point screenSize = new Point();
        Display display = windowManager.getDefaultDisplay();
        display.getRealSize(screenSize);

        screenWidth = screenSize.x;
        screenHeight = screenSize.y;
        density = getResources().getDisplayMetrics().density;
		layoutWidth = convertSizeToDp(270);
        layoutHeight = convertSizeToDp(354);
        iconSize = convertSizeToDp(40);
        btn = convertSizeToDp(30);
        menuButtonSize = convertSizeToDp(30);            
        tabWidth = convertSizeToDp(90);
        tabHeight = convertSizeToDp(40);
		
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            type = 2038;
        } else {
            type = 2002;
        }
		
		RecorderFakeUtils.setFakeRecorderWindowLayoutParams(mainLayoutParams);
		RecorderFakeUtils.setFakeRecorderWindowLayoutParams(iconLayoutParams);
		RecorderFakeUtils.setFakeRecorderWindowLayoutParams(canvasLayoutParams);
        CreateIcon();
        CreateLayout();
        CreateCanvas();
		startAnimation();

        mUpdateThread.start();
        mUpdateCanvas.start();
    }

    void AddFeatures() {
		//AddText(0,"Model: " + Build.MODEL , 7.0f, Color.BLACK);
		AddTextDivide(0,"ANTIBAN MENU");	
		AddSwitch(0, "Logo Bypaas", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("ESP::LINE", isChecked ? 1 : 0);
				}
			});
        AddButton(0,"       Join Telegram ",ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 15, new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent("android.intent.action.VIEW");
                    intent.setFlags(268435456);
                    intent.setPackage("org.telegram.messenger");
                    intent.setData(Uri.parse("https://t.me/XoroEsp"));
                    Floating.this.getApplicationContext().startActivity(intent);               
                }
            });
		AddTextDivide(0,"ESP MENU");	
        AddSwitch(0, "Line", false, new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                UpdateConfiguration("ESP::LINE", isChecked ? 1 : 0);
            }
        });
        AddSwitch(0, "Box", false, new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                UpdateConfiguration("ESP::BOX", isChecked ? 1 : 0);
            }
        });
        AddSwitch(0, "Skeleton", false, new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                UpdateConfiguration("ESP::SKELETON", isChecked ? 1 : 0);
            }
        });
        AddSwitch(0, "Health", false, new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                UpdateConfiguration("ESP::HEALTH", isChecked ? 1 : 0);
            }
        });
        AddSwitch(0, "Team ID", false, new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                UpdateConfiguration("ESP::TEAM_ID", isChecked ? 1 : 0);
            }
        });
        AddSwitch(0, "Name", false, new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                UpdateConfiguration("ESP::NAME", isChecked ? 1 : 0);
            }
        });
        AddSwitch(0, "Distance", false, new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                UpdateConfiguration("ESP::DISTANCE", isChecked ? 1 : 0);
            }
        });

		
	/*Menu 2 4GG*/
	
        AddSwitch(0, "Vehicle", false, new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                UpdateConfiguration("ESP::VEHICLE", isChecked ? 1 : 0);
            }
        });
        AddSwitch(0, "Grenade Warning", false, new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                UpdateConfiguration("ESP::GRENADE", isChecked ? 1 : 0);
            }
        });
        AddSwitch(0, "Loot Box", false, new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                UpdateConfiguration("ESP::LOOT_BOX", isChecked ? 1 : 0);
            }
        });
       AddSwitch(0, "Show Loot Box Content", false, new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                UpdateConfiguration("ESP::LOOT_BOX_ITEMS", isChecked ? 1 : 0);
            }
        });
        AddSeekbar(0, "Max Distance", 0, 100, 10, "", "m", new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                UpdateConfiguration("ESP::LOOT_BOX_MAX_DISTANCE", progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        AddSeekbar(0, "ESP Framerate", 30, 120, 60, "", " FPS", new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                sleepTime = 1000 / progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        // ============================Fiture 3 4GG=============================================== //
        try {
            InputStream is = getAssets().open("items.png");
            int size = is.available();
            byte[] buffer = new byte[size];
            if (is.read(buffer) > 0) {
                is.close();
                String json = new String(buffer, StandardCharsets.UTF_8);
                UpdateConfiguration("CMD_PARSE_ITEMS", json);

                JSONArray arr = new JSONArray(json);
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject obj = arr.getJSONObject(i);

                    if (obj.has("itemCategory")) {
                        String itemCategory = obj.getString("itemCategory");
                        AddTextDivide(1,itemCategory);
                    } else {
                        String itemName = obj.getString("itemName");
                        final int itemId = obj.getInt("itemId");

                        AddSwitch(1, itemName, false, new CompoundButton.OnCheckedChangeListener() {
                            @Override
                            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                UpdateConfiguration("ESP::ITEMS", itemId);
                            }
                        });
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        // =======================================BulleTrack==================================== //
		AddTextDivide(2,"Brutal Menu");
		
		AddSwitch(2, "AIM::AIMBULLET", false, new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                UpdateConfiguration("AIM::AIMBULLET", isChecked ? 1 : 0);
            }
        });
       
        
       
        AddSwitch(2, "Xhit Effect", false, new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                UpdateConfiguration("AIM::AIMBULLET", isChecked ? 1 : 0);
            }
        });

      
        AddSwitch(2, "Ipad View", false, new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                UpdateConfiguration("AIM::AIMBULLET", isChecked ? 1 : 0);
            }
        });

		
		/*AddSwitch(2, "Enable Aim", false, new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                UpdateConfiguration("AIM::AIMBOT", isChecked ? 1 : 0);
            }
        });*/
        
        
        /*dsss
        AddSwitch(2, "Bullet Tracking", false, new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                UpdateConfiguration("AIM::AIMBULLET", isChecked ? 1 : 0);
            }
        });
        AddTextDivide(2,"TARGET");
        AddRadioButton(2, new String[]{"Head", "Body"}, 0, new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                UpdateConfiguration("AIM::LOCATION", checkedId);
            }
        });
     //   AddText(2, "Aimbot Type: ", 5.0f, Color.RED);
		AddTextDivide(2,"PRIORITY");
        AddRadioButton(2, new String[]{"Shortest Distance", "FOV"}, 0, new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                UpdateConfiguration("AIM::TARGET", checkedId);
            }
        });
        AddSeekbar(2, "Fov Size:", 0, 1000, 0, "", "", new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                UpdateConfiguration("AIM::SIZE", progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        AddTextDivide(2,"TRGGER");
        AddRadioButton(2, new String[]{"None", "Shoot", "Scope"}, 0, new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                UpdateConfiguration("AIM::TRIGGER", checkedId);
            }
        });
        AddSwitch(2, "Prediction", false, new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                UpdateConfiguration("AIM::PREDICTION", isChecked ? 1 : 0);
            }
        });
        AddSwitch(2, "Ignore Knocked", false, new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                UpdateConfiguration("AIM::KNOCKED", isChecked ? 1 : 0);
            }
        });
        AddSwitch(2, "Visibility Check", false, new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                UpdateConfiguration("AIM::VISCHECK", isChecked ? 1 : 0);
            }
        });
   /*    AddSwitch(3, "Less Recoil", false, new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                UpdateConfiguration("MEMORY::RECOIL", isChecked ? 1 : 0);
            }
        });

         AddSwitch(3, "Smal Crosshair", false, new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                UpdateConfiguration("MEMORY::SMAL", isChecked ? 1 : 0);
            }
        });

       AddSeekbar(4, "Menu Size", 50, 200, 100, "", "%", new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                mainLayoutParams.width = (int) ((float) layoutWidth * ((float) progress / 100.f));
                mainLayoutParams.height = (int) ((float) layoutHeight * ((float) progress / 100.f));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                windowManager.updateViewLayout(mainLayout, mainLayoutParams);

                closeLayout.setX(mainLayoutParams.width - closeLayoutParams.width - (closeLayoutParams.width * 0.075f));
                maximizeLayout.setX(closeLayout.getX() - maximizeLayoutParams.width - (maximizeLayoutParams.width * 0.075f));
                minimizeLayout.setX(maximizeLayout.getX() - minimizeLayoutParams.width - (minimizeLayoutParams.width * 0.075f));
            }
        });
        AddSeekbar(4, "Menu Opacity", 1, 100, 100, "", "%", new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                mainLayout.setAlpha((float) progress / 100.f);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        AddSeekbar(4, "Icon Size", 50, 200, 100, "", "%", new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                ViewGroup.LayoutParams iconParams = iconImg.getLayoutParams();
                iconParams.width = (int) ((float) iconSize * ((float) progress / 100.f));
                iconParams.height = (int) ((float) iconSize * ((float) progress / 100.f));
                iconImg.setLayoutParams(iconParams);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                iconLayout.setVisibility(View.VISIBLE);
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                iconLayout.setVisibility(View.GONE);
            }
        });
        AddSeekbar(4, "Icon Opacity", 0, 100, 100, "", "%", new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                iconLayout.setAlpha((float) progress / 100.f);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                iconLayout.setVisibility(View.VISIBLE);
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                iconLayout.setVisibility(View.GONE);
            }
        });*/
    }

    @SuppressLint("ClickableViewAccessibility")
    void CreateLayout() {
		final int type;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            type = 2038;
        } else {
            type = 2002;
        }
        mainLayoutParams = new WindowManager.LayoutParams(layoutWidth, layoutHeight, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS | WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, PixelFormat.RGBA_8888);
		RecorderFakeUtils.setFakeRecorderWindowLayoutParams(mainLayoutParams);
		RecorderFakeUtils.setFakeRecorderWindowLayoutParams(iconLayoutParams);
		RecorderFakeUtils.setFakeRecorderWindowLayoutParams(canvasLayoutParams);
        mainLayoutParams.x = 0;
        mainLayoutParams.y = 0;
        mainLayoutParams.gravity = Gravity.START | Gravity.TOP;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            mainLayoutParams.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

		mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        GradientDrawable mainLayoutBg = new GradientDrawable();
        mainLayoutBg.setColor(Color.parseColor("#00000000"));
        mainLayout.setBackground(mainLayoutBg);
        mainLayout.setBackground(gdAnimation);



        RelativeLayout headerLayout = new RelativeLayout(this);
        headerLayout.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, menuButtonSize + convertSizeToDp(4)));
        headerLayout.setClickable(true);
        headerLayout.setFocusable(true);
        headerLayout.setFocusableInTouchMode(true);
        headerLayout.setBackgroundColor(Color.parseColor("#00000000"));
        mainLayout.addView(headerLayout);

        TitanicTextView textTitle = new TitanicTextView(this);
        textTitle.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        textTitle.setGravity(Gravity.START|Gravity.CENTER_HORIZONTAL);
        textTitle.setClickable(true);
		textTitle.setPadding(30,17,0,0);
        textTitle.setFocusable(true);
        textTitle.setFocusableInTouchMode(true);
        Typeface IIU = Typeface.createFromAsset(getAssets(),"fonts/14.ttf"); 
        textTitle.setTypeface(IIU);
        textTitle.setText(" XoroEsp™ - 64Bit" );
        textTitle.setTextSize(convertSizeToDp(6.0f));
        textTitle.setTextColor(Color.WHITE);

        headerLayout.addView(textTitle);
		new Titanic().start(textTitle);



        View.OnTouchListener onTitleListener = new View.OnTouchListener() {
            float pressedX;
            float pressedY;
            float deltaX;
            float deltaY;
            float newX;
            float newY;
            float maxX;
            float maxY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:

                        deltaX = mainLayoutParams.x - event.getRawX();
                        deltaY = mainLayoutParams.y - event.getRawY();

                        pressedX = event.getRawX();
                        pressedY = event.getRawY();

                        break;
                    case MotionEvent.ACTION_MOVE:
                        newX = event.getRawX() + deltaX;
                        newY = event.getRawY() + deltaY;

                        maxX = screenWidth - mainLayout.getWidth();
                        maxY = screenHeight - mainLayout.getHeight();

                        if (newX < 0)
                            newX = 0;
                        if (newX > maxX)
                            newX = (int) maxX;
                        if (newY < 0)
                            newY = 0;
                        if (newY > maxY)
                            newY = (int) maxY;

                        mainLayoutParams.x = (int) newX;
                        mainLayoutParams.y = (int) newY;
                        windowManager.updateViewLayout(mainLayout, mainLayoutParams);

                        break;

                    default:
                        break;
                }

                return false;
            }
        };

        headerLayout.setOnTouchListener(onTitleListener);
        textTitle.setOnTouchListener(onTitleListener);
		

        closeLayout = new RelativeLayout(this);
        closeLayoutParams = new RelativeLayout.LayoutParams(menuButtonSize, menuButtonSize);
        closeLayout.setLayoutParams(closeLayoutParams);
        closeLayout.setX(mainLayoutParams.width - closeLayoutParams.width - convertSizeToDp(2));
        closeLayout.setY(convertSizeToDp(2));
        closeLayout.setBackgroundColor(Color.TRANSPARENT);
        headerLayout.addView(closeLayout);

        maximizeLayout = new RelativeLayout(this);
        maximizeLayoutParams = new RelativeLayout.LayoutParams(menuButtonSize, menuButtonSize);
        maximizeLayout.setLayoutParams(maximizeLayoutParams);
        maximizeLayout.setX(closeLayout.getX() - maximizeLayoutParams.width - convertSizeToDp(2));
        maximizeLayout.setY(convertSizeToDp(2));
        maximizeLayout.setBackgroundColor(Color.TRANSPARENT);
        headerLayout.addView(maximizeLayout);

        minimizeLayout = new RelativeLayout(this);
        minimizeLayoutParams = new RelativeLayout.LayoutParams(menuButtonSize, menuButtonSize);
        minimizeLayout.setLayoutParams(minimizeLayoutParams);
        minimizeLayout.setX(maximizeLayout.getX() - minimizeLayoutParams.width - convertSizeToDp(2));
        minimizeLayout.setY(convertSizeToDp(2));
        minimizeLayout.setBackgroundColor(Color.TRANSPARENT);
        headerLayout.addView(minimizeLayout);

        closeLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Floating.this, 5);
                    builder.setTitle("PUNISHER 64BIT MOD");
                    builder.setMessage("Are You Sure You Want To Stop The Hack?\nyou Won't Be To Able Access The Hack Again Until You Re-open The Game!");
                    builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                stopSelf();
                            }
                        });
                    builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });

                    AlertDialog dialog = builder.create();
				   dialog.getWindow().setType(type);
                    dialog.show();
                }
            });

        maximizeLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    isMaximized = !isMaximized;

                    if (isMaximized) {
                        lastMaximizedX = mainLayoutParams.x;
                        lastMaximizedY = mainLayoutParams.y;

                        lastMaximizedW = mainLayoutParams.width;
                        lastMaximizedH = mainLayoutParams.height;

                        mainLayoutParams.x = 0;
                        mainLayoutParams.y = 0;

                        mainLayoutParams.width = screenWidth;
                        mainLayoutParams.height = screenHeight;
                        windowManager.updateViewLayout(mainLayout, mainLayoutParams);

                        closeLayout.setX(mainLayoutParams.width - closeLayoutParams.width - (closeLayoutParams.width * 0.075f));
                        maximizeLayout.setX(closeLayout.getX() - maximizeLayoutParams.width - (maximizeLayoutParams.width * 0.075f));
                        minimizeLayout.setX(maximizeLayout.getX() - minimizeLayoutParams.width - (minimizeLayoutParams.width * 0.075f));
                    } else {
                        mainLayoutParams.x = lastMaximizedX;
                        mainLayoutParams.y = lastMaximizedY;

                        mainLayoutParams.width = lastMaximizedW;
                        mainLayoutParams.height = lastMaximizedH;
                        windowManager.updateViewLayout(mainLayout, mainLayoutParams);

                        closeLayout.setX(mainLayoutParams.width - closeLayoutParams.width - (closeLayoutParams.width * 0.075f));
                        maximizeLayout.setX(closeLayout.getX() - maximizeLayoutParams.width - (maximizeLayoutParams.width * 0.075f));
                        minimizeLayout.setX(maximizeLayout.getX() - minimizeLayoutParams.width - (minimizeLayoutParams.width * 0.075f));
                    }
                }
            });

        minimizeLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mainLayout.setVisibility(View.GONE);
                    iconLayout.setVisibility(View.VISIBLE);
                }
            });

		TitanicTextView closeText = new TitanicTextView(this);
        closeText.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        closeText.setGravity(Gravity.CENTER);
        closeText.setText("✕");
        closeText.setTextSize(convertSizeToDp(mediumSize));
        closeText.setTextColor(Color.RED);
        closeLayout.addView(closeText);
        new Titanic().start(closeText);

        TitanicTextView maximizeText = new TitanicTextView(this);
        maximizeText.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        maximizeText.setGravity(Gravity.CENTER);
        maximizeText.setText("□");
        maximizeText.setTextSize(convertSizeToDp(mediumSize));
        maximizeText.setTextColor(Color.RED);
        maximizeLayout.addView(maximizeText);
        new Titanic().start(maximizeText);

        TitanicTextView minimizeText = new TitanicTextView(this);
        minimizeText.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        minimizeText.setGravity(Gravity.CENTER);
        minimizeText.setText("—");
        minimizeText.setTextSize(convertSizeToDp(mediumSize));
        minimizeText.setTextColor(Color.RED);
        minimizeLayout.addView(minimizeText);
        new Titanic().start(minimizeText);
		
        LinearLayout tabLayout = new LinearLayout(this);
        tabLayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        tabLayout.setOrientation(LinearLayout.HORIZONTAL);

		final GradientDrawable kontolBg3 = new GradientDrawable();
        kontolBg3.setColor(Color.BLACK);
        kontolBg3.setCornerRadius(50);
        kontolBg3.setStroke(5, Color.WHITE);


        HorizontalScrollView tabScrollView = new HorizontalScrollView(this);
        tabScrollView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        tabScrollView.setBackgroundColor(Color.TRANSPARENT);

        tabScrollView.addView(tabLayout);

        mainLayout.addView(tabScrollView);

        final RelativeLayout[] tabButtons = new RelativeLayout[listTab.length];
        for (int i = 0; i < tabButtons.length; i++) {
            pageLayouts[i] = new LinearLayout(this);
            pageLayouts[i].setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, menuButtonSize + convertSizeToDp(15)));
            pageLayouts[i].setOrientation(LinearLayout.VERTICAL);

            ScrollView scrollView = new ScrollView(this);
            scrollView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            scrollView.addView(pageLayouts[i]);

            tabButtons[i] = new RelativeLayout(this);
            tabButtons[i].setLayoutParams(new RelativeLayout.LayoutParams(tabWidth, tabHeight));
            if (i != 0) {
                tabButtons[i].setBackground(kontolBg3); 
                pageLayouts[i].setVisibility(View.GONE);
            } else {
                tabButtons[i].setBackground(kontolBg3); 
                pageLayouts[i].setVisibility(View.VISIBLE);
            }

            TitanicTextView tabText = new TitanicTextView(this);
            tabText.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            tabText.setGravity(Gravity.CENTER);
            tabText.setText(listTab[i]);

            //Typeface typeface = Typeface.createFromAsset(getAssets(),"title.ttf"); 
			// tabText.setTypeface(typeface);
			tabText.setTypeface(null, Typeface.BOLD);
			//tabText.setTypeface(null, typeface);
            tabText.setTextSize(convertSizeToDp(5.f));
            tabText.setTextColor(Color.WHITE);
            new Titanic().start(tabText);
            tabButtons[i].addView(tabText);
            final int curTab = i;


            tabButtons[i].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (curTab != lastSelectedPage) {
                            tabButtons[curTab].setBackground(kontolBg3);    
                            pageLayouts[curTab].setVisibility(View.VISIBLE);

                            pageLayouts[lastSelectedPage].setVisibility(View.GONE);
                            lastSelectedPage = curTab;

                            for (int j = 0; j < tabButtons.length; j++) {
                                if (j != curTab) {
                                    tabButtons[j].setBackground(kontolBg3); 
                                }
                            }
                        }
                    }
                });

            tabLayout.addView(tabButtons[i]);
            mainLayout.addView(scrollView);
        }

        windowManager.addView(mainLayout, mainLayoutParams);

		AddFeatures();
    }

    
    @SuppressLint("ClickableViewAccessibility")
    void CreateIcon() {
        iconLayout = new RelativeLayout(this);
        RelativeLayout.LayoutParams iconParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        iconLayout.setLayoutParams(iconParams);
        iconImg = new ImageView(this);
        ViewGroup.LayoutParams iconImgParams = new ViewGroup.LayoutParams(iconSize, iconSize);
        iconImg.setLayoutParams(iconImgParams);
        iconLayout.addView(iconImg);

        try {
            String iconBase64 = hehehe();
            byte[] iconData = Base64.decode(iconBase64, Base64.DEFAULT);

            Bitmap bmp = BitmapFactory.decodeByteArray(iconData, 0, iconData.length);
            iconImg.setImageBitmap(bmp);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        iconLayoutParams = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, PixelFormat.TRANSLUCENT);
        iconLayoutParams.gravity = Gravity.START | Gravity.TOP;

        iconLayoutParams.x = 0;
        iconLayoutParams.y = 0;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            iconLayoutParams.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        iconLayout.setVisibility(View.GONE);

        iconLayout.setOnTouchListener(new View.OnTouchListener() {
                float pressedX;
                float pressedY;
                float deltaX;
                float deltaY;
                float newX;
                float newY;

                @Override
                public boolean onTouch(View v, MotionEvent event) {

                    switch (event.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:

                            deltaX = iconLayoutParams.x - event.getRawX();
                            deltaY = iconLayoutParams.y - event.getRawY();

                            pressedX = event.getRawX();
                            pressedY = event.getRawY();

                            break;
                        case MotionEvent.ACTION_UP:
                            int Xdiff = (int) (event.getRawX() - pressedX);
                            int Ydiff = (int) (event.getRawY() - pressedY);

                            if (Xdiff == 0 && Ydiff == 0) {
                                mainLayout.setVisibility(View.VISIBLE);
                                iconLayout.setVisibility(View.GONE);
                            }
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            newX = event.getRawX() + deltaX;
                            newY = event.getRawY() + deltaY;

                            float maxX = screenWidth - v.getWidth();
                            float maxY = screenHeight - v.getHeight();

                            if (newX < 0)
                                newX = 0;
                            if (newX > maxX)
                                newX = (int) maxX;
                            if (newY < 0)
                                newY = 0;
                            if (newY > maxY)
                                newY = (int) maxY;

                            iconLayoutParams.x = (int) newX;
                            iconLayoutParams.y = (int) newY;

                            windowManager.updateViewLayout(iconLayout, iconLayoutParams);
                            break;

                        default:
                            break;
                    }

                    return false;
                }
            });
        windowManager.addView(iconLayout, iconLayoutParams);
    }

	
	
	LinearLayout CreateHolder(Object data) {
        RelativeLayout parentHolder = new RelativeLayout(this);
        parentHolder.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout childHolder = new LinearLayout(this);
        childHolder.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        childHolder.setOrientation(LinearLayout.HORIZONTAL);
        parentHolder.addView(childHolder);

        if (data instanceof Integer)
            pageLayouts[(Integer) data].addView(parentHolder);
        else if (data instanceof ViewGroup)
            ((ViewGroup) data).addView(parentHolder);

        return childHolder;
    }

	void AddTextDivide(Object data,String string) {
        TitanicTextView textView = new TitanicTextView(this);
		new Titanic().start(textView);
        textView.setText((CharSequence)string);
        textView.setTextSize(1, 20.0f);
        textView.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-2, -2));
		Typeface top = Typeface.createFromAsset(getAssets(),"fonts/title.ttf"); 
        textView.setTypeface(top);
        textView.setPadding(8, 15, 8, 8);
        textView.setTextColor(Color.parseColor("#FFF405"));
        textView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
		if (data instanceof Integer)
            pageLayouts[(Integer) data].addView(textView);
        else if (data instanceof ViewGroup)
            ((ViewGroup) data).addView(textView);
    }
	
	
    void AddText(Object data, String text, float size, int color) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setTextColor(color);
        textView.setPadding(15, 15, 15, 15);
        textView.setTextSize(convertSizeToDp(size));
        textView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
		
        if (data instanceof Integer)
            pageLayouts[(Integer) data].addView(textView);
        else if (data instanceof ViewGroup)
            ((ViewGroup) data).addView(textView);
    }

    void AddCenteredText(Object data, String text, int size, int typeface, String color) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setTextColor(Color.parseColor(color));
        textView.setTypeface(null, typeface);
        textView.setPadding(15, 15, 15, 15);
        textView.setTextSize(convertSizeToDp(size));
        textView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        textView.setGravity(Gravity.CENTER);

        if (data instanceof Integer)
            pageLayouts[(Integer) data].addView(textView);
        else if (data instanceof ViewGroup)
            ((ViewGroup) data).addView(textView);
    }


	
    void AddHeader(Object data, String text) {
        LinearLayout headerLayout = new LinearLayout(this);
        headerLayout.setLayoutParams(new WindowManager.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        headerLayout.setOrientation(LinearLayout.VERTICAL);
        headerLayout.setBackgroundColor(Color.rgb(255, 0, 0));

        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setTextColor(Color.RED);
        textView.setTypeface(null, Typeface.BOLD);
        textView.setPadding(15, 15, 15, 15);
        textView.setTextSize(convertSizeToDp(12.5f));
        textView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        headerLayout.addView(textView);

        if (data instanceof Integer)
            pageLayouts[(Integer) data].addView(headerLayout);
        else if (data instanceof ViewGroup)
            ((ViewGroup) data).addView(headerLayout);
    }

    void AddCheckbox(Object data, String text, boolean checked, CompoundButton.OnCheckedChangeListener listener) {
        CheckBox checkBox = new CheckBox(this);
        checkBox.setText(text);
        checkBox.setTextSize(convertSizeToDp(10.f));
        checkBox.setTextColor(Color.MAGENTA);
        checkBox.setChecked(checked);
        checkBox.setOnCheckedChangeListener(listener);
        checkBox.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        if (Build.VERSION.SDK_INT >= 21) {
            ColorStateList colorStateList = new ColorStateList(
				new int[][]{
					new int[]{-android.R.attr.state_checked}, // unchecked
					new int[]{android.R.attr.state_checked}  // checked
				},
				new int[]{
					Color.MAGENTA,
					Color.MAGENTA
				}
            );
            checkBox.setButtonTintList(colorStateList);
        }

        if (data instanceof Integer)
            pageLayouts[(Integer) data].addView(checkBox);
        else if (data instanceof ViewGroup)
            ((ViewGroup) data).addView(checkBox);
    }

    void AddSwitch(Object data, String text, boolean checked, CompoundButton.OnCheckedChangeListener listener) {
        Switch toggle = new Switch(this);
        toggle.setText(text);
        toggle.setTextSize(convertSizeToDp(mediumSize));
        toggle.setTextColor(Color.WHITE);
		toggle.setTypeface(Typeface.SERIF);
        toggle.setChecked(checked);
        toggle.setPadding(15, 15, 15, 15);
        toggle.setOnCheckedChangeListener(listener);
        toggle.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

		if (Build.VERSION.SDK_INT >= 21) {
            ColorStateList colorStateList = new ColorStateList(
                new int[][]{
                    new int[]{-android.R.attr.state_checked}, // unchecked
                    new int[]{android.R.attr.state_checked}  // checked
                },
                new int[]{
					Color.parseColor("#FFFFFF"),
					Color.parseColor("#FF0000"),
					Color.parseColor("#FFFFFF")
                }
            );
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
				toggle.getThumbDrawable().setTintList(colorStateList);
				toggle.getTrackDrawable().setTintList(colorStateList);
			}
        }
        if (data instanceof ViewGroup)
            ((ViewGroup) data).addView(toggle);
        else if (data instanceof Integer)
            pageLayouts[(int) data].addView(toggle);
    }
	
	

    void AddSeekbar(Object data, String text, int min, int max, int value, final String prefix, final String suffix, final SeekBar.OnSeekBarChangeListener listener) {
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        linearLayout.setOrientation(LinearLayout.HORIZONTAL);

        TextView textV = new TextView(this);
        textV.setText(text + ":");
        textV.setTextSize(convertSizeToDp(mediumSize));
        textV.setPadding(15, 15, 15, 15);
        textV.setTextColor(Color.WHITE);
        textV.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        textV.setGravity(Gravity.LEFT);

        SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(max);
        if (Build.VERSION.SDK_INT >= 26) {
            seekBar.setMin(min);
            seekBar.setProgress(min);
        }
        if (Build.VERSION.SDK_INT >= 21) {
            seekBar.setThumbTintList(ColorStateList.valueOf(Color.RED));
            seekBar.setProgressTintList(ColorStateList.valueOf(Color.RED));
        }
        seekBar.setPadding(20, 15, 20, 15);

        final TextView textValue = new TextView(this);
        textValue.setText(prefix + min + suffix);
        textValue.setGravity(Gravity.RIGHT);
        textValue.setTextSize(convertSizeToDp(mediumSize));
        textValue.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        textValue.setPadding(20, 15, 20, 15);
        textValue.setTextColor(Color.WHITE);

        final int minimValue = min;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					if (progress < minimValue) {
						progress = minimValue;
						seekBar.setProgress(progress);
					}

					if (listener != null) listener.onProgressChanged(seekBar, progress, fromUser);
					textValue.setText(prefix + progress + suffix);
				}

				@Override
				public void onStartTrackingTouch(SeekBar seekBar) {
					if (listener != null) listener.onStartTrackingTouch(seekBar);
				}

				@Override
				public void onStopTrackingTouch(SeekBar seekBar) {
					if (listener != null) listener.onStopTrackingTouch(seekBar);
				}
			});

        if (value != 0) {
            if (value < min)
                value = min;
            if (value > max)
                value = max;

            textValue.setText(prefix + value + suffix);
            seekBar.setProgress(value);
        }

        linearLayout.addView(textV);
        linearLayout.addView(textValue);

        if (data instanceof Integer) {
            pageLayouts[(Integer) data].addView(linearLayout);
            pageLayouts[(Integer) data].addView(seekBar);
        } else if (data instanceof ViewGroup) {
            ((ViewGroup) data).addView(linearLayout);
            ((ViewGroup) data).addView(seekBar);
        }
    }

    void AddRadioButton(Object data, String[] list, int defaultCheckedId, RadioGroup.OnCheckedChangeListener listener) {
        RadioGroup rg = new RadioGroup(this);
        RadioButton[] rb = new RadioButton[list.length];
        rg.setOrientation(RadioGroup.HORIZONTAL);
        for (int i = 0; i < list.length; i++) {
            rb[i] = new RadioButton(this);
            if (i == defaultCheckedId) rb[i].setChecked(true);
            rb[i].setPadding(10, 5, 10, 5);
            rb[i].setText(list[i]);
            rb[i].setTextSize(convertSizeToDp(5.0f));
            rb[i].setId(i);
            rb[i].setGravity(Gravity.LEFT);
            Typeface yyy = Typeface.createFromAsset(getAssets(), "fonts/10.ttf"); 
            rb[i].setTypeface(yyy);
            rb[i].setTextColor(Color.WHITE);
            rb[i].setButtonTintList(ColorStateList.valueOf(Color.WHITE));

            rg.addView(rb[i]);
        }
        rg.setOnCheckedChangeListener(listener);
        RelativeLayout.LayoutParams toggleP = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rg.setLayoutParams(toggleP);

        if (data instanceof Integer)
            pageLayouts[(Integer) data].addView(rg);
        else if (data instanceof ViewGroup)
            ((ViewGroup) data).addView(rg);
    }
	
    void AddDropdown(Object data, String[] list, AdapterView.OnItemSelectedListener listener) {
        LinearLayout holderLayout = new LinearLayout(this);
        holderLayout.setOrientation(LinearLayout.VERTICAL);
        holderLayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        holderLayout.setPadding(15, 15, 15, 15);
        holderLayout.setGravity(Gravity.CENTER);

        Spinner sp = new Spinner(this, Spinner.MODE_DROPDOWN);

        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(Color.argb(255, 233, 233, 233));
        drawable.setStroke(1, Color.BLACK);
        sp.setPopupBackgroundDrawable(drawable);
        sp.setBackground(drawable);

        sp.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);

                ((TextView) v).setTextColor(Color.WHITE);
                ((TextView) v).setTypeface(null, Typeface.BOLD);
                ((TextView) v).setGravity(Gravity.CENTER);

                return v;
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View v = super.getDropDownView(position, convertView, parent);

                ((TextView) v).setTextColor(Color.WHITE);
                ((TextView) v).setTypeface(null, Typeface.BOLD);
                ((TextView) v).setGravity(Gravity.CENTER);

                return v;
            }
        };
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(dataAdapter);
        sp.setOnItemSelectedListener(listener);
        sp.setPadding(0, 5, 0, 5);

        holderLayout.addView(sp);

        if (data instanceof Integer)
            pageLayouts[(Integer) data].addView(holderLayout);
        else if (data instanceof ViewGroup)
            ((ViewGroup) data).addView(holderLayout);
    }

	
	void AddButton(Object data, String text, int width, int height, int padding, View.OnClickListener listener) {
        LinearLayout holderLayout = new LinearLayout(this);
        holderLayout.setOrientation(LinearLayout.VERTICAL);
        holderLayout.setLayoutParams(new LinearLayout.LayoutParams(width, height));
        holderLayout.setPadding(padding, padding, padding, padding);
        holderLayout.setGravity(Gravity.CENTER);

        Button bt= new Button(this);
        TitanicTextView btn = new TitanicTextView(this);
        btn.setText(text);
        Typeface tokk = Typeface.createFromAsset(getAssets(),"fonts/title.ttf"); 
        btn.setTypeface(tokk);
        btn.setTextColor(Color.WHITE);

        btn.setTextSize(20f);
        btn.setOnClickListener(listener);
        btn.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        new Titanic().start(btn);

        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(Color.BLACK);
        drawable.setStroke(3, Color.WHITE);

        btn.setBackground(drawable);


        holderLayout.addView(btn);

        if (data instanceof Integer)
            pageLayouts[(Integer) data].addView(holderLayout);
        else if (data instanceof ViewGroup)
            ((ViewGroup) data).addView(holderLayout);
    }

    float convertSizeToDp(float size) {
        return TypedValue.applyDimension(
			TypedValue.COMPLEX_UNIT_DIP,
			size,
			getResources().getDisplayMetrics()
        );
    }

    int convertSizeToDp(int size) {
        return Math.round(TypedValue.applyDimension(
							  TypedValue.COMPLEX_UNIT_DIP,
							  size,
							  getResources().getDisplayMetrics()
						  ));
    }

	
    @SuppressLint("HandlerLeak")
    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what == 0) {
                try {
                    Point screenSize = new Point();
                    Display display = windowManager.getDefaultDisplay();
                    display.getRealSize(screenSize);

                    screenWidth = screenSize.x;
                    screenHeight = screenSize.y;

                    mainLayoutParams.width = layoutWidth;
                    mainLayoutParams.height = layoutHeight;
                    windowManager.updateViewLayout(mainLayout, mainLayoutParams);

                    canvasLayoutParams.width = screenWidth;
                    canvasLayoutParams.height = screenHeight;
                    windowManager.updateViewLayout(canvasLayout, canvasLayoutParams);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
            if (msg.what == 1) {
                if (lastUpdateTitle < System.currentTimeMillis()) {
                    char[] randS = "!@#$%^&*()".toCharArray();
                    char[] newTitle = titleName.toCharArray();
                    newTitle[random.nextInt(titleName.length())] = randS[random.nextInt(randS.length)];
                    textTitle.setText(String.valueOf(newTitle));
                    lastUpdateTitle = System.currentTimeMillis() + 500;
                }
            }
        }
    };

    Thread mUpdateCanvas = new Thread() {
        @Override
        public void run() {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_DISPLAY);
            while (isAlive() && !isInterrupted()) {
                try {
                    long t1 = System.currentTimeMillis();
                    canvasLayout.postInvalidate();
                    long td = System.currentTimeMillis() - t1;
                    Thread.sleep(Math.max(Math.min(0, sleepTime - td), sleepTime));
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
    };

    Thread mUpdateThread = new Thread() {
        @Override
        public void run() {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_DISPLAY);
            while (isAlive() && !isInterrupted()) {
                try {
                    long t1 = System.currentTimeMillis();
                    Point screenSize = new Point();
                    Display display = windowManager.getDefaultDisplay();
                    display.getRealSize(screenSize);

                    if (screenWidth != screenSize.x || screenHeight != screenSize.y) {
                        handler.sendEmptyMessage(0);
                    }

                    //handler.sendEmptyMessage(1);

                    long td = System.currentTimeMillis() - t1;
                    Thread.sleep(Math.max(Math.min(0, sleepTime - td), sleepTime));
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
    };
}

