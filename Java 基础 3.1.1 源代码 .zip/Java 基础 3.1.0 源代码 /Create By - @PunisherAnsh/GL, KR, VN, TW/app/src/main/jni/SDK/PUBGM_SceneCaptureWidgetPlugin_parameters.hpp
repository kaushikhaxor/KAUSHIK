#pragma once
// BGMI (3.8.0) TG @XorMods
// BGMI (3.8.0) TG @XorMods  
// @XorMods Thu May 15 09:51:48 2025
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function SceneCaptureWidgetPlugin.SceneCaptureWidget.SetSceneCaptureCameraActor
struct USceneCaptureWidget_SetSceneCaptureCameraActor_Params
{
	class ASceneCaptureCameraActor*                    InSceneCaptureCameraActor;                                // (Parm, ZeroConstructor, IsPlainOldData)
};

}

