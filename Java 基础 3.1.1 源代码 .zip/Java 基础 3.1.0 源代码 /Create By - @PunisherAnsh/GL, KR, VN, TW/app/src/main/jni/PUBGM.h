#pragma once

#include "StrEnc.h"
#include "Includes.h"

#include "SDK.hpp"
#include "fake_dlfcn.h"
#include "obfuscate.h"
#include <curl/curl.h>

#include "Tools.h"
#include "json.hpp"
#include "base64/base64.h"
#include "md5.h"
#include "Log.h"
//#include "Spoof.h"
#include "plthook.h"
#include "Engine/Canvas.h"
#include "KittyMemory/MemoryPatch.h"
#include "KittyMemory/KittyScanner.h"

using json = nlohmann::ordered_json;
using namespace SDK;
using namespace std;

#include "UE4.h"

extern void StartRuntimeHook(const char *);

// ================================================================================================================================
// //
uintptr_t g_UE4 = 0;

int algorithm = 0;

#define SLEEP_TIME 1000LL / 60LL
int g_screenWidth = 0, g_screenHeight = 0;
int screenDensity = 0;
std::string g_Token, g_Auth;
std::map<std::string, u_long> Config;
char extra[30];
bool bValid = false, bScanPatternCompleted = false;
ASTExtraPlayerCharacter *g_LocalPlayer = 0;
ASTExtraPlayerController *g_PlayerController = 0;
std::map<int, bool> itemConfig;
json itemData;
std::string expiretime = "";

void doPatch(uintptr_t offset, string replace) {
    MemoryPatch::createWithHex("libanort.so", offset, std::move(replace)).Modify();
}

void doBypass(uintptr_t offset, string replace) {
    MemoryPatch::createWithHex("libanogs.so", offset, std::move(replace)).Modify();
}

#define GNames_Offset 0x78a0af8
#define GUObject_Offset 0xd741460

struct sRegion
{
	uintptr_t start, end;
};

std::vector<sRegion> trapRegions;

bool isEqual(std::string s1, const char* check) {
    std::string s2(check);
    return (s1 == s2);
}

bool isObjectInvalid(UObject *obj)
{
	if (!Tools::IsPtrValid(obj))
	{
		return true;
	}
	if (!Tools::IsPtrValid(obj->ClassPrivate))
	{
		return true;
	}
	if (obj->InternalIndex <= 0)
	{
		return true;
	}
	if (obj->NamePrivate.ComparisonIndex <= 0)
	{
		return true;
	}
	if ((uintptr_t)(obj) % sizeof(uintptr_t) != 0x0 && (uintptr_t)(obj) % sizeof(uintptr_t) != 0x4)
	{
		return true;
	}
	if (std::any_of(trapRegions.begin(), trapRegions.end(), [obj](sRegion region) { return ((uintptr_t)obj) >= region.start && ((uintptr_t)obj) <= region.end; }) ||
		std::any_of(trapRegions.begin(), trapRegions.end(), [obj](sRegion region) { return ((uintptr_t)obj->ClassPrivate) >= region.start && ((uintptr_t)obj->ClassPrivate) <= region.end; }))
	{
		return true;
	}
	return false;
}

const char *getObjectPath(UObject *Object) {
std::string s;
for (auto super = Object->ClassPrivate; super; super = (UClass *) super->SuperStruct) {
if (!s.empty())
s += ".";
s += super->GetName();}return s.c_str();}

UWorld *GEWorld;
int GWorldNum = 0;
TUObjectArray gobjects;
UWorld *GetWorld(){
if(GWorldNum == 0) {
        gobjects = UObject::GUObjectArray->ObjObjects;
        for (int i=0; i< gobjects.Num(); i++)
            if (auto obj = gobjects.GetByIndex(i)) {
                if(obj->IsA(UEngine::StaticClass())) {
                    auto GEngine = (UEngine *) obj;
                    if(GEngine) {
                        auto ViewPort = GEngine->GameViewport;
                        if (ViewPort)
                        {
                            GEWorld = ViewPort->World;
                            GWorldNum = i;
                                return ViewPort->World;
                        }
                    }
                }
            }
    }else {
        auto GEngine = (UEngine *) (gobjects.GetByIndex(GWorldNum));
        if(GEngine) {
            auto ViewPort = GEngine->GameViewport;
            if(ViewPort) {
                GEWorld = ViewPort->World;
                return ViewPort->World;
            }
        }
    }
    return 0;
}

static UGameViewportClient *GameViewport = 0;
UGameViewportClient *GetGameViewport() {
    while (!GameViewport) {
        GameViewport = UObject::FindObject<UGameViewportClient>("GameViewportClient Transient.UAEGameEngine_1.GameViewportClient_1");
        sleep(1);
    }
    if (GameViewport) {
        return GameViewport;
    }
    return 0;
}


std::vector<AActor *> GetActors()
{
    auto World = GetWorld();
    if (!World)
        return std::vector<AActor *>();
    auto PersistentLevel = World->PersistentLevel;
    if (!PersistentLevel)
        return std::vector<AActor *>();
    auto Actors = *(TArray<AActor *> *)((uintptr_t)PersistentLevel + 0xA0);
    std::vector<AActor *> actors;
    for (int i = 0; i < Actors.Num(); i++)
    {
        auto Actor = Actors[i];
        if (Actor)
        {
            actors.push_back(Actor);
        }
    }
    return actors;
}

TNameEntryArray *GetGNames()
{
	return ((TNameEntryArray * (*)()) (g_UE4 + GNames_Offset))();
}

template <class T>
void GetAllActors(std::vector<T *> &Actors)
{
	UGameplayStatics *gGameplayStatics = (UGameplayStatics *)gGameplayStatics->StaticClass();
	auto GWorld = GetWorld();
	if (GWorld)
	{
		TArray<AActor *> Actors2;
		gGameplayStatics->GetAllActorsOfClass((UObject *)GWorld, T::StaticClass(), &Actors2);
		for (int i = 0; i < Actors2.Num(); i++)
		{
			Actors.push_back((T *)Actors2[i]);
		}
	}
}

FVector GetBoneLocationByName(ASTExtraPlayerCharacter *Actor, const char *BoneName) {
    return Actor->GetBonePos(BoneName, FVector());
}


#define PI 3.14159265358979323846f

FVector WorldToScreen(FVector world) //Auto Canvas_Map 
{
    if (!g_PlayerController->PlayerCameraManager)
        return {0, 0, 0};
    
    FMinimalViewInfo camViewInfo = g_PlayerController->PlayerCameraManager->CameraCache.POV;
    
    auto CameraLocation = camViewInfo.Location;
    auto CameraRotation = camViewInfo.Rotation;
    
    Matrix tempMatrix = RotatorToMatrix(CameraRotation);

    FVector vAxisX(tempMatrix.M[0][0], tempMatrix.M[0][1], tempMatrix.M[0][2]);
    FVector vAxisY(tempMatrix.M[1][0], tempMatrix.M[1][1], tempMatrix.M[1][2]);
    FVector vAxisZ(tempMatrix.M[2][0], tempMatrix.M[2][1], tempMatrix.M[2][2]);

    FVector vDelta = world - CameraLocation;

    FVector vTransformed(vDelta.Dot(vAxisY), vDelta.Dot(vAxisZ), vDelta.Dot(vAxisX));

    auto FovAngle = camViewInfo.FOV;
    float screenCenterX = g_screenWidth / 2;
    float screenCenterY = g_screenHeight / 2;

    float X = (screenCenterX + vTransformed.X * (screenCenterX / tanf(FovAngle * ((float)PI / 360.0f))) / vTransformed.Z);
    float Y = (screenCenterY - vTransformed.Y * (screenCenterX / tanf(FovAngle * ((float)PI / 360.0f))) / vTransformed.Z);
    float Z = vTransformed.Z;
    
    return {X, Y, Z};
}


// =========================================================================p=======================================================
bool isInsideFOV(int x, int y) {
    if (!Config["AIM::SIZE"])
        return true;

    int circle_x = g_screenWidth / 2;
    int circle_y = g_screenHeight / 2;
    int rad = Config["AIM::SIZE"];
    return (x - circle_x) * (x - circle_x) + (y - circle_y) * (y - circle_y) <= rad * rad;
}

// ================================================================================================================================
class FPSCounter {
protected:
    unsigned int m_fps;
    unsigned int m_fpscount;
    long m_fpsinterval;

public:
    FPSCounter() : m_fps(0), m_fpscount(0), m_fpsinterval(0) {
    }

    void update() {
        m_fpscount++;

        if (m_fpsinterval < time(0)) {
            m_fps = m_fpscount;

            m_fpscount = 0;
            m_fpsinterval = time(0) + 1;
        }
    }

    unsigned int get() const {
        return m_fps;
    }
};

FPSCounter fps;

auto GetTargetByCrosshairDistance() {
    ASTExtraPlayerCharacter *result = 0;
    float max = std::numeric_limits<float>::infinity();

    auto localPlayer = g_LocalPlayer;
    auto localController = g_PlayerController;

    auto Actors = GetActors();

    if (localPlayer && localController) {
        for (int i = 0; i < Actors.size(); i++) {
            auto Actor = Actors[i];
            if (isObjectInvalid(Actor))
                continue;
            if (Actor->IsA(ASTExtraPlayerCharacter::StaticClass())) {
                auto Player = (ASTExtraPlayerCharacter *) Actor;
                if (Player->PlayerKey == localPlayer->PlayerKey)
                    continue;

                if (Player->TeamID == localPlayer->TeamID)
                    continue;

                if (Player->bDead)
                    continue;

                if (Config["AIM::VISCHECK"]) {
                    if (!localController->LineOfSightTo(Player, {0, 0, 0}, true)) {
                        continue;
                    }
                }

                if (Config["AIM::KNOCKED"]) {
                    if (Player->Health == 0.0f)
                        continue;
                }

              
                auto Root = GetBoneLocationByName(Player, "Root");
                auto Head = GetBoneLocationByName(Player, "Head");

                FVector RootSc = WorldToScreen(Root);
                FVector HeadSc = WorldToScreen(Head);
                if (RootSc.Z > 0 && HeadSc.Z > 0) {
                    float height = abs(HeadSc.Y - RootSc.Y);
                    float width = height * 0.65f;

                    FVector middlePoint = {HeadSc.X + (width / 2), HeadSc.Y + (height / 2), 0};
                    if ((middlePoint.X >= 0 && middlePoint.X <= g_screenWidth) &&
                        (middlePoint.Y >= 0 && middlePoint.Y <= g_screenHeight)) {
                        FVector2D v2Middle = FVector2D((float) (g_screenWidth / 2),
                                                       (float) (g_screenHeight / 2));
                        FVector2D v2Loc = FVector2D(middlePoint.X, middlePoint.Y);

                        if (isInsideFOV((int) middlePoint.X, (int) middlePoint.Y)) {
                            float dist = FVector2D::Distance(v2Middle, v2Loc);

                            if (dist < max) {
                                max = dist;
                                result = Player;
                            }
                        }
                    }
                }
            }
        }
    }
    return result;
}
		

static bool isHead, isNeck, isPelvis, isLeftClavicle, isRightClavicle, 
            isLeftUpperArm, isLeftLowerArm, isLeftHand, isLeftThigh, 
            isLeftCalf, isLeftFoot, isRightUpperArm, isRightLowerArm, 
            isRightHand, isRightThigh, isRightCalf, isRightFoot, 
            isSpine1, isSpine2, isSpine3;

auto GetTargetByPussy()
{
    ASTExtraPlayerCharacter *result = 0;
    float max = std::numeric_limits<float>::infinity();
    auto Actors = GetActors();
    auto localPlayer = g_LocalPlayer;
    auto localController = g_PlayerController;
  /*  FVector ViewPosY{0, 0, 0};
    if (localPlayer) {
        ViewPosY = localPlayer->GetBoneLocationByName("Head");
        ViewPosY.Z += -15.0f;
    }
  */
    
    if (localPlayer)
    {
        for (int i = 0; i < Actors.size(); i++)
        {
            auto Actor = Actors[i];
            if (isObjectInvalid(Actor))
                continue;

            if (Actor->IsA(ASTExtraPlayerCharacter::StaticClass())){

                auto Player = (ASTExtraPlayerCharacter *)Actor;
              
				float Distance = localPlayer->GetDistanceTo(Player) / 100.0f;

                if (Distance > 400.0f)//if (Dist > 500.0f)
                    continue;

                if (Player->PlayerKey == localPlayer->PlayerKey)
                    continue;

                if (Player->TeamID == localPlayer->TeamID)
                    continue;

                if (Player->bDead)
                    continue;

                if (Player->bHidden)
                    continue;

                /*if (BtIgnoreKnocked)
                {
                    if (Player->Health == 0.0f)
                        continue;
                }

                if (BtVisCheck){
                
                if (!localController->LineOfSightTo(Player, {0, 0, 0}, true))
                        continue;
                }

                if (BtIgnoreBot)
                {
                  if (Player->bEnsure)
                        continue;
                }*/
                
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager,Player->GetBonePos("Head", {0, 0, 0}), false))//头
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager,Player->GetBonePos("neck_01", {0, 0, 0}), false))//Neck
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager,Player->GetBonePos("upperarm_r", {0, 0, 0}), false))//上面的肩膀右
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager,Player->GetBonePos("upperarm_l", {0, 0, 0}), false))//上面的肩膀左
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager,Player->GetBonePos("lowerarm_r", {0, 0, 0}), false))//上面的手臂右
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager,Player->GetBonePos("lowerarm_l", {0, 0, 0}), false))//上面的手臂左
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager,Player->GetBonePos("spine_03", {0, 0, 0}), false))//脊柱3
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager,Player->GetBonePos("spine_02", {0, 0, 0}), false))//脊柱2
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager,Player->GetBonePos("spine_01", {0, 0, 0}), false))//脊柱2
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager,Player->GetBonePos("pelvis", {0, 0, 0}), false))//骨盆
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager,Player->GetBonePos("thigh_l", {0, 0, 0}), false))//大腿左
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager,Player->GetBonePos("thigh_r", {0, 0, 0}), false))//大腿右
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager,Player->GetBonePos("calf_l", {0, 0, 0}), false))//小腿左
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager,Player->GetBonePos("calf_r", {0, 0, 0}), false))//小腿右
                continue;

                static bool isSelected = false;
                algorithm = 1;
                 

                
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager, Player->GetBonePos("Head", {0, 0, 0}),  false)) {//头
                 isHead = false;
                }else{
                 isHead = true;
                }
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager, Player->GetBonePos("pelvis", {0, 0, 0}),  false))
                {//骨盆
                 isPelvis = false;
                }else{
                 isPelvis = true;
                }
                                               
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager, Player->GetBonePos("neck_01", {0, 0, 0}),  false))
                {//Neck
                 isNeck = false;
                }else{
                 isNeck = true;
                }
                                                
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager, Player->GetBonePos("hand_l", {0, 0, 0}),  false))
                {//左手
                 isLeftHand = false;
                }else{
                 isLeftHand = true;
                }
                                                
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager, Player->GetBonePos("hand_r", {0, 0, 0}),  false))
                {//右手
                 isRightHand = false;
                }else{
                 isRightHand = true;
                }
                        
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager, Player->GetBonePos("foot_l", {0, 0, 0}),  false))
                {//左脚
                 isLeftFoot = false;
                }else{
                 isLeftFoot = true;
                }
                     
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager, Player->GetBonePos("foot_r", {0, 0, 0}),  false))
                {//右脚
                 isRightFoot = false;
                }else{
                 isRightFoot = true;
                }
                        
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager, Player->GetBonePos("calf_l", {0, 0, 0}),  false))
                {//LeftCalf
                 isLeftCalf = false;
                }else{
                 isLeftCalf = true;
                }
                        
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager, Player->GetBonePos("calf_r", {0, 0, 0}),  false))
                {//RightCalf
                 isRightCalf = false;
                }else{
                 isRightCalf = true;
                }
                        
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager, Player->GetBonePos("lowerarm_l", {0, 0, 0}),  false))
                {//LeftForearm
                 isLeftLowerArm = false;
                }else{
                 isLeftLowerArm = true;
                }
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager, Player->GetBonePos("lowerarm_r", {0, 0, 0}),  false))
                {//RightForearm
                 isRightLowerArm = false;
                }else{
                 isRightLowerArm = true;
                }
                        
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager, Player->GetBonePos("thigh_l", {0, 0, 0}),  false))
                {//左上臂
                 isLeftThigh = false;
                }else{
                 isLeftThigh = true;
                }
                if(!g_PlayerController->LineOfSightTo(g_PlayerController->PlayerCameraManager, Player->GetBonePos("thigh_r", {0, 0, 0}),  false))
                {//左上臂
                 isRightThigh = false;
                }else{
                 isRightThigh = true;
                }
                                                                                                
                if (!isSelected)
                if(isHead)
                {
                  algorithm = 1;
                  isSelected = true;
                }else{
                  isSelected = false;
                }
                if (!isSelected)
                if(isPelvis)
                {
                  algorithm = 2;
                  isSelected = true;
                }else{
                  isSelected = false;
                }
                if (!isSelected)
                if(isLeftCalf)
                {
                  algorithm = 3;
                  isSelected = true;
                }else{
                  isSelected = false;
                }
                if (!isSelected)
                if(isRightCalf)
                {
                  algorithm = 4;   
                  isSelected = true;
                }else{
                  isSelected = false;
                }
                if (!isSelected)
                if(isLeftLowerArm)
                {
                  algorithm = 5;
                  isSelected = true;
                }else{
                  isSelected = false;
                }
                if (!isSelected)
                if(isRightLowerArm)
                {
                  algorithm = 6;
                  isSelected = true;
                }else{
                  isSelected = false;
                }
                if (!isSelected)
                if(isLeftUpperArm)
                {
                  algorithm = 7;
                  isSelected = true;
                }else{
                  isSelected = false;
                }
                if (!isSelected)
                if(isRightUpperArm)
                {
                  algorithm = 8;
                  isSelected = true;
                }else{
                  isSelected = false;
                }
                if (!isSelected)
                if(isLeftThigh)
                {
                  algorithm = 9;
                  isSelected = true;
                }else{
                  isSelected = false;
                }
                if (!isSelected)
                if(isRightThigh)
                {
                  algorithm = 10;
                  isSelected = true;
                 }else{
                  isSelected = false;
                }
                if (!isSelected)
                if(isLeftFoot)
                {
                  algorithm = 11;
                  isSelected = true;
                }else{
                  isSelected = false;
                }
                if (!isSelected)
                if(isRightFoot)
                {
                  algorithm = 12;
                  isSelected = true;
                }else{
                  isSelected = false;
                }
                         
                auto Root = GetBoneLocationByName(Player, "Root");
                auto Head = GetBoneLocationByName(Player, "Head");

                FVector RootSc = WorldToScreen(Root);
                FVector HeadSc = WorldToScreen(Head);
                if (RootSc.Z > 0 && HeadSc.Z > 0) {
                    float height = abs(HeadSc.Y - RootSc.Y);
                    float width = height * 0.65f;

                    FVector middlePoint = {HeadSc.X + (width / 2), HeadSc.Y + (height / 2), 0};
                    if ((middlePoint.X >= 0 && middlePoint.X <= width) && (middlePoint.Y >= 0 && middlePoint.Y <= height)) {
                        FVector2D v2Middle = FVector2D((float) (width / 2), (float) (height / 2));
                        FVector2D v2Loc = FVector2D(middlePoint.X, middlePoint.Y);

                        float dist = FVector2D::Distance(v2Middle, v2Loc);

                        if (dist < max) {
                            max = dist;
                            result = Player;
                            }
                        }
                    }
                }
            }
        }
    return result;
}



// ================================================================================================================================
FRotator ToRotator(FVector local, FVector target) {
    FVector rotation = UKismetMathLibrary::Subtract_VectorVector(local, target);

    float hyp = sqrt(rotation.X * rotation.X + rotation.Y * rotation.Y);

    FRotator newViewAngle = {0};
    newViewAngle.Pitch = -atan(rotation.Z / hyp) * (180.f / (float) 3.14159265358979323846);
    newViewAngle.Yaw = atan(rotation.Y / rotation.X) * (180.f / (float) 3.14159265358979323846);
    newViewAngle.Roll = (float) 0.f;

    if (rotation.X >= 0.f)
        newViewAngle.Yaw += 180.0f;

    return newViewAngle;
}

// =================BULLETRACK===============================================================================================================
/*
void (*orig_shoot_event)(USTExtraShootWeaponComponent *thiz, FVector start, FRotator rot,
                         void *unk1, int unk2) = 0;

void shoot_event(USTExtraShootWeaponComponent *thiz, FVector start, FRotator rot,
                 ASTExtraShootWeapon *weapon, int unk1) {
    if (Config["AIM::AIMBULLET"]) {
        auto localPlayer = g_LocalPlayer;
        ASTExtraPlayerCharacter *Target = 0;
        Target = GetTargetByCrosshairDistance();
        if (Target) {
            bool triggerOk = false;
            if (!Config["AIM::TRIGGER"] == 0) {
                if (Config["AIM::TRIGGER"] == 1) {
                    triggerOk = localPlayer->bIsWeaponFiring;
                } else if (Config["AIM::TRIGGER"] == 2) {
                    triggerOk = localPlayer->bIsGunADS;
                } else if (Config["AIM::TRIGGER"] == 3) {
                    triggerOk = localPlayer->bIsWeaponFiring || localPlayer->bIsGunADS;
                }
            } else
                triggerOk = true;
            if (triggerOk) {
                FVector targetAimPos = GetBoneLocationByName(Target, "(Target, "Head");
                if (Config["AIM::LOCATION"] == 1) {
                    targetAimPos = GetBoneLocationByName(Target, "Head");
                    targetAimPos.Z -= 35.f;
                }
                UShootWeaponEntity *ShootWeaponEntityComponent = thiz->ShootWeaponEntityComponent;
                if (ShootWeaponEntityComponent) {
                    if (Config["AIM::PREDICTION"]) {
                        ASTExtraVehicleBase *CurrentVehicle = Target->CurrentVehicle;
                        if (CurrentVehicle) {
                            FVector LinearVelocity =
                                    CurrentVehicle->ReplicatedMovement.LinearVelocity;

                            float dist = g_LocalPlayer->GetDistanceTo(Target);

                            auto timeToTravel = dist / ShootWeaponEntityComponent->BulletFireSpeed;

                            targetAimPos = UKismetMathLibrary::Add_VectorVector(targetAimPos,
                                                                                UKismetMathLibrary::
                                                                                Multiply_VectorFloat
                                                                                        (LinearVelocity,
                                                                                         timeToTravel));


                            targetAimPos.Z += LinearVelocity.Z * timeToTravel +
                                              0.5 * 0.5 * timeToTravel * timeToTravel;

                        } else {
                            FVector Velocity = Target->GetVelocity();
                            float dist = g_LocalPlayer->GetDistanceTo(Target);
                            auto timeToTravel = dist / ShootWeaponEntityComponent->BulletFireSpeed;


                            targetAimPos = UKismetMathLibrary::Add_VectorVector(targetAimPos,
                                                                                UKismetMathLibrary::
                                                                                Multiply_VectorFloat
                                                                                        (Velocity,
                                                                                         timeToTravel));

                            targetAimPos.Z += Velocity.Z * timeToTravel +
                                              0.5 * 0.5 * timeToTravel * timeToTravel;
                        }
                    }
                    FVector fDir =
                            g_PlayerController->PlayerCameraManager->CameraCache.POV.Location;
                    rot = ToRotator(fDir, targetAimPos);
                }
            }
        }
    }
    return orig_shoot_event(thiz, start, rot, weapon, unk1);
}
*/

void (*Orig_Shoot_Event)(USTExtraShootWeaponComponent *thiz, FVector start, FRotator rot, void *unk1, int unk2, float a6, float a7, float a8) = 0;
void Hook_Shoot_Event(USTExtraShootWeaponComponent *thiz, FVector start, FRotator rot, ASTExtraShootWeapon *weapon, int unk1, float a6, float a7, float a8){
    if (Config["AIM::AIMBULLET"]) {
        ASTExtraPlayerCharacter *Target = GetTargetByPussy();
        if (Target){
			if(g_LocalPlayer->bIsWeaponFiring){
			auto CurrentWeapon = (ASTExtraShootWeapon *)g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated;
            if (CurrentWeapon){
            CurrentWeapon->ShootMode = EShootWeaponShootMode::SWST_TraceTarget;  
          FVector targetAimPos;
                       if(algorithm == 0) {
                        targetAimPos=GetBoneLocationByName(Target, "Head");
                       } else if(algorithm == 1) {
                        targetAimPos = GetBoneLocationByName(Target, "Head");
                       }else if(algorithm == 2){
                        targetAimPos = GetBoneLocationByName(Target, "pelvis");//锁骨
                       }else if(algorithm == 3){
                        targetAimPos = GetBoneLocationByName(Target, "calf_l");//LeftCalf
                       }else if(algorithm == 4){
                        targetAimPos = GetBoneLocationByName(Target, "calf_r");//RightCalf
                       }else if(algorithm == 5){
                        targetAimPos = GetBoneLocationByName(Target, "lowerarm_l");//LeftForearm
                       }else if(algorithm == 6){
                        targetAimPos = GetBoneLocationByName(Target, "lowerarm_r");//RightForearm
                       }else if(algorithm == 7){
                        targetAimPos = GetBoneLocationByName(Target, "upperarm_l");//左上臂
                       }else if(algorithm == 8){
                        targetAimPos = GetBoneLocationByName(Target, "upperarm_r");//右上臂
                       }else if(algorithm == 9) {
                        targetAimPos = GetBoneLocationByName(Target, "thigh_l");//LeftThigh
                       }else if(algorithm == 10) {
                        targetAimPos = GetBoneLocationByName(Target, "thigh_r");//RightThigh
                       }else if(algorithm == 11) {
                        targetAimPos = GetBoneLocationByName(Target, "foot_l");//左脚
                       }else if(algorithm == 12){
                        targetAimPos = GetBoneLocationByName(Target, "foot_r");//右脚
                       }
                       targetAimPos.Z -= -10.0f;
			FRotator sex = ToRotator(start, targetAimPos);
            return Orig_Shoot_Event(thiz, targetAimPos, sex, weapon, unk1, a6, a7, a8);
        }
    }
 }
}
    return Orig_Shoot_Event(thiz, start, rot, weapon, unk1, a6, a7, a8);
}



Canvas *m_Canvas = nullptr;

void
native_onCanvasDraw(JNIEnv *env, jobject thiz, jobject canvas, jint screenWidth,
                    jint screenHeight, jfloat screenDensity) {
    static Canvas *m_Canvas = 0;
    if (!m_Canvas) {
        m_Canvas = new Canvas(env, screenWidth, screenHeight, screenDensity);
    }

    m_Canvas->UpdateCanvas(canvas);

    g_screenWidth = screenWidth;
    g_screenHeight = screenHeight;

    if (Config["AIM::AIMBULLET"] == 1) {
        m_Canvas->drawCircle(screenWidth / 2, screenHeight / 2, Config["AIM::SIZE"], 2.0f, false,
                             ARGB(255, 000, 255, 000));
    }
/*
     if (!bValid) {
         exit(-1);
     }
     */
     if (!bScanPatternCompleted) return;

    ASTExtraPlayerCharacter *localPlayer = 0;
    ASTExtraPlayerController *localController = 0;


    std::string sFPS = "FPS : ";
    sFPS += std::to_string(fps.get());

    m_Canvas->drawText(sFPS.c_str(), screenWidth / 50, 180, 12.f, Align::LEFT, YELLOW, BLACK);

std::string Version = "Telegram -> @By_Kaushik";
float posX = screenWidth / 2.0f;
float posY = screenHeight * 0.1f; // 10% from top
m_Canvas->drawText(Version.c_str(), posX, posY, 16.2f, Align::CENTER, RED, BLACK);
	

    int totalEnemies = 0, totalBots = 0;

    auto Actors = GetActors();
    for (int i = 0; i < Actors.size(); i++) {
        auto Actor = Actors[i];
        if (isObjectInvalid(Actor))
            continue;

        if (Actor->IsA(ASTExtraPlayerController::StaticClass())) {
            localController = (ASTExtraPlayerController *) Actor;
            break;
        }
    }

    if (localController) {
        for (int i = 0; i < Actors.size(); i++) {
            auto Actor = Actors[i];
            if (isObjectInvalid(Actor))
                continue;

            if (Actor->IsA(ASTExtraPlayerCharacter::StaticClass())) {
                if (((ASTExtraPlayerCharacter *) Actor)->PlayerKey == localController->PlayerKey) {
                    localPlayer = (ASTExtraPlayerCharacter *) Actor;
                    break;
                }
            }
        }

        if (localPlayer) {
            if (localPlayer->PartHitComponent) {
                auto ConfigCollisionDistSqAngles =
                        localPlayer->PartHitComponent->ConfigCollisionDistSqAngles;
                for (int j = 0; j < ConfigCollisionDistSqAngles.Num(); j++) {
                    ConfigCollisionDistSqAngles[j].Angle = 180.0f;
                }
                localPlayer->PartHitComponent->ConfigCollisionDistSqAngles =
                        ConfigCollisionDistSqAngles;
            }
/*
            if (Config["AIM::AIMBULLET"]) {
                auto WeaponManagerComponent = localPlayer->WeaponManagerComponent;
                if (WeaponManagerComponent) {
                    auto propSlot = WeaponManagerComponent->GetCurrentUsingPropSlot();
                    if ((int) propSlot.GetValue() >= 1 && (int) propSlot.GetValue() <= 3) {
                        auto CurrentWeaponReplicated =
                                (ASTExtraShootWeapon *) WeaponManagerComponent->
                                        CurrentWeaponReplicated;
                        if (CurrentWeaponReplicated) {
                            auto ShootWeaponComponent =
                                    CurrentWeaponReplicated->ShootWeaponComponent;
                            if (ShootWeaponComponent) {
                                int shoot_event_idx = 168;
                                auto Vtable = (void **) ShootWeaponComponent->VTable;
                                if (Vtable && (Vtable[shoot_event_idx] != shoot_event)) {
                                    orig_shoot_event =
                                            decltype(orig_shoot_event)(Vtable[shoot_event_idx]);
                                    Vtable[shoot_event_idx] = (void *) shoot_event;
                                }
                            }
                        }
                    }
                }
            }*/

             if (Config["MEMORY::RECOIL"] || Config["MEMORY::SMAL"]) {
                auto WeaponManagerComponent = localPlayer->WeaponManagerComponent;
                if (WeaponManagerComponent) {
                    auto Slot = WeaponManagerComponent->GetCurrentUsingPropSlot();
                    if ((int) Slot.GetValue() >= 1 && (int) Slot.GetValue() <= 3) {
                        auto CurrentWeaponReplicated =
                                (ASTExtraShootWeapon *) WeaponManagerComponent->
                                        CurrentWeaponReplicated;
                        if (CurrentWeaponReplicated) {
                            auto ShootWeaponEntityComp =
                                    CurrentWeaponReplicated->ShootWeaponEntityComp;
                            auto ShootWeaponEffectComp =
                                    CurrentWeaponReplicated->ShootWeaponEffectComp;
                            if (ShootWeaponEntityComp && ShootWeaponEffectComp) {
                                if (Config["MEMORY::RECOIL"]) {
                                    ShootWeaponEntityComp->AccessoriesVRecoilFactor = 0.1f;
                                    ShootWeaponEntityComp->AccessoriesHRecoilFactor = 0.2f;
									ShootWeaponEntityComp->bRecordHitDetail = false;
                                    if (Config["MEMORY::SMAL"]) {
                                  ShootWeaponEntityComp->GameDeviationFactor = 0.40f;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            // ================================================================================================================================

            for (int i = 0; i < Actors.size(); i++) {
                auto Actor = Actors[i];
                if (isObjectInvalid(Actor))
                    continue;

                if (Actor->IsA(ASTExtraPlayerCharacter::StaticClass())) {
                    auto Player = (ASTExtraPlayerCharacter *) Actor;

                    float Distance = localPlayer->GetDistanceTo(Player) / 100.0f;
                    if (Distance > 500.0f)
                        continue;

                    if (Player->PlayerKey == localController->PlayerKey)
                        continue;

                    if (Player->TeamID == localController->TeamID)
                        continue;

                    if (Player->bDead)
                        continue;

                    if (!Player->RootComponent)
                        continue;

                    if (Player->bEnsure)
                        totalBots++;
                    else
                        totalEnemies++;

                    FVector Head = GetBoneLocationByName(Player, "Head");
                    FVector Root = GetBoneLocationByName(Player, "Root");


                    FVector HeadSc = WorldToScreen(Head);
                    FVector RootSc = WorldToScreen(Root);

                   bool IsVisible = localController->LineOfSightTo(Player, {0, 0, 0}, true);
				   
                   auto ColorVisible = IsVisible ? GREEN : RED;

												

                   if (HeadSc.Z > 0 && RootSc.Z > 0) {

                        if (Config["ESP::LINE"]) {
                            m_Canvas->drawLine(screenWidth / 2, 65, HeadSc.X, HeadSc.Y, 2.5f, ColorVisible);
                        }

                        if (Config["ESP::SKELETON"]) {
                            // ESP SKELETON
                            auto neck = WorldToScreen(GetBoneLocationByName(Player, "Head"));
                            auto chest = WorldToScreen(GetBoneLocationByName(Player, "neck_01"));
                            auto pelvis = WorldToScreen(GetBoneLocationByName(Player, "pelvis"));
                            auto rShoulder =
                                    WorldToScreen(GetBoneLocationByName(Player, "upperarm_r"));
                            auto lShoulder =
                                    WorldToScreen(GetBoneLocationByName(Player, "upperarm_l"));
                            auto lElbow =
                                    WorldToScreen(GetBoneLocationByName(Player, "lowerarm_l"));
                            auto rElbow =
                                    WorldToScreen(GetBoneLocationByName(Player, "lowerarm_r"));
                            auto lWrist = WorldToScreen(GetBoneLocationByName(Player, "hand_l"));
                            auto rWrist = WorldToScreen(GetBoneLocationByName(Player, "hand_r"));
                            auto lThigh = WorldToScreen(GetBoneLocationByName(Player, "thigh_l"));
                            auto rThigh = WorldToScreen(GetBoneLocationByName(Player, "thigh_r"));
                            auto lKnee = WorldToScreen(GetBoneLocationByName(Player, "calf_l"));
                            auto rKnee = WorldToScreen(GetBoneLocationByName(Player, "calf_r"));
                            auto lAnkle = WorldToScreen(GetBoneLocationByName(Player, "foot_l"));
                            auto rAnkle = WorldToScreen(GetBoneLocationByName(Player, "foot_r"));

                            if (neck.Z < 1 || chest.Z < 1 || pelvis.Z < 1 || lShoulder.Z < 1 ||
                                rShoulder.Z < 1 || lElbow.Z < 1 || rElbow.Z < 1 || lWrist.Z < 1 ||
                                rWrist.Z < 1 || lThigh.Z < 1 || rThigh.Z < 1 || lKnee.Z < 1 ||
                                rKnee.Z < 1 || lAnkle.Z < 1 || rAnkle.Z < 1)
                                continue;

                            m_Canvas->drawLine(neck.X, neck.Y, chest.X, chest.Y, 2.5f, ColorVisible);
                            m_Canvas->drawLine(chest.X, chest.Y, pelvis.X, pelvis.Y, 2.5f, ColorVisible);
                            m_Canvas->drawLine(chest.X, chest.Y, lShoulder.X, lShoulder.Y, 2.5f,
                                               ColorVisible);
                            m_Canvas->drawLine(chest.X, chest.Y, rShoulder.X, rShoulder.Y, 2.5f,
                                               ColorVisible);
                            m_Canvas->drawLine(lShoulder.X, lShoulder.Y, lElbow.X, lElbow.Y, 2.5f,
                                               ColorVisible);
                            m_Canvas->drawLine(rShoulder.X, rShoulder.Y, rElbow.X, rElbow.Y, 2.5f,
                                               ColorVisible);
                            m_Canvas->drawLine(lElbow.X, lElbow.Y, lWrist.X, lWrist.Y, 2.5f, ColorVisible);
                            m_Canvas->drawLine(rElbow.X, rElbow.Y, rWrist.X, rWrist.Y, 2.5f, ColorVisible);
                            m_Canvas->drawLine(pelvis.X, pelvis.Y, lThigh.X, lThigh.Y, 2.5f, ColorVisible);
                            m_Canvas->drawLine(pelvis.X, pelvis.Y, rThigh.X, rThigh.Y, 2.5f, ColorVisible);
                            m_Canvas->drawLine(lThigh.X, lThigh.Y, lKnee.X, lKnee.Y, 2.5f, ColorVisible);
                            m_Canvas->drawLine(rThigh.X, rThigh.Y, rKnee.X, rKnee.Y, 2.5f, ColorVisible);
                            m_Canvas->drawLine(lKnee.X, lKnee.Y, lAnkle.X, lAnkle.Y, 2.5f, ColorVisible);
                            m_Canvas->drawLine(rKnee.X, rKnee.Y, rAnkle.X, rAnkle.Y, 2.5f, ColorVisible);
                        }
						
                        // ESP BOX
                        if (Config["ESP::BOX"]) {
                            float boxHeight = abs(HeadSc.Y - RootSc.Y);
                            float boxWidth = boxHeight * 0.50f;
                            FVector2D vBox = {HeadSc.X - (boxWidth / 2), HeadSc.Y};
                            m_Canvas->drawBorder(vBox.X, vBox.Y, boxWidth, boxHeight, 2.5f, ColorVisible);
                        }

                        if (Config["ESP::NAME"] || Config["ESP::DIST"] || Config["ESP::HEALTH"]) {
                            float boxW = m_Canvas->scaleSize(100.f);
                            float boxH = boxW * 0.10f;

                            Vector3 pos = {HeadSc.X - (boxW / 2), HeadSc.Y - (boxH * 2)};
                            // ESP HEALTH
                            if (Config["ESP::HEALTH"]) {
                                int CurHP =
                                        (int) std::max(0,
                                                       std::min((int) Player->Health,
                                                                (int) Player->HealthMax));
                                int MaxHP = (int) Player->HealthMax;

                                long curHP_Color = ARGB(255, 0, 255, 0);

                                if (Player->Health == 0.0f && !Player->bDead) {
                                    curHP_Color = ARGB(255, 255, 0, 0);

                                    CurHP = Player->NearDeathBreath;
                                    if (Player->NearDeatchComponent) {
                                        MaxHP = Player->NearDeatchComponent->BreathMax;
                                    }
                                }

                                float hpH = boxH * 0.25f;
                                m_Canvas->drawBox(pos.X, pos.Y + boxH, (boxW * CurHP) / MaxHP, hpH,
                                                  curHP_Color);
                                m_Canvas->drawBorder(pos.X, pos.Y + boxH, boxW, hpH,
                                                     m_Canvas->scaleSize(0.5f), 0xFF000000);
                                pos.Y -= hpH;
                            }
                            // ESP INFO
                            if (Config["ESP::NAME"] || Config["ESP::DISTANCE"]) {
                                m_Canvas->drawBox(pos.X, pos.Y, boxW, boxH, 0x88000000);
                                m_Canvas->drawBorder(pos.X, pos.Y, boxW, boxH,
                                                     m_Canvas->scaleSize(0.5f), 0xFF000000);

                                std::wstring ws;
                                if (Config["ESP::NAME"]) {
                                    if (Player->bEnsure)
                                        ws += L"Bot";
                                    else if (Player->PlayerName.IsValid())
                                        ws += Player->PlayerName.ToWString();
                                }
                                if (Config["ESP::NAME"]) {
                                    Rect *nameSize =
                                            m_Canvas->getTextBounds(ws.c_str(), 0, ws.size());
                                    m_Canvas->drawText(ws.c_str(), pos.X + (boxW * 0.025f),
                                                       pos.Y + boxH -
                                                       ((float) nameSize->getHeight() / 4),
                                                       m_Canvas->scaleSize(3.0f), Align::LEFT,
                                                       ARGB(255, 248, 252, 0));
                                }

                                if (Config["ESP::DISTANCE"]) {
                                    std::wstring ws;
                                    ws += std::to_wstring((int) Distance);
                                    ws += L"M";

                                    Rect *distSize =
                                            m_Canvas->getTextBounds(ws.c_str(), 0, ws.size());
                                    m_Canvas->drawText(ws.c_str(), pos.X + boxW - (boxW * 0.025f),
                                                       pos.Y + boxH -
                                                       ((float) distSize->getHeight() / 4),
                                                       m_Canvas->scaleSize(3.0f), Align::RIGHT,
                                                       0xFFFFFFFF);
                                }
                            }
                        }
                    }
                }
	

	
				/*

                if (Config["ESP::GRENADE"]) {
                    if (Actor->IsA(ASTExtraGrenadeBase::StaticClass())) {
                        auto Grenade = (ASTExtraGrenadeBase *) Actor;
                        auto RootComponent = Grenade->RootComponent;
                        if (!RootComponent)
                            continue;

                        float Distance = Grenade->GetDistanceTo(localPlayer) / 100.f;
                        if (Distance <= 500.f) {
                            m_Canvas->drawText("Warning! Grenade near you!", screenWidth / 2, 350,
                                               10.5f, Align::CENTER, RED);

                            FVector Location = WorldToScreen(RootComponent->RelativeLocation);
                            if (Location.Z > 0) {
                                m_Canvas->drawText("GRENADE", Location.X, Location.Y, 10.5f,
                                                   Align::CENTER, RED);
                            }
                        }
                    }
                }*/
				
				
				
                if (Config["ESP::VEHICLE"]) {
                    if (Actor->IsA(ASTExtraVehicleBase::StaticClass())) {
                        auto Vehicle = (ASTExtraVehicleBase *) Actor;

                        auto RootComponent = Vehicle->RootComponent;
                        if (!RootComponent)
                            continue;

                        float Distance = Vehicle->GetDistanceTo(localPlayer) / 100.f;
                        if (Distance <= 500.f) {
                            FVector Location = WorldToScreen(RootComponent->RelativeLocation);
                            if (Location.Z > 0) {
                                std::string s = GetVehicleName(Vehicle);
                                s += " - ";
                                s += std::to_string((int) Distance);
                                s += "M";
                                m_Canvas->drawText(s.c_str(), Location.X, Location.Y, 8.f,
                                                   Align::CENTER, YELLOW, BLACK);
                            }
                        }
                    }
                }

                if (Actor->IsA(APickUpWrapperActor::StaticClass())) {
                    auto PickUp = (APickUpWrapperActor *) Actor;
                    if (Tools::IsPtrValid(PickUp)) {
                        if (itemConfig[PickUp->DefineID.TypeSpecificID]) {

                            auto RootComponent = PickUp->RootComponent;
                            if (!RootComponent)
                                continue;

                            float Distance = PickUp->GetDistanceTo(localPlayer) / 100.f;
                            if (Distance <= 500.f) {
                                std::string s;
                                int tc = 0xFF000000, oc = 0xFFFFFFFF;

                                for (auto &e: itemData) {
                                    if (e["itemId"] == PickUp->DefineID.TypeSpecificID) {
                                        s = e["itemName"].get<std::string>();
                                        tc = strtoul(e["itemTextColor"].get<std::string>
                                                ().c_str(), 0, 16);
                                        oc = strtoul(e["itemOutlineColor"].get<std::string>
                                                ().c_str(), 0, 16);
                                        break;
                                    }
                                }

                                s += " - ";
                                s += std::to_string((int) Distance);
                                s += "M";

                                FVector Location = WorldToScreen(RootComponent->RelativeLocation);
                                if (Location.Z > 0) {
                                    m_Canvas->drawText(s.c_str(), Location.X, Location.Y, 7.5f,
                                                       Align::CENTER, tc, oc);
                                }
                            }
                        }
                    }
                }
				

                if (Config["ESP::LOOT_BOX"]) {
                    if (Actor->IsA(APickUpListWrapperActor::StaticClass())) {
                        auto PickUpList = (APickUpListWrapperActor *) Actor;

                        auto RootComponent = PickUpList->RootComponent;
                        if (!RootComponent)
                            continue;

                        auto PickUpDataList2 = *(TArray<FPickUpItemData> *) ((uintptr_t)
                                                                                     PickUpList +
                                                                             0x828);

                        float Distance = PickUpList->GetDistanceTo(localPlayer) / 100.f;

                        if (Distance <= 500.f) {
                            std::string s = "Loot Box ";
                            s += " - ";
                            s += std::to_string((int) Distance);
                            s += "M";

                            FVector Location = WorldToScreen(RootComponent->RelativeLocation);
                            if (Location.Z > 0) {
                                m_Canvas->drawText(s.c_str(), Location.X, Location.Y, 7.5f,
                                                   Align::LEFT, BROWN, BLACK);

                                if (Config["ESP::LOOT_BOX_ITEMS"]) {
                                    if (Distance <=
                                        (float) (Config["ESP::LOOT_BOX_MAX_DISTANCE"])) {
                                        Rect *m_Rect = m_Canvas->getTextBounds(s.c_str(), 0,
                                                                               s.size());
                                        float posY = Location.Y - (m_Rect->getHeight() * 1.5f);
                                        for (int j = 0; j < PickUpDataList2.Num(); j++) {
                                            std::vector<std::string> s2;
                                            long tc = 0xFF000000, oc = 0xFFFFFFFF;

                                            for (auto &e: itemData) {
                                                if (e["itemId"] ==
                                                    PickUpDataList2[j].ID.TypeSpecificID) {
                                                    s2.push_back(e["itemName"].get<std::string>
                                                            ());
                                                    tc = strtoul(e["itemTextColor"].get<
                                                            std::string>().c_str(), 0, 16);
                                                    oc = strtoul(e["itemOutlineColor"].get<
                                                            std::string>().c_str(), 0, 16);
                                                    break;
                                                }
                                            }
                                            if (!s2.empty()) {
                                                if (PickUpDataList2[j].Count > 1) {
                                                    s2.push_back(" * ");
                                                    s2.push_back(std::
                                                                 to_string(PickUpDataList2[j].
                                                            Count));
                                                }

                                                std::string s3;
                                                for (auto &s4: s2) {
                                                    s3 += s4;
                                                }

                                                m_Canvas->drawText(s2, Location.X, posY, 7.0f,
                                                                   Align::LEFT,
                                                                   {
                                                                           tc, LIME, LIME},
                                                                   {
                                                                           oc, BLACK, BLACK}
                                                );
                                                m_Rect = m_Canvas->getTextBounds(s3.c_str(), 0,
                                                                                 s3.size());
                                                posY -= m_Rect->getHeight() * 1.25f;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
	
		
		g_LocalPlayer = localPlayer;
        g_PlayerController = localController;
    }
    fps.update();
}

// ================================================================================================================================
// //
const char *GetAndroidID(JNIEnv *env, jobject context) {
    jclass contextClass = env->FindClass(    /* android/content/Context */
            StrEnc("`L+&0^[S+-:J^$,r9q92(as",
                   "\x01\x22\x4F\x54\x5F\x37\x3F\x7C\x48\x42\x54\x3E\x3B\x4A\x58\x5D\x7A\x1E\x57\x46\x4D\x19\x07",
                   23).c_str());
    jmethodID getContentResolverMethod = env->GetMethodID(contextClass,    /* getContentResolver */
                                                          StrEnc("E8X\\7r7ys_Q%JS+L+~",
                                                                 "\x22\x5D\x2C\x1F\x58\x1C\x43\x1C\x1D\x2B\x03\x40\x39\x3C\x47\x3A\x4E\x0C",
                                                                 18).c_str(),    /* ()Landroid/content/ContentResolver; */
                                                          StrEnc
                                                                  ("8^QKmj< }5D:9q7f.BXkef]A*GYLNg}B!/L",
                                                                   "\x10\x77\x1D\x2A\x03\x0E\x4E\x4F\x14\x51\x6B\x59\x56\x1F\x43\x03\x40\x36\x77\x28\x0A\x08\x29\x24\x44\x33\x0B\x29\x3D\x08\x11\x34\x44\x5D\x77",
                                                                   35).c_str());
    jclass settingSecureClass = env->FindClass(    /* android/provider/Settings$Secure */
            StrEnc("T1yw^BCF^af&dB_@Raf}\\FS,zT~L(3Z\"",
                   "\x35\x5F\x1D\x05\x31\x2B\x27\x69\x2E\x13\x09\x50\x0D\x26\x3A\x32\x7D\x32\x03\x09\x28\x2F\x3D\x4B\x09\x70\x2D\x29\x4B\x46\x28\x47",
                   32).c_str());
    jmethodID getStringMethod = env->GetStaticMethodID(settingSecureClass,    /* getString */
                                                       StrEnc("e<F*J5c0Y",
                                                              "\x02\x59\x32\x79\x3E\x47\x0A\x5E\x3E",
                                                              9).c_str(),    /* (Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String; */
                                                       StrEnc
                                                               ("$6*%R*!XO\"m18o,0S!*`uI$IW)l_/_knSdlRiO1T`2sH|Ouy__^}%Y)JsQ:-\"(2_^-$i{?H",
                                                                "\x0C\x7A\x4B\x4B\x36\x58\x4E\x31\x2B\x0D\x0E\x5E\x56\x1B\x49\x5E\x27\x0E\x69\x0F\x1B\x3D\x41\x27\x23\x7B\x09\x2C\x40\x33\x1D\x0B\x21\x5F\x20\x38\x08\x39\x50\x7B\x0C\x53\x1D\x2F\x53\x1C\x01\x0B\x36\x31\x39\x46\x0C\x15\x43\x2B\x05\x30\x15\x41\x43\x46\x55\x70\x0D\x59\x56\x00\x15\x58\x73",
                                                                71).c_str());

    auto obj = env->CallObjectMethod(context, getContentResolverMethod);
    auto str = (jstring) env->CallStaticObjectMethod(settingSecureClass, getStringMethod, obj,
                                                     env->NewStringUTF(    /* android_id */
                                                             StrEnc("ujHO)8OfOE",
                                                                    "\x14\x04\x2C\x3D\x46\x51\x2B\x39\x26\x21",
                                                                    10).c_str()));
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceModel(JNIEnv *env) {
    jclass buildClass = env->FindClass( /* android/os/Build */ StrEnc("m5I{GKGWBP-VOxkA",
                                                                      "\x0C\x5B\x2D\x09\x28\x22\x23\x78\x2D\x23\x02\x14\x3A\x11\x07\x25",
                                                                      16).c_str());
    jfieldID modelId = env->GetStaticFieldID(buildClass, /*MODEL*/
                                             StrEnc("|}[q:", "\x31\x32\x1F\x34\x76",
                                                    5).c_str(),    /* Ljava/lang/String; */
                                             StrEnc(".D:C:ETZ1O-Ib&^h.Y",
                                                    "\x62\x2E\x5B\x35\x5B\x6A\x38\x3B\x5F\x28\x02\x1A\x16\x54\x37\x06\x49\x62",
                                                    18).c_str());

    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceBrand(JNIEnv *env) {
    jclass buildClass = env->FindClass( /* android/os/Build */ StrEnc("0iW=2^>0zTRB!B90",
                                                                      "\x51\x07\x33\x4F\x5D\x37\x5A\x1F\x15\x27\x7D\x00\x54\x2B\x55\x54",
                                                                      16).c_str());
    jfieldID modelId = env->GetStaticFieldID(buildClass, /*BRAND*/
                                             StrEnc("@{[FP", "\x02\x29\x1A\x08\x14",
                                                    5).c_str(),    /* Ljava/lang/String; */
                                             StrEnc(".D:C:ETZ1O-Ib&^h.Y",
                                                    "\x62\x2E\x5B\x35\x5B\x6A\x38\x3B\x5F\x28\x02\x1A\x16\x54\x37\x06\x49\x62",
                                                    18).c_str());

    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetPackageName(JNIEnv *env, jobject context) {
    jclass contextClass = env->FindClass(    /* android/content/Context */
            StrEnc("`L+&0^[S+-:J^$,r9q92(as",
                   "\x01\x22\x4F\x54\x5F\x37\x3F\x7C\x48\x42\x54\x3E\x3B\x4A\x58\x5D\x7A\x1E\x57\x46\x4D\x19\x07",
                   23).c_str());
    jmethodID getPackageNameId = env->GetMethodID(contextClass,    /* getPackageName */
                                                  StrEnc("YN4DaP)!{wRGN}",
                                                         "\x3E\x2B\x40\x14\x00\x33\x42\x40\x1C\x12\x1C\x26\x23\x18",
                                                         14).c_str(),    /* ()Ljava/lang/String; */
                                                  StrEnc("VnpibEspM(b]<s#[9cQD",
                                                         "\x7E\x47\x3C\x03\x03\x33\x12\x5F\x21\x49\x0C\x3A\x13\x20\x57\x29\x50\x0D\x36\x7F",
                                                         20).c_str());

    auto str = (jstring) env->CallObjectMethod(context, getPackageNameId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceUniqueIdentifier(JNIEnv *env, const char *uuid) {
    jclass uuidClass = env->FindClass(    /* java/util/UUID */
            StrEnc("B/TxJ=3BZ_]SFx",
                   "\x28\x4E\x22\x19\x65\x48\x47\x2B\x36\x70\x08\x06\x0F\x3C",
                   14).c_str());

    auto len = strlen(uuid);

    jbyteArray myJByteArray = env->NewByteArray(len);
    env->SetByteArrayRegion(myJByteArray, 0, len, (jbyte *) uuid);

    jmethodID nameUUIDFromBytesMethod = env->GetStaticMethodID(uuidClass,    /* nameUUIDFromBytes */
                                                               StrEnc("P6LV|'0#A+zQmoat,",
                                                                      "\x3E\x57\x21\x33\x29\x72\x79\x67\x07\x59\x15\x3C\x2F\x16\x15\x11\x5F",
                                                                      17).c_str(),    /* ([B)Ljava/util/UUID; */
                                                               StrEnc("sW[\"Q[W3,7@H.vT0) xB",
                                                                      "\x5B\x0C\x19\x0B\x1D\x31\x36\x45\x4D\x18\x35\x3C\x47\x1A\x7B\x65\x7C\x69\x3C\x79",
                                                                      20).c_str());
    jmethodID toStringMethod = env->GetMethodID(uuidClass, /* toString */ StrEnc("2~5292eW",
                                                                                 "\x46\x11\x66\x46\x4B\x5B\x0B\x30",
                                                                                 8).c_str(),    /* ()Ljava/lang/String; */
                                                StrEnc("P$BMc' #j?<:myTh_*h0",
                                                       "\x78\x0D\x0E\x27\x02\x51\x41\x0C\x06\x5E\x52\x5D\x42\x2A\x20\x1A\x36\x44\x0F\x0B",
                                                       20).c_str());

    auto obj = env->CallStaticObjectMethod(uuidClass, nameUUIDFromBytesMethod, myJByteArray);
    auto str = (jstring) env->CallObjectMethod(obj, toStringMethod);
    return env->GetStringUTFChars(str, 0);
}

#include <curl/curl.h>

struct MemoryStruct {
    char *memory;
    size_t size;
};

static size_t WriteMemoryCallback(void *contents, size_t size, size_t nmemb, void *userp) {
    size_t realsize = size * nmemb;
    struct MemoryStruct *mem = (struct MemoryStruct *) userp;

    mem->memory = (char *) realloc(mem->memory, mem->size + realsize + 1);
    if (mem->memory == NULL) {
        return 0;
    }

    memcpy(&(mem->memory[mem->size]), contents, realsize);
    mem->size += realsize;
    mem->memory[mem->size] = 0;

    return realsize;
}

[[noreturn]]
void *maps_thread(void *) {
    while (true) {
        auto t1 = std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::system_clock::now().time_since_epoch()).count();

        std::vector<sRegion> tmp;
        char line[512];
        FILE *f = fopen("/proc/self/maps", "r");
        if (f) {
            while (fgets(line, sizeof line, f)) {
                uintptr_t start, end;
                char tmpProt[16];
                if (sscanf(line, "%" PRIXPTR "-%" PRIXPTR " %16s %*s %*s %*s %*s", &start, &end,
                           tmpProt) > 0) {
                    if (tmpProt[0] != 'r') {
                        tmp.push_back({start, end});
                    }
                }
            }
            fclose(f);
        }
        trapRegions = tmp;


        auto td = std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::system_clock::now().time_since_epoch()).count() - t1;
        std::this_thread::sleep_for(
                std::chrono::milliseconds(std::max(std::min(0LL, SLEEP_TIME - td), SLEEP_TIME)));
    }
}

// ================================================================================================================================
void *Init_Thread(void *) {
    while (!g_UE4) {
        g_UE4 = Tools::GetBaseAddress("libUE4.so");
        sleep(1);
    }
    LOGI("libUE4.so: %p", g_UE4);

    FName::GNames = GetGNames();
    while (!FName::GNames) {
        FName::GNames = GetGNames();
        sleep(1);
    }
    
    
    UObject::GUObjectArray = (FUObjectArray *) (g_UE4 + GUObject_Offset);
    bScanPatternCompleted = true;
    Config["ESP::LOOT_BOX_MAX_DISTANCE"] = 10.f;
    pthread_t t;
    pthread_create(&t, 0, maps_thread, 0);
    Tools::Hook((void *) (g_UE4 + 0x6090788), (void *) Hook_Shoot_Event, (void **) &Orig_Shoot_Event);
	
  //  ProcMap il2cppMap;
	
        
    return 0;
}

void native_Init(JNIEnv *env, jclass clazz, jobject mContext) {
    auto pkgName = GetPackageName(env, mContext);
    // StartRuntimeHook(pkgName);
    // pthread_t t;
    // pthread_create(&t, 0, Init_Thread, 0);
}

jstring native_Check(JNIEnv *env, jclass clazz, jobject jContext, jstring jUserKey) {
    auto user_key = env->GetStringUTFChars(jUserKey, 0);

    auto gamePackageName = GetPackageName(env, jContext);

    std::string hwid = user_key;
    hwid += GetAndroidID(env, jContext);
    hwid += GetDeviceModel(env);
    hwid += GetDeviceBrand(env);
    std::string UUID = GetDeviceUniqueIdentifier(env, hwid.c_str());

    std::string errMsg;

    struct MemoryStruct chunk
            {
            };
    chunk.memory = (char *) malloc(1);
    chunk.size = 0;

    CURL *curl;
    CURLcode res;
    curl = curl_easy_init();
 	
    if (curl) {
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, /*POST*/ StrEnc(",IL=", "\x7C\x06\x1F\x69", 4).c_str());
        std::string api_key = OBFUSCATE("https://apiserver.fun/SHANIVIP/connect");
        curl_easy_setopt(curl, CURLOPT_URL, (api_key.c_str()));
        curl_easy_setopt(curl, CURLOPT_DEFAULT_PROTOCOL, /*https*/ StrEnc("!mLBO", "\x49\x19\x38\x32\x3C", 5).c_str());
        struct curl_slist *headers = NULL;
        headers = curl_slist_append(headers, /*Content-Type: application/x-www-form-urlencoded*/ StrEnc("@;Ls\\(KP4Qrop`b#d3094/r1cf<c<=H)AiiBG6i|Ta66s2[", "\x03\x54\x22\x07\x39\x46\x3F\x7D\x60\x28\x02\x0A\x4A\x40\x03\x53\x14\x5F\x59\x5A\x55\x5B\x1B\x5E\x0D\x49\x44\x4E\x4B\x4A\x3F\x04\x27\x06\x1B\x2F\x6A\x43\x1B\x10\x31\x0F\x55\x59\x17\x57\x3F", 47).c_str());
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

        char data[4096];
        sprintf(data, /* game=PUBG&user_key=%s&serial=%s */
                StrEnc("qu2yXK,YkJyGD@ut0.u~Nb'5(:.:chK",
                       "\x16\x14\x5F\x1C\x65\x1B\x79\x1B\x2C\x6C\x0C\x34\x21\x32\x2A\x1F\x55\x57\x48\x5B\x3D\x44\x54\x50\x5A\x53\x4F\x56\x5E\x4D\x38",
                       31).c_str(), user_key, UUID.c_str());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);

        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *) &chunk);

        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
        

        res = curl_easy_perform(curl);
        if (res == CURLE_OK) {
            try {
                json result = json::parse(chunk.memory);
                if (result[ /* status */ StrEnc("(>_LBm", "\x5B\x4A\x3E\x38\x37\x1E", 6).c_str()]
                    ==
                    true) {
                    std::string token = result[ /* data */ StrEnc("fAVA", "\x02\x20\x22\x20",
                                                                  4).
                            c_str()][ /* token */ StrEnc("{>3Lr",
                                                         "\x0F\x51\x58\x29\x1C",
                                                         5).c_str()].get<
                            std::string>();
                    time_t rng = result[ /* data */ StrEnc("fAVA", "\x02\x20\x22\x20",
                                                           4).c_str()][ /* rng */ StrEnc("+n,",
                                                                                         "\x59\x00\x4B",
                                                                                         3).
                            c_str()].get<time_t>();

                    rng = result[ /* data */ StrEnc("fAVA", "\x02\x20\x22\x20",
                                                    4).c_str()][ /* rng */ StrEnc("+n,",
                                                                                  "\x59\x00\x4B",
                                                                                  3).c_str()].get<
                            time_t>();
                    //expiretime = result["data"]["expiretime"].get<std::string>();

                    if (rng + 30 > time(0)) {
                        std::string auth = /*PUBG*/ StrEnc("Q*) ", "\x01\x7F\x6B\x67", 4).c_str();;
                        auth += "-";
                        auth += user_key;
                        auth += "-";
                        auth += UUID;
                        auth += "-";
                        std::string licanse = OBFUSCATE("Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E");
                        auth += licanse.c_str();		         
						std::string outputAuth = Tools::CalcMD5(auth);

                        g_Token = token;
                        g_Auth = outputAuth;

                        bValid = g_Token == g_Auth;

                    }
                } else {
                    errMsg = result[ /* reason */ StrEnc("LW(3(c", "\x3E\x32\x49\x40\x47\x0D",
                                                         6).c_str()].get<std::string>();
                }
            }
            catch (json::exception &e) {
                errMsg = "{";
                errMsg += e.what();
                errMsg += "}\n{";
                errMsg += chunk.memory;
                errMsg += "}";
            }
        } else {
            errMsg = curl_easy_strerror(res);
        }
    }
    curl_easy_cleanup(curl);
    if (bValid) {
        pthread_t t;
        pthread_create(&t, 0, Init_Thread, 0);
    }
    return bValid ? env->NewStringUTF("OK") : env->NewStringUTF(errMsg.c_str());
}
