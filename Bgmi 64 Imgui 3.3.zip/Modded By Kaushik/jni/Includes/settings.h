#pragma once

namespace settings {

	inline ImVec4 particleColour = ImVec4(255, 255, 255, 255);

}