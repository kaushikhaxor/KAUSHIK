extern "C" {
JNIEXPORT void JNICALL
Java_com_Mrkaushikhaxor_Injector_Hack1(JNIEnv *, jobject, jint code,jboolean jboolean1) {																  
switch ((int)code) { 	
case 2324:
Config.AimBot.Enable = jboolean1;
if(Config.AimBot.Enable){
Config.AimBot.Enable = true;
break;
}}}}
extern "C" {
JNIEXPORT void JNICALL
Java_com_Mrkaushikhaxor_Injector_Hack2(JNIEnv *, jobject, jint code,jboolean jboolean1) {																  
switch ((int)code) {   	
case 2325:
Config.SilentAim.Enable/*Config.BulletTrack.Enable*/ = jboolean1;
if(Config.SilentAim.Enable){
Config.SilentAim.Enable = true;
break;
}}}}
extern "C" {
JNIEXPORT void JNICALL
Java_com_Mrkaushikhaxor_Injector_Hack3(JNIEnv *, jobject, jint code,jboolean jboolean1) {																  
switch ((int)code) { 	
case 2326:
ggxhit = jboolean1;
if(ggxhit){
kFox::SetSearchRange(RegionType::ALL);
kFox::MemorySearch("10.0", Type::TYPE_FLOAT);
kFox::MemoryOffset("46.0", 4, Type::TYPE_FLOAT);
kFox::MemoryWrite("1000.0", 0, Type::TYPE_FLOAT);
kFox::ClearResult();
break;
}}}}

extern "C" {
JNIEXPORT void JNICALL
Java_com_Mrkaushikhaxor_Injector_Hack4(JNIEnv *, jobject, jint code,jboolean jboolean1) {																  
switch ((int)code) {
case 2327:
XhitRainBow = jboolean1;
if(XhitRainBow){
XhitRainBow = true;
break;
}}}}
extern "C" {
JNIEXPORT void JNICALL
Java_com_Mrkaushikhaxor_Injector_Hack5(JNIEnv *, jobject, jint code,jboolean jboolean1) {																  
switch ((int)code) { 	
case 2328:
Config.HighRisk.Small = jboolean1;
if(Config.HighRisk.Small){
Config.HighRisk.Small = true;
break;
}}}}
extern "C" {
JNIEXPORT void JNICALL
Java_com_Mrkaushikhaxor_Injector_Hack6(JNIEnv *, jobject, jint code,jboolean jboolean1) {																  
switch ((int)code) { 	
case 2329:
RgbCross = jboolean1;
if(RgbCross){
RgbCross = true;
break;
}}}}
extern "C" {
JNIEXPORT void JNICALL
Java_com_Mrkaushikhaxor_Injector_Hack7(JNIEnv *, jobject, jint code,jboolean jboolean1) {																  
switch ((int)code) { 	
case 2330:
FASTPARACHUTE = jboolean1;
if(FASTPARACHUTE){
FASTPARACHUTE = true;
break;
}}}}
extern "C" {
JNIEXPORT void JNICALL
Java_com_Mrkaushikhaxor_Injector_Hack8(JNIEnv *, jobject, jint code,jboolean jboolean1) {																  
switch ((int)code) { 	
case 2331:
Zoom = jboolean1;
if(Zoom){
Zoom = true;
break;
}}}}
extern "C" {
JNIEXPORT void JNICALL
Java_com_Mrkaushikhaxor_Injector_Hack9(JNIEnv *, jobject, jint code,jboolean jboolean1) {																  
switch ((int)code) { 	
case 2332:
Magic = jboolean1;
if(Magic){
kFox::ClearResult();
kFox::SetSearchRange(RegionType::ALL);
kFox::MemorySearch("25", Type::TYPE_FLOAT);
kFox::MemoryOffset("30.5", 4, Type::TYPE_FLOAT);
kFox::MemoryWrite("700.5", 0, Type::TYPE_FLOAT);
kFox::MemoryWrite("700.5", 4, Type::TYPE_FLOAT);
kFox::ClearResult();
kFox::SetSearchRange(RegionType::ALL);
kFox::MemorySearch("-88.66608428955", Type::TYPE_FLOAT);
kFox::MemoryOffset("26", 8, Type::TYPE_FLOAT);
kFox::MemoryWrite("-460", 8, Type::TYPE_FLOAT);
kFox::ClearResult();
kFox::SetSearchRange(RegionType::ALL);
kFox::MemorySearch("-88.73961639404", Type::TYPE_FLOAT);
kFox::MemoryOffset("28", 8, Type::TYPE_FLOAT);
kFox::MemoryWrite("-560", 8, Type::TYPE_FLOAT);
kFox::ClearResult();
break;
}}}}
extern "C" {
JNIEXPORT void JNICALL
Java_com_Mrkaushikhaxor_Injector_Hack10(JNIEnv *, jobject, jint code,jboolean jboolean1) {																  
switch ((int)code) { 	
case 2333:
Config.HighRisk.SmallAim = jboolean1;
if(Config.HighRisk.SmallAim){
Config.HighRisk.SmallAim = true;
break;
}}}}

extern "C" {
JNIEXPORT void JNICALL
Java_com_Mrkaushikhaxor_Injector_Hack11(JNIEnv *, jobject, jint code,jboolean jboolean1) {																  
switch ((int)code) { 	
case 2334:
NEWMENU = jboolean1;
if(NEWMENU){
NEWMENU = true;
break;
}}}}
//---------------------------------------------------------------------------------------------------------//
#define SLEEP_TIME 1000LL / 60LL
[[noreturn]] void * kaushik_thread(void *) {
while (true) {
auto t1 = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
auto localPlayer = g_LocalPlayer;
auto localController = g_LocalController;
if (localPlayer && localController) {
	


if (XhitRainBow) {
 auto objs = UObject::GetGlobalObjects();
for (int i = 0; i < objs.Num(); i++) {
auto Object = objs.GetByIndex(i);
if (isObjectInvalid(Object))
continue;
if (Object->IsA(ASurviveHUD::StaticClass())) {
auto xRGB = (ASurviveHUD*)Object;
static float cnt = 0.0f;
const float rainbowSpeed = 18.0f;
FLinearColor rainbowColors[] = {
FLinearColor(1.0f, 0.0f, 0.0f, 1.0f), // A: Red
FLinearColor(1.0f, 0.5f, 0.0f, 1.0f), // B: Orange
FLinearColor(1.0f, 1.0f, 0.0f, 1.0f), // C: Yellow
FLinearColor(0.0f, 1.0f, 0.0f, 1.0f), // D: Green
FLinearColor(0.0f, 0.0f, 1.0f, 1.0f), // E: Blue
FLinearColor(0.5f, 0.0f, 1.0f, 1.0f), // F: Indigo
FLinearColor(1.0f, 0.0f, 1.0f, 1.0f), // G: Violet
FLinearColor(1.0f, 0.0f, 0.5f, 1.0f), // H: Purple
FLinearColor(0.5f, 0.0f, 0.5f, 1.0f), // I: Mauve
FLinearColor(0.0f, 0.5f, 0.5f, 1.0f), // J: Teal
FLinearColor(0.5f, 0.5f, 0.5f, 1.0f), // K: Gray
FLinearColor(0.5f, 0.0f, 0.0f, 1.0f), // L: Maroon
FLinearColor(0.0f, 0.5f, 0.0f, 1.0f), // M: Lime
FLinearColor(0.0f, 0.5f, 0.5f, 1.0f), // N: Aqua
FLinearColor(0.5f, 0.5f, 0.0f, 1.0f), // O: Olive
FLinearColor(0.0f, 0.0f, 0.5f, 1.0f), // P: Navy
FLinearColor(0.5f, 0.0f, 0.5f, 1.0f), // Q: Fuchsia
FLinearColor(0.5f, 1.0f, 0.0f, 1.0f), // R: Chartreuse
FLinearColor(0.0f, 0.5f, 1.0f, 1.0f), // S: Sky Blue
FLinearColor(1.0f, 0.5f, 0.5f, 1.0f), // T: Salmon
FLinearColor(0.5f, 0.0f, 0.0f, 1.0f), // U: Burgundy
FLinearColor(0.0f, 0.0f, 0.0f, 1.0f), // V: Black
FLinearColor(1.0f, 1.0f, 1.0f, 1.0f), // W: White
FLinearColor(0.0f, 1.0f, 1.0f, 1.0f), // X: Cyan
FLinearColor(0.5f, 0.5f, 1.0f, 1.0f), // Y: Lavender
FLinearColor(0.75f, 0.75f, 0.0f, 1.0f) // Z: Gold
};
int rainbowColorIndex = static_cast<int>(fmod(cnt * rainbowSpeed, 7.0f));
FLinearColor color1 = rainbowColors[rainbowColorIndex];
FLinearColor color2 = rainbowColors[(rainbowColorIndex + 1) % 7]; // Wrap around
float t = fmod(cnt * rainbowSpeed, 1.0f); // Interpolation factor
FLinearColor rainbowColor = FLinearColor(
color1.R + (color2.R - color1.R) * t,
color1.G + (color2.G - color1.G) * t,
color1.B + (color2.B - color1.B) * t,1.0f);
xRGB->HitPerform.HitBodyDrawColor = rainbowColor;   // body hit color
xRGB->HitPerform.HitHeadDrawColor = rainbowColor;  // head hoit color
if (cnt >= 360.0f) {
cnt = 0.0f;
}else {
cnt += 0.02f;
}}}}
if (FASTPARACHUTE) {
auto objs = UObject::GetGlobalObjects();
for (int i = 0;i < objs.Num();i++) {
auto Object = objs.GetByIndex(i);
if (isObjectInvalid(Object))
continue;
UCharacterParachuteComponent *ParachuteComponent = g_LocalPlayer->ParachuteComponent;
if (ParachuteComponent)
{
ParachuteComponent->CurrentFallSpeed = 9999.9f;
}}}

if (Config.HighRisk.Small || Config.HighRisk.Shake || Config.HighRisk.HitEffect || Config.HighRisk.Recoil || Config.HighRisk.SmallAim || Instantv2) {
auto WeaponManagerComponent = localPlayer->WeaponManagerComponent;
if (WeaponManagerComponent) {
auto Slot = WeaponManagerComponent->GetCurrentUsingPropSlot();
if ((int)Slot.GetValue() >= 1 && (int)Slot.GetValue() <= 3) {
auto CurrentWeaponReplicated = (ASTExtraShootWeapon *)WeaponManagerComponent->CurrentWeaponReplicated;
if (CurrentWeaponReplicated) {
auto ShootWeaponEntityComp = CurrentWeaponReplicated->ShootWeaponEntityComp;
auto ShootWeaponEffectComp = CurrentWeaponReplicated->ShootWeaponEffectComp;
if (ShootWeaponEntityComp && ShootWeaponEffectComp) {
if (Instantv2){
if (ShootWeaponEntityComp){
ShootWeaponEntityComp->BaseImpactDamage = 9999999.9f;
ShootWeaponEntityComp->WeaponAimFOV = 180.0f;
ShootWeaponEntityComp->MaxDamageRate = 9999999.9f;
ShootWeaponEntityComp->MaxVelocityOffsetAddRate = 9999.0f;
ShootWeaponEntityComp->BulletRange = 999999.9f;
ShootWeaponEntityComp->BurstShootInterval = 0;
ShootWeaponEntityComp->BurstShootCD = 0.01f;
ShootWeaponEntityComp->WeaponBodyLength = 999.0f;
ShootWeaponEntityComp->MaxBulletImpactFXClampDistance = 999999.9f;
}}
if (Zoom){
UCameraComponent *ScopeCameraComp = localPlayer->ScopeCameraComp;
if (ScopeCameraComp){
ScopeCameraComp->SetFieldOfView(SetZoom);
}}
if (Config.HighRisk.Recoil) {
ShootWeaponEntityComp->AccessoriesVRecoilFactor = 0.0f;
ShootWeaponEntityComp->AccessoriesHRecoilFactor = 0.0f;
ShootWeaponEntityComp->AccessoriesRecoveryFactor = 0.0f;
ShootWeaponEntityComp->RecoilKickADS = 0.0f;
}
if (Config.HighRisk.Shake) {
ShootWeaponEffectComp->CameraShakeInnerRadius = 0.0f;
ShootWeaponEffectComp->CameraShakeOuterRadius = 0.0f;
ShootWeaponEffectComp->CameraShakFalloff = 0.0f;
}
if (Config.HighRisk.Small) {
ShootWeaponEntityComp->GameDeviationFactor = 0.0f;
}
if (Config.HighRisk.SmallAim) {
ShootWeaponEntityComp->IsSupportAutoAim = true;
}
if (Config.HighRisk.HitEffect) {
ShootWeaponEntityComp->DamageImpulse = 6.0f;
ShootWeaponEntityComp->ExtraHitPerformScale = 6.0f;
}}}}}}}
auto td = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count() - t1;
std::this_thread::sleep_for(std::chrono::milliseconds(std::max(std::min(0LL, SLEEP_TIME - td), SLEEP_TIME)));
}
return 0;
}
