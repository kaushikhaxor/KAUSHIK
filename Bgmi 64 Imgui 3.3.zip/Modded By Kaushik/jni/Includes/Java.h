extern "C" {
JNIEXPORT void JNICALL
Java_com_Mrkaushikhaxor_Injector_Hack1(JNIEnv *, jobject, jint code,jboolean jboolean1) {																  
switch ((int)code) { 	
case 2324:
Config.AimBot.Enable = jboolean1;
if(Config.AimBot.Enable){
Config.AimBot.Enable = true;
break;
}}}}
extern "C" {
JNIEXPORT void JNICALL
Java_com_Mrkaushikhaxor_Injector_Hack2(JNIEnv *, jobject, jint code,jboolean jboolean1) {																  
switch ((int)code) {   	
case 2325:
Config.SilentAim.Enable/*Config.BulletTrack.Enable*/ = jboolean1;
if(Config.SilentAim.Enable){
Config.SilentAim.Enable = true;
break;
}}}}
extern "C" {
JNIEXPORT void JNICALL
Java_com_Mrkaushikhaxor_Injector_Hack3(JNIEnv *, jobject, jint code,jboolean jboolean1) {																  
switch ((int)code) { 	
case 2326:
ggxhit = jboolean1;
if(ggxhit){
kFox::SetSearchRange(RegionType::ALL);
kFox::MemorySearch("10.0", Type::TYPE_FLOAT);
kFox::MemoryOffset("46.0", 4, Type::TYPE_FLOAT);
kFox::MemoryWrite("1000.0", 0, Type::TYPE_FLOAT);
kFox::ClearResult();
break;
}}}}

extern "C" {
JNIEXPORT void JNICALL
Java_com_Mrkaushikhaxor_Injector_Hack4(JNIEnv *, jobject, jint code,jboolean jboolean1) {																  
switch ((int)code) {
case 2327:
XhitRainBow = jboolean1;
if(XhitRainBow){
XhitRainBow = true;
break;
}}}}
extern "C" {
JNIEXPORT void JNICALL
Java_com_Mrkaushikhaxor_Injector_Hack5(JNIEnv *, jobject, jint code,jboolean jboolean1) {																  
switch ((int)code) { 	
case 2328:
Config.HighRisk.Small = jboolean1;
if(Config.HighRisk.Small){
Config.HighRisk.Small = true;
break;
}}}}
extern "C" {
JNIEXPORT void JNICALL
Java_com_Mrkaushikhaxor_Injector_Hack6(JNIEnv *, jobject, jint code,jboolean jboolean1) {																  
switch ((int)code) { 	
case 2329:
RgbCross = jboolean1;
if(RgbCross){
RgbCross = true;
break;
}}}}
extern "C" {
JNIEXPORT void JNICALL
Java_com_Mrkaushikhaxor_Injector_Hack7(JNIEnv *, jobject, jint code,jboolean jboolean1) {																  
switch ((int)code) { 	
case 2330:
FASTPARACHUTE = jboolean1;
if(FASTPARACHUTE){
FASTPARACHUTE = true;
break;
}}}}
extern "C" {
JNIEXPORT void JNICALL
Java_com_Mrkaushikhaxor_Injector_Hack8(JNIEnv *, jobject, jint code,jboolean jboolean1) {																  
switch ((int)code) { 	
case 2331:
Zoom = jboolean1;
if(Zoom){
Zoom = true;
break;
}}}}
extern "C" {
JNIEXPORT void JNICALL
Java_com_Mrkaushikhaxor_Injector_Hack9(JNIEnv *, jobject, jint code,jboolean jboolean1) {																  
switch ((int)code) { 	
case 2332:
Magic = jboolean1;
if(Magic){
kFox::ClearResult();
kFox::SetSearchRange(RegionType::ALL);
kFox::MemorySearch("25", Type::TYPE_FLOAT);
kFox::MemoryOffset("30.5", 4, Type::TYPE_FLOAT);
kFox::MemoryWrite("700.5", 0, Type::TYPE_FLOAT);
kFox::MemoryWrite("700.5", 4, Type::TYPE_FLOAT);
kFox::ClearResult();
kFox::SetSearchRange(RegionType::ALL);
kFox::MemorySearch("-88.66608428955", Type::TYPE_FLOAT);
kFox::MemoryOffset("26", 8, Type::TYPE_FLOAT);
kFox::MemoryWrite("-460", 8, Type::TYPE_FLOAT);
kFox::ClearResult();
kFox::SetSearchRange(RegionType::ALL);
kFox::MemorySearch("-88.73961639404", Type::TYPE_FLOAT);
kFox::MemoryOffset("28", 8, Type::TYPE_FLOAT);
kFox::MemoryWrite("-560", 8, Type::TYPE_FLOAT);
kFox::ClearResult();
break;
}}}}
extern "C" {
JNIEXPORT void JNICALL
Java_com_Mrkaushikhaxor_Injector_Hack10(JNIEnv *, jobject, jint code,jboolean jboolean1) {																  
switch ((int)code) { 	
case 2333:
Config.HighRisk.SmallAim = jboolean1;
if(Config.HighRisk.SmallAim){
Config.HighRisk.SmallAim = true;
break;
}}}}

extern "C" {
JNIEXPORT void JNICALL
Java_com_Mrkaushikhaxor_Injector_Hack11(JNIEnv *, jobject, jint code,jboolean jboolean1) {																  
switch ((int)code) { 	
case 2334:
NEWMENU = jboolean1;
if(NEWMENU){
NEWMENU = true;
break;
}}}}
//---------------------------------------------------------------------------------------------------------//