void *main_thread(void *) {
Crack(); Crack2(); Crack3(); Crack4(); Crack5(); Crack6(); Crack7(); Crack8(); Crack9(); Crack10(); Crack11(); Crack12(); Crack13(); Crack14();
FixGameCrash();

anogs = Tools::GetBaseAddress("libanogs.so");
while (!anogs) {
anogs = Tools::GetBaseAddress("libanogs.so");
sleep(1);
}
UE4 = Tools::GetBaseAddress("libUE4.so");
while (!UE4) {
UE4 = Tools::GetBaseAddress("libUE4.so");
sleep(1);
}	
while (!g_App) {
g_App = *(android_app **) (UE4 + GNativeAndroidApp_Offset);
sleep(1);
}

void *input = dlopen_ex(OBFUSCATE("libinput.so"), 4);
while (!input) {
input = dlopen_ex(OBFUSCATE("libinput.so"), 4);
sleep(1);
}
void *address = dlsym_ex(input, OBFUSCATE("_ZN7android13InputConsumer21initializeMotionEventEPNS_11MotionEventEPKNS_12InputMessageE"));
HOOK(address, onInputEvent, &orig_onInputEvent);
dlclose_ex(input);


initOffset();
FName::GNames = GetGNames();
while (!FName::GNames) {
FName::GNames = GetGNames();
sleep(1);
}
UObject::GUObjectArray = (FUObjectArray *) (UE4 + GUObject_Offset);

void *egl = dlopen_ex("libEGL.so", 4);
while (!egl) {
egl = dlopen_ex("libEGL.so", 4);
sleep(1);
}
void *addr = dlsym_ex(egl, "eglSwapBuffers");
A64HookFunction((void *) (Tools::GetBaseAddress(OBFUSCATE("libUE4.so")) + eglSwapBuffers), (void *) _eglSwapBuffers, (void **) &orig_eglSwapBuffers);(addr, _eglSwapBuffers, &orig_eglSwapBuffers);

//A64HookFunction((void *) (UE4 + 0x634F498), (void *)Hook_Shoot_Event, (void **)&Orig_Shoot_Event);
pthread_t t;
items_data = json::parse(JSON_ITEMS);
return 0;
}

__attribute__((constructor)) void _init() {
pthread_t t;
pthread_create(&t, 0, main_thread, 0);
pthread_create(&t, 0, kaushik_thread, 0);
pthread_create(&t, 0, kaushik2_thread, 0);
}
