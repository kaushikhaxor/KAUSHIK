void *(*oProcessEvent)(UObject *pObj, UFunction *pFunc, void *pArgs);
void *hkProcessEvent(UObject *pObj, UFunction *pFunc, void *pArgs) {
	/*
if (std::string(pFunc->GetFullName().c_str()).find("BackpackBlueprintUtils_BP.BackpackBlueprintUtils_BP_C.CreateBattleItemHandle") != std::string::npos){
UBackpackUtils_CreateBattleItemHandle_Params *PARAMS = ( UBackpackUtils_CreateBattleItemHandle_Params * ) pArgs;
std::string strWeaponId = std::to_string((int)PARAMS->DefineID.TypeSpecificID);
std::string strBackPack = std::to_string((int)PARAMS->DefineID.TypeSpecificID);
std::string strHelmet = std::to_string((int)PARAMS->DefineID.TypeSpecificID);


if (strstr(strWeaponId.c_str(), "703001"))//Hoverboard
{
PARAMS->DefineID.TypeSpecificID = 4151030;
}
	
//bsckpack

if (strstr(strBackPack.c_str(), "501001")){
PARAMS->DefineID.TypeSpecificID = 1501003443;
}
if (strstr(strBackPack.c_str(), "501002")){
PARAMS->DefineID.TypeSpecificID = 1501003443;
}
if (strstr(strBackPack.c_str(), "501003")){
PARAMS->DefineID.TypeSpecificID = 1501003443;
}
//m4
if (strstr(strWeaponId.c_str(), "203001")){//reddotpuro
PARAMS->DefineID.TypeSpecificID = 1010040470; //Glacier - M416
}
if (strstr(strWeaponId.c_str(), "101004")){
PARAMS->DefineID.TypeSpecificID = 1101004046; //Glacier - M416
}
if (strstr(strWeaponId.c_str(), "205002")){// Config.M416_Tactical_stock
PARAMS->DefineID.TypeSpecificID = 1010040443; //Glacier - M416
}
if (strstr(strWeaponId.c_str(), "205005")){// M416_default_stock
PARAMS->DefineID.TypeSpecificID = 1010040443; //Glacier - M416 
}
if (strstr(strWeaponId.c_str(), "203008")){// M416_Mechanical_Sights
PARAMS->DefineID.TypeSpecificID = 1010040442; //Glacier - M416 
}
if (strstr(strWeaponId.c_str(), "291004")){// M416_default_Magazine
PARAMS->DefineID.TypeSpecificID = 1010040441; //Glacier - M416
}




//Cryofrost Shard - UMP 45

if (strstr(strWeaponId.c_str(), "102002")){
PARAMS->DefineID.TypeSpecificID = 1102002136;
}
if (strstr(strWeaponId.c_str(), "292002")){//Ump maz
PARAMS->DefineID.TypeSpecificID = 1020021357;
}
if (strstr(strWeaponId.c_str(), "12219414")){
PARAMS->DefineID.TypeSpecificID = 12219718;
}
return oProcessEvent(pObj, pFunc, pArgs);
}*/

//---------------------- K I L L   M E S S A G E ---------------------------------//
const char *pBroadCast = ("Function ShadowTrackerExtra.STExtraPlayerController.BroadcastFatalDamageToClientWithStruct");//kaushik
if (pFunc) {
if (pFunc->GetFullName() == pBroadCast) {
ASTExtraPlayerController *pController = (ASTExtraPlayerController *) pObj;//kaushik
if (pController) {
auto Params = (ASTExtraPlayerController_BroadcastFatalDamageToClientWithStruct_Params *) pArgs;//kaushik
if (Params) {
auto GWorld = GetWorld();//kaushik
if (GWorld){
if (GWorld->NetDriver->ServerConnection)
if(GWorld->NetDriver->ServerConnection->PlayerController){
ASTExtraPlayerController *localController = (ASTExtraPlayerController *)GWorld->NetDriver->ServerConnection->PlayerController;//kaushik
ASTExtraPlayerCharacter *localPlayer = (ASTExtraPlayerCharacter *)localController->AcknowledgedPawn;//kaushik
if(localController->PlayerKey == Params->FatalDamageParameter.CauserKey && !localController->STExtraBaseCharacter->CurrentVehicle && localPlayer->WeaponManagerComponent->CurrentWeaponReplicated){          
//Params->FatalDamageParameter.CauserClothAvatarID =  1405870;
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "AKM")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1101001213;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "M762")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1101008104;
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "M24")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1103002059;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "M416")){  
Params->FatalDamageParameter.CauserWeaponAvatarID = 1101004046;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "AWM")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1103003087;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "UMP")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1102002136; 
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "ACE")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1101102017;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "SCAR")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1101003167;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "GROZA")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1101005082;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "UZI")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1102001069;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "Vector")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1102003060;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "Thompson")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1102004018;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "PP-19 Bizon")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1102005020;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "Kar98K")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1103001179;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "DP")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1105002063;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "M16A4")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1101002081;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "QBZ")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1101007062;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "M249")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1105001048;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "Mini 14")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1101007025;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "SLR")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1103009022;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "SKS")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1103004058;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "Pan")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1108004283;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "Vss")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1103005024;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "MK14")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1103007028;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "S1897")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1104002022;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "AUG")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1101006033;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "AMR")){

Params->FatalDamageParameter.CauserWeaponAvatarID = 1103012010;
}
else if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "S12K")){
Params->FatalDamageParameter.CauserWeaponAvatarID = 1104003026;
}}}}}}
return oProcessEvent(pObj, pFunc, pArgs);
}
}
/*

//---------------------- D E A T H      B O X---------------------------------//
if( std::string(pObj->GetName().c_str()).find("DeadBoxAvatarComponent") != std::string::npos ) {
UDeadBoxAvatarComponent *DeadBoxPointer = ( UDeadBoxAvatarComponent *) pObj; 
if( std::string(pFunc->GetFullName().c_str()).find("GetLuaFilePath") != std::string::npos ) {
uint32_t Key = DeadBoxPointer->IsSelf();              
auto GWorld = GetWorld();
if (GWorld){
if (GWorld->NetDriver->ServerConnection)
if(GWorld->NetDriver->ServerConnection->PlayerController){
ASTExtraPlayerController *localController = (ASTExtraPlayerController *)GWorld->NetDriver->ServerConnection->PlayerController;
ASTExtraPlayerCharacter *localPlayer = (ASTExtraPlayerCharacter *)localController->AcknowledgedPawn;
if(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated){
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "AKM")){
DeadBoxPointer->ChangeItemAvatar(1101001213, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "M762")){
DeadBoxPointer->ChangeItemAvatar(1101008104, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "M24")){
DeadBoxPointer->ChangeItemAvatar(1103002059, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "M416")){  
DeadBoxPointer->ChangeItemAvatar(1101004046, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "AWM")){
DeadBoxPointer->ChangeItemAvatar(1103003087, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "UMP")){
DeadBoxPointer->ChangeItemAvatar(1102002136, true); 
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "ACE")){
DeadBoxPointer->ChangeItemAvatar(1101102017, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "SCAR")){
DeadBoxPointer->ChangeItemAvatar(1101003167, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "GROZA")){
DeadBoxPointer->ChangeItemAvatar(1101005082, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "UZI")){
DeadBoxPointer->ChangeItemAvatar(1102001069, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "Vector")){
DeadBoxPointer->ChangeItemAvatar(1102003060, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "Thompson")){
DeadBoxPointer->ChangeItemAvatar(1102004018, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "PP-19 Bizon")){
DeadBoxPointer->ChangeItemAvatar(1102005020, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "Kar98K")){
DeadBoxPointer->ChangeItemAvatar(1103001179, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "DP")){
DeadBoxPointer->ChangeItemAvatar(1105002063, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "M16A4")){
DeadBoxPointer->ChangeItemAvatar(1101002081, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "QBZ")){
DeadBoxPointer->ChangeItemAvatar(1101007062, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "M249")){
DeadBoxPointer->ChangeItemAvatar(1105001048, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "Mini 14")){
DeadBoxPointer->ChangeItemAvatar(1101007025, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "SLR")){
DeadBoxPointer->ChangeItemAvatar(1103009022, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "SKS")){
DeadBoxPointer->ChangeItemAvatar(1103004058, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "Pan")){
DeadBoxPointer->ChangeItemAvatar(1108004283, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "Vss")){
DeadBoxPointer->ChangeItemAvatar(1103005024, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "MK14")){
DeadBoxPointer->ChangeItemAvatar(1103007028, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "S1897")){
DeadBoxPointer->ChangeItemAvatar(1104002022, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "AUG")){
DeadBoxPointer->ChangeItemAvatar(1101006033, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "AMR")){

DeadBoxPointer->ChangeItemAvatar(1103012010, true);
}
if(strstr(localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponName().ToString(), "S12K")){
DeadBoxPointer->ChangeItemAvatar(1104003026, true);
}}}}}
return oProcessEvent(pObj, pFunc, pArgs);
}
*/

const char *EngineHUD = ("Function Engine.HUD.ReceiveDrawHUD");
if (pFunc) {
if (pFunc->GetFullName() == EngineHUD) {
AHUD *pHUD = (AHUD *) pObj;
if (pHUD) {
auto Params = (AHUD_ReceiveDrawHUD_Params *) pArgs;
if (Params) {
RenderESPPRIVATE(pHUD, Params->SizeX, Params->SizeY);
}}}}
return oProcessEvent(pObj, pFunc, pArgs);
}
void initOffset() {
Tools::Hook((void *) (UE4 + ProcessEvent_Offset), (void *) hkProcessEvent,(void **) &oProcessEvent);
}
