int OpenURL(const char* url)
{
    JavaVM* java_vm = g_App->activity->vm;
    JNIEnv* java_env = NULL;

    jint jni_return = java_vm->GetEnv((void**)&java_env, JNI_VERSION_1_6);
    if (jni_return == JNI_ERR)
        return -1;

    jni_return = java_vm->AttachCurrentThread(&java_env, NULL);
    if (jni_return != JNI_OK)
        return -2;

    jclass native_activity_clazz = java_env->GetObjectClass(g_App->activity->clazz);
    if (native_activity_clazz == NULL)
        return -3;

    jmethodID method_id = java_env->GetMethodID(native_activity_clazz, "AndroidThunkJava_LaunchURL", "(Ljava/lang/String;)V");
    if (method_id == NULL)
        return -4;
        
    jstring retStr = java_env->NewStringUTF(url);
    java_env->CallVoidMethod(g_App->activity->clazz, method_id, retStr);

    jni_return = java_vm->DetachCurrentThread();
    if (jni_return != JNI_OK)
        return -5;

    return 0;
}


    std::string getClipboardText() {
    if (!g_App)
        return "";

    auto activity = g_App->activity;
    if (!activity)
        return "";

    auto vm = activity->vm;
    if (!vm)
        return "";

    auto object = activity->clazz;
    if (!object)
        return "";

    std::string result;

    JNIEnv *env;
    vm->AttachCurrentThread(&env, 0);
    {
        auto ContextClass = env->FindClass("android/content/Context");
        auto getSystemServiceMethod = env->GetMethodID(ContextClass, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");

        auto str = env->NewStringUTF("clipboard");
        auto clipboardManager = env->CallObjectMethod(object, getSystemServiceMethod, str);
        env->DeleteLocalRef(str);

        auto ClipboardManagerClass = env->FindClass("android/content/ClipboardManager");
        auto getText = env->GetMethodID(ClipboardManagerClass, "getText", "()Ljava/lang/CharSequence;");

        auto CharSequenceClass = env->FindClass("java/lang/CharSequence");
        auto toStringMethod = env->GetMethodID(CharSequenceClass, "toString", "()Ljava/lang/String;");

        auto text = env->CallObjectMethod(clipboardManager, getText);
        if (text) {
            str = (jstring) env->CallObjectMethod(text, toStringMethod);
            result = env->GetStringUTFChars(str, 0);
            env->DeleteLocalRef(str);
            env->DeleteLocalRef(text);
        }

        env->DeleteLocalRef(CharSequenceClass);
        env->DeleteLocalRef(ClipboardManagerClass);
        env->DeleteLocalRef(clipboardManager);
        env->DeleteLocalRef(ContextClass);
    }
    vm->DetachCurrentThread();

    return result;
}



const char *GetAndroidID(JNIEnv *env, jobject context) {
    jclass contextClass = env->FindClass(/*android/content/Context*/ StrEnc("`L+&0^[S+-:J^$,r9q92(as", "\x01\x22\x4F\x54\x5F\x37\x3F\x7C\x48\x42\x54\x3E\x3B\x4A\x58\x5D\x7A\x1E\x57\x46\x4D\x19\x07", 23).c_str());
    jmethodID getContentResolverMethod = env->GetMethodID(contextClass, /*getContentResolver*/ StrEnc("E8X\\7r7ys_Q%JS+L+~", "\x22\x5D\x2C\x1F\x58\x1C\x43\x1C\x1D\x2B\x03\x40\x39\x3C\x47\x3A\x4E\x0C", 18).c_str(), /*()Landroid/content/ContentResolver;*/ StrEnc("8^QKmj< }5D:9q7f.BXkef]A*GYLNg}B!/L", "\x10\x77\x1D\x2A\x03\x0E\x4E\x4F\x14\x51\x6B\x59\x56\x1F\x43\x03\x40\x36\x77\x28\x0A\x08\x29\x24\x44\x33\x0B\x29\x3D\x08\x11\x34\x44\x5D\x77", 35).c_str());
    jclass settingSecureClass = env->FindClass(/*android/provider/Settings$Secure*/ StrEnc("T1yw^BCF^af&dB_@Raf}\\FS,zT~L(3Z\"", "\x35\x5F\x1D\x05\x31\x2B\x27\x69\x2E\x13\x09\x50\x0D\x26\x3A\x32\x7D\x32\x03\x09\x28\x2F\x3D\x4B\x09\x70\x2D\x29\x4B\x46\x28\x47", 32).c_str());
    jmethodID getStringMethod = env->GetStaticMethodID(settingSecureClass, /*getString*/ StrEnc("e<F*J5c0Y", "\x02\x59\x32\x79\x3E\x47\x0A\x5E\x3E", 9).c_str(), /*(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;*/ StrEnc("$6*%R*!XO\"m18o,0S!*`uI$IW)l_/_knSdlRiO1T`2sH|Ouy__^}%Y)JsQ:-\"(2_^-$i{?H", "\x0C\x7A\x4B\x4B\x36\x58\x4E\x31\x2B\x0D\x0E\x5E\x56\x1B\x49\x5E\x27\x0E\x69\x0F\x1B\x3D\x41\x27\x23\x7B\x09\x2C\x40\x33\x1D\x0B\x21\x5F\x20\x38\x08\x39\x50\x7B\x0C\x53\x1D\x2F\x53\x1C\x01\x0B\x36\x31\x39\x46\x0C\x15\x43\x2B\x05\x30\x15\x41\x43\x46\x55\x70\x0D\x59\x56\x00\x15\x58\x73", 71).c_str());

    auto obj = env->CallObjectMethod(context, getContentResolverMethod);
    auto str = (jstring) env->CallStaticObjectMethod(settingSecureClass, getStringMethod, obj, env->NewStringUTF(/*android_id*/ StrEnc("ujHO)8OfOE", "\x14\x04\x2C\x3D\x46\x51\x2B\x39\x26\x21", 10).c_str()));
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceModel(JNIEnv *env) {
    jclass buildClass = env->FindClass(/*android/os/Build*/ StrEnc("m5I{GKGWBP-VOxkA", "\x0C\x5B\x2D\x09\x28\x22\x23\x78\x2D\x23\x02\x14\x3A\x11\x07\x25", 16).c_str());
    jfieldID modelId = env->GetStaticFieldID(buildClass, /*MODEL*/ StrEnc("|}[q:", "\x31\x32\x1F\x34\x76", 5).c_str(), /*Ljava/lang/String;*/ StrEnc(".D:C:ETZ1O-Ib&^h.Y", "\x62\x2E\x5B\x35\x5B\x6A\x38\x3B\x5F\x28\x02\x1A\x16\x54\x37\x06\x49\x62", 18).c_str());

    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceBrand(JNIEnv *env) {
    jclass buildClass = env->FindClass(/*android/os/Build*/ StrEnc("0iW=2^>0zTRB!B90", "\x51\x07\x33\x4F\x5D\x37\x5A\x1F\x15\x27\x7D\x00\x54\x2B\x55\x54", 16).c_str());
    jfieldID modelId = env->GetStaticFieldID(buildClass, /*BRAND*/ StrEnc("@{[FP", "\x02\x29\x1A\x08\x14", 5).c_str(), /*Ljava/lang/String;*/ StrEnc(".D:C:ETZ1O-Ib&^h.Y", "\x62\x2E\x5B\x35\x5B\x6A\x38\x3B\x5F\x28\x02\x1A\x16\x54\x37\x06\x49\x62", 18).c_str());

    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetPackageName(JNIEnv *env, jobject context) {
    jclass contextClass = env->FindClass(/*android/content/Context*/ StrEnc("`L+&0^[S+-:J^$,r9q92(as", "\x01\x22\x4F\x54\x5F\x37\x3F\x7C\x48\x42\x54\x3E\x3B\x4A\x58\x5D\x7A\x1E\x57\x46\x4D\x19\x07", 23).c_str());
    jmethodID getPackageNameId = env->GetMethodID(contextClass, /*getPackageName*/ StrEnc("YN4DaP)!{wRGN}", "\x3E\x2B\x40\x14\x00\x33\x42\x40\x1C\x12\x1C\x26\x23\x18", 14).c_str(), /*()Ljava/lang/String;*/ StrEnc("VnpibEspM(b]<s#[9cQD", "\x7E\x47\x3C\x03\x03\x33\x12\x5F\x21\x49\x0C\x3A\x13\x20\x57\x29\x50\x0D\x36\x7F", 20).c_str());

    auto str = (jstring) env->CallObjectMethod(context, getPackageNameId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceUniqueIdentifier(JNIEnv *env, const char *uuid) {
    jclass uuidClass = env->FindClass(/*java/util/UUID*/ StrEnc("B/TxJ=3BZ_]SFx", "\x28\x4E\x22\x19\x65\x48\x47\x2B\x36\x70\x08\x06\x0F\x3C", 14).c_str());

    auto len = strlen(uuid);

    jbyteArray myJByteArray = env->NewByteArray(len);
    env->SetByteArrayRegion(myJByteArray, 0, len, (jbyte *) uuid);

    jmethodID nameUUIDFromBytesMethod = env->GetStaticMethodID(uuidClass, /*nameUUIDFromBytes*/ StrEnc("P6LV|'0#A+zQmoat,", "\x3E\x57\x21\x33\x29\x72\x79\x67\x07\x59\x15\x3C\x2F\x16\x15\x11\x5F", 17).c_str(), /*([B)Ljava/util/UUID;*/ StrEnc("sW[\"Q[W3,7@H.vT0) xB", "\x5B\x0C\x19\x0B\x1D\x31\x36\x45\x4D\x18\x35\x3C\x47\x1A\x7B\x65\x7C\x69\x3C\x79", 20).c_str());
    jmethodID toStringMethod = env->GetMethodID(uuidClass, /*toString*/ StrEnc("2~5292eW", "\x46\x11\x66\x46\x4B\x5B\x0B\x30", 8).c_str(), /*()Ljava/lang/String;*/ StrEnc("P$BMc' #j?<:myTh_*h0", "\x78\x0D\x0E\x27\x02\x51\x41\x0C\x06\x5E\x52\x5D\x42\x2A\x20\x1A\x36\x44\x0F\x0B", 20).c_str());

    auto obj = env->CallStaticObjectMethod(uuidClass, nameUUIDFromBytesMethod, myJByteArray);
    auto str = (jstring) env->CallObjectMethod(obj, toStringMethod);
    return env->GetStringUTFChars(str, 0);
}



int LoginAnnouncementBykaushik(const char* url) {
    JavaVM* java_vm = g_App->activity->vm;
    JNIEnv* java_env = NULL;
    jint jni_return = java_vm->GetEnv((void**)&java_env, JNI_VERSION_1_6);
    if (jni_return == JNI_EDETACHED) {
        if (java_vm->AttachCurrentThread(&java_env, NULL) != JNI_OK) {
            return -1;
        }
    } else if (jni_return == JNI_EVERSION) {
        return -1;
    }
	jclass KAUSHIK = java_env->FindClass("android/media/MediaPlayer");
    if (KAUSHIK == NULL) {
        return -3;
    }

    jmethodID create_method_id = java_env->GetMethodID(KAUSHIK, "<init>", "()V");
    if (create_method_id == NULL) {
        return -4;
    }

    jobject media_player_obj = java_env->NewObject(KAUSHIK, create_method_id);
    if (media_player_obj == NULL) {
        return -5;
    }

    jmethodID set_data_source_method_id = java_env->GetMethodID(KAUSHIK, "setDataSource", "(Ljava/lang/String;)V");
    if (set_data_source_method_id == NULL) {
        return -6;
		}

    jstring url_str = java_env->NewStringUTF(url);
    java_env->CallVoidMethod(media_player_obj, set_data_source_method_id, url_str);

    jmethodID prepare_method_id = java_env->GetMethodID(KAUSHIK, "prepare", "()V");
    if (prepare_method_id == NULL) {
        return -7;
    }
    java_env->CallVoidMethod(media_player_obj, prepare_method_id);

    jmethodID start_method_id = java_env->GetMethodID(KAUSHIK, "start", "()V");
    if (start_method_id == NULL) {
        return -8;
    }
   
    java_env->CallVoidMethod(media_player_obj, start_method_id);

    java_env->DeleteLocalRef(KAUSHIK);
    java_env->DeleteLocalRef(media_player_obj);
    java_env->DeleteLocalRef(url_str);

    if (java_vm->DetachCurrentThread() != JNI_OK) {
        return -1;
    }

    return 0;
}
struct MemoryStruct
{
    char *memory;
    size_t size;
};

static size_t WriteMemoryCallback(void *contents, size_t size, size_t nmemb, void *userp)
{
    size_t realsize = size * nmemb;
    struct MemoryStruct *mem = (struct MemoryStruct *)userp;

    mem->memory = (char *)realloc(mem->memory, mem->size + realsize + 1);
    if (mem->memory == NULL)
    {
        return 0;
    }

    memcpy(&(mem->memory[mem->size]), contents, realsize);
    mem->size += realsize;
    mem->memory[mem->size] = 0;

    return realsize;
}

std::string FetchText(const std::string &url)
{
    CURL *curl = curl_easy_init();
    if (!curl)
    {
        return "Error";
    }

    CURLcode res;
    struct MemoryStruct chunk;
    chunk.memory = (char *)malloc(1);
    chunk.size = 0;

    if (curl)
    {
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_easy_setopt(curl, CURLOPT_USERAGENT, "");

        res = curl_easy_perform(curl);
        if (res != CURLE_OK)
        {

            curl_easy_cleanup(curl);
            free(chunk.memory);
            return "Error";
        }

        std::string text(chunk.memory);
        curl_easy_cleanup(curl);
        free(chunk.memory);
        return text;
    }

    return "Error";
}
std::string Login(const char *user_key) {
    if (!g_App)
        return "Internal Error";

    auto activity = g_App->activity;
    if (!activity)
        return "Internal Error";

    auto vm = activity->vm;
    if (!vm)
        return "Internal Error";

    auto object = activity->clazz;
    if (!object)
        return "Internal Error";

    JNIEnv *env;
    vm->AttachCurrentThread(&env, 0);

    std::string hwid = user_key;
    hwid += GetAndroidID(env, object);
    hwid += GetDeviceModel(env);
    hwid += GetDeviceBrand(env);

    std::string UUID = GetDeviceUniqueIdentifier(env, hwid.c_str());

    vm->DetachCurrentThread();

    std::string errMsg;

    struct MemoryStruct chunk{};
    chunk.memory = (char *) malloc(1);
    chunk.size = 0;

        CURL *curl;
        CURLcode res;
        curl = curl_easy_init();
        if (curl) {
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, /*POST*/ StrEnc(",IL=", "\x7C\x06\x1F\x69", 4).c_str());
                
        //std::string api_key = OBFUSCATE("https://sharkmod.x-key.xyz/public/connect");
		std::string api_key = OBFUSCATE("https://LollipopMod.shop/ansh/connect");
		
		
		curl_easy_setopt(curl, CURLOPT_URL, (api_key.c_str()));

        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
        curl_easy_setopt(curl, CURLOPT_DEFAULT_PROTOCOL, /*https*/ StrEnc("!mLBO", "\x49\x19\x38\x32\x3C", 5).c_str());
        struct curl_slist *headers = NULL;
        headers = curl_slist_append(headers, /*Content-Type: application/x-www-form-urlencoded*/ StrEnc("@;Ls\\(KP4Qrop`b#d3094/r1cf<c<=H)AiiBG6i|Ta66s2[", "\x03\x54\x22\x07\x39\x46\x3F\x7D\x60\x28\x02\x0A\x4A\x40\x03\x53\x14\x5F\x59\x5A\x55\x5B\x1B\x5E\x0D\x49\x44\x4E\x4B\x4A\x3F\x04\x27\x06\x1B\x2F\x6A\x43\x1B\x10\x31\x0F\x55\x59\x17\x57\x3F", 47).c_str());
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

        char data[4096];
        sprintf(data, /*game=PUBG&user_key=%s&serial=%s*/ StrEnc("qu2yXK,YkJyGD@ut0.u~Nb'5(:.:chK", "\x16\x14\x5F\x1C\x65\x1B\x79\x1B\x2C\x6C\x0C\x34\x21\x32\x2A\x1F\x55\x57\x48\x5B\x3D\x44\x54\x50\x5A\x53\x4F\x56\x5E\x4D\x38", 31).c_str(), user_key, UUID.c_str());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);

        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *) &chunk);

        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);

        res = curl_easy_perform(curl);
        if (res == CURLE_OK) {
            try {
                json result = json::parse(chunk.memory);
                if (result[/*status*/ StrEnc("(>_LBm", "\x5B\x4A\x3E\x38\x37\x1E", 6).c_str()] == true) {
                
                    
                    rng = result[/*data*/ StrEnc("fAVA", "\x02\x20\x22\x20", 4).c_str()][/*rng*/ StrEnc("+n,", "\x59\x00\x4B", 3).c_str()].get<time_t>();
                    std::string token = result[/*data*/ StrEnc("fAVA", "\x02\x20\x22\x20", 4).c_str()][/*token*/ StrEnc("{>3Lr", "\x0F\x51\x58\x29\x1C", 5).c_str()].get<std::string>();
             //       time_t rng = result[/*data*/ StrEnc("fAVA", "\x02\x20\x22\x20", 4).c_str()][/*rng*/ StrEnc("+n,", "\x59\x00\x4B", 3).c_str()].get<time_t>();
                       rng = result[/*data*/ StrEnc("fAVA", "\x02\x20\x22\x20", 4).c_str()][/*rng*/ StrEnc("+n,", "\x59\x00\x4B", 3).c_str()].get<time_t>();          
                      
				        if (rng + 30 > time(0)) {
                        std::string auth = /*PUBG*/ StrEnc("Q*) ", "\x01\x7F\x6B\x67", 4).c_str();;
                        auth += "-";
                        auth += user_key;
                        auth += "-";
                        auth += UUID;
                        auth += "-";
						std::string licanse = OBFUSCATE("TeriAmmiMeraFanRokLeKaifeeIfYouCan");
						auth += licanse.c_str();
                     // auth +=  StrEnc("ZD$_K NtaM8Fu=n0fFyO;!Ae<H)*Gy4%", "\x0C\x29\x1C\x13\x20\x17\x1B\x1E\x53\x07\x55\x35\x1F\x7E\x3E\x66\x36\x10\x13\x3D\x77\x40\x76\x1F\x5B\x2E\x51\x19\x32\x03\x0D\x60", 32).c_str();;
                        std::string outputAuth = Tools::CalcMD5(auth);

                        g_Token = token;
                        g_Auth = outputAuth;

                        bValid = g_Token == g_Auth;
						
				/*        EXP = result["data"]["EXP"];
						
                         status = result ["data"]["mod_status"];
                            
                         floating = result ["data"]["credit"];
                         */   
                    }
                } else {
                    errMsg = result[/*reason*/ StrEnc("LW(3(c", "\x3E\x32\x49\x40\x47\x0D", 6).c_str()].get<std::string>();
                }
            } catch (json::exception &e) {
                errMsg = "{";
                errMsg += e.what();
                errMsg += "}\n{";
                errMsg += chunk.memory;
                errMsg += "}";
            }
        } else {
            errMsg = curl_easy_strerror(res);
        }
    }
    curl_easy_cleanup(curl);

    return bValid ? "OK" : errMsg;
}


void FixGameCrash(){
    system(OBFUSCATE("rm -rf /data/data/com.pubg.imobile/files"));
    system(OBFUSCATE("rm -rf /data/data/com.pubg.imobile/files/ano_tmp"));
    system(OBFUSCATE("touch /data/data/com.pubg.imobile/files/ano_tmp"));
    system(OBFUSCATE("chmod 000 /data/data/com.pubg.imobile/files/ano_tmp"));
    system(OBFUSCATE("rm -rf /data/data/com.pubg.imobile/files/obblib"));
    system(OBFUSCATE("touch /data/data/com.pubg.imobile/files/obblib"));
    system(OBFUSCATE("chmod 000 /data/data/com.pubg.imobile/files/obblib"));
    system(OBFUSCATE("rm -rf /data/data/com.pubg.imobile/files/xlog"));
    system(OBFUSCATE("touch /data/data/com.pubg.imobile/files/xlog"));
    system(OBFUSCATE("chmod 000 /data/data/com.pubg.imobile/files/xlog"));
    system(OBFUSCATE("rm -rf /data/data/com.pubg.imobile/app_bugly"));
    system(OBFUSCATE("touch /data/data/com.pubg.imobile/app_bugly"));
    system(OBFUSCATE("chmod 000 /data/data/com.pubg.imobile/app_bugly"));
    system(OBFUSCATE("rm -rf /data/data/com.pubg.imobile/app_crashrecord"));
    system(OBFUSCATE("touch /data/data/com.pubg.imobile/app_crashrecord"));
    system(OBFUSCATE("chmod 000 /data/data/com.pubg.imobile/app_crashrecord"));
    system(OBFUSCATE("rm -rf /data/data/com.pubg.imobile/app_crashSight"));
    system(OBFUSCATE("touch /data/data/com.pubg.imobile/app_crashSight"));
    system(OBFUSCATE("chmod 000 /data/data/com.pubg.imobile/app_crashSight"));
}

int AntiCrackCanart() {
    JavaVM* java_vm = g_App->activity->vm;
    JNIEnv* java_env = NULL;
    jint jni_return = java_vm->GetEnv((void**)&java_env, JNI_VERSION_1_6);
    if (jni_return == JNI_ERR)
        return -1;
    jni_return = java_vm->AttachCurrentThread(&java_env, NULL);
    if (jni_return != JNI_OK)
        return -2;
    jclass native_activity_clazz = java_env->GetObjectClass(g_App->activity->clazz);
    if (native_activity_clazz == NULL /*By kaushik */)
        return -3;
    jmethodID method_id = java_env->GetMethodID(native_activity_clazz, OBFUSCATE("AndroidThunkJava_RestartGame"),
    OBFUSCATE("()V"));
    if (method_id == NULL)
        return -4;
    java_env->CallVoidMethod(g_App->activity->clazz, method_id);
    jni_return = java_vm->DetachCurrentThread();
    if (jni_return != JNI_OK)
        return -5;
    return 0;
}
bool isAntiCrackCanartFolderHere(const std::string& folderPath) {
    return (access(folderPath.c_str(), F_OK) == 0);
}
void Crack() {
std::string folderPath = OBFUSCATE("/storage/emulated/0/Android/data/com.guoshi.httpcanary");
if (isAntiCrackCanartFolderHere(folderPath))/* by - @Mrkaushikhaxor */{
    AntiCrackCanart(); } else {}
}
void Crack2() {
std::string folderPath = OBFUSCATE("/storage/emulated/0/Android/data/com.guoshi.httpcanary.premium");
if (isAntiCrackCanartFolderHere(folderPath))/* by - @Mrkaushikhaxor */{
    AntiCrackCanart(); } else {}
}
void Crack3() {
std::string folderPath = OBFUSCATE("/data/user/0/eu.faircode.netguard");
if (isAntiCrackCanartFolderHere(folderPath))/* by - @Mrkaushikhaxor */{
    AntiCrackCanart(); } else {}
}
void Crack4() {
std::string folderPath = OBFUSCATE("/data/user/0/com.guoshi.httpcanary.premium");
if (isAntiCrackCanartFolderHere(folderPath))/* by - @Mrkaushikhaxor */{
    AntiCrackCanart(); } else {}
}
void Crack5() {
std::string folderPath = OBFUSCATE("/storage/emulated/0/Android/data/com.sniffer");
if (isAntiCrackCanartFolderHere(folderPath))/* by - @Mrkaushikhaxor */{
    AntiCrackCanart(); } else {}
}
void Crack6() {
std::string folderPath = OBFUSCATE("/data/user/0/com.sniffer");
if (isAntiCrackCanartFolderHere(folderPath))/* by - @Mrkaushikhaxor */{
    AntiCrackCanart(); } else {}
}
void Crack7() {
std::string folderPath = OBFUSCATE("/data/user/0/com.guoshi.httpcanary");
if (isAntiCrackCanartFolderHere(folderPath))/* by - @Mrkaushikhaxor */{
    AntiCrackCanart(); } else {}
}
void Crack8() {
std::string folderPath = OBFUSCATE("/data/user/0/org.httpcanary.pro");
if (isAntiCrackCanartFolderHere(folderPath))/* by - @Mrkaushikhaxor */{
    AntiCrackCanart(); } else {}
}
void Crack9() {
std::string folderPath = OBFUSCATE("/storage/emulated/0/Android/data/com.datacapture.pro");
if (isAntiCrackCanartFolderHere(folderPath))/* by - @Mrkaushikhaxor */{
    AntiCrackCanart(); } else {}
}
void Crack10() {
std::string folderPath = OBFUSCATE("/data/user/0/com.datacapture.pro");
if (isAntiCrackCanartFolderHere(folderPath))/* by - @Mrkaushikhaxor */{
    AntiCrackCanart(); } else {}
}
void Crack11() {
std::string folderPath = OBFUSCATE("/storage/emulated/0/Android/data/com.httpcanary.pro");
if (isAntiCrackCanartFolderHere(folderPath))/* by - @Mrkaushikhaxor */{
    AntiCrackCanart(); } else {}
}
void Crack12() {
std::string folderPath = OBFUSCATE("/storage/emulated/0/Android/data/ROKMOD.COM");
if (isAntiCrackCanartFolderHere(folderPath))/* by - @Mrkaushikhaxor */{
    AntiCrackCanart(); } else {}
}
void Crack13() {
std::string folderPath = OBFUSCATE("/storage/emulated/0/Android/data/com.sanmeet");
if (isAntiCrackCanartFolderHere(folderPath))/* by - @Mrkaushikhaxor */{
    AntiCrackCanart(); } else {}
}
void Crack14() {
std::string folderPath = OBFUSCATE("/data/user/0/com.sanmeet");
if (isAntiCrackCanartFolderHere(folderPath))/* by - @Mrkaushikhaxor */{
    AntiCrackCanart(); } else {}
}
///---------------------------MR KAUSHIK HAXOR ---------------------------//

namespace Settings{
static int Tab = 1;
}
EGLBoolean (*orig_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
EGLBoolean _eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    eglQuerySurface(dpy, surface, EGL_WIDTH, &glWidth);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &glHeight);
    if (glWidth <= 0 || glHeight <= 0)
        return orig_eglSwapBuffers(dpy, surface);

    if (!g_App)
        return orig_eglSwapBuffers(dpy, surface);

    screenWidth = ANativeWindow_getWidth(g_App->window);
    screenHeight = ANativeWindow_getHeight(g_App->window);
    density = AConfiguration_getDensity(g_App->config);

  
		
	   if (!initImGui) {
       ImGui::CreateContext();
       ImGuiStyle *style = &ImGui::GetStyle();		
      // InitTexture();
	   style->WindowRounding = 2.0f;
       style->FrameRounding = 0.0f;
       style->FramePadding = ImVec2(8, 4);
	   style->TabRounding = 1.0f;
       style->GrabRounding = 2.0f;
	   style->WindowTitleAlign = ImVec2(0.5, 0.5);
	   
	   
	   //---------------------------------------//
    
            
       style->ScaleAllSizes(std::max(1.0f, density / 250.0f));
       style->ScrollbarSize *= 0.0f;
       style->Colors[ImGuiCol_Text]                  = ImVec4(0.00f, 0.00f, 0.00f, 1.00f);
       style->Colors[ImGuiCol_TextDisabled]          = ImVec4(0.60f, 0.60f, 0.60f, 1.00f);
       style->Colors[ImGuiCol_WindowBg]              = ImColor(170,173,180,255);
       style->Colors[ImGuiCol_PopupBg]               = ImVec4(1.00f, 1.00f, 1.00f, 0.94f);
       style->Colors[ImGuiCol_Border]                = ImVec4(0.00f, 0.00f, 0.00f, 0.39f);
       style->Colors[ImGuiCol_BorderShadow]          = ImVec4(1.00f, 1.00f, 1.00f, 0.10f);
       style->Colors[ImGuiCol_FrameBg]               = ImVec4(1.00f, 1.00f, 1.00f, 0.94f);
       style->Colors[ImGuiCol_FrameBgHovered]        = ImVec4(0.26f, 0.59f, 0.98f, 0.40f);
       style->Colors[ImGuiCol_FrameBgActive]         = ImVec4(0.26f, 0.59f, 0.98f, 0.67f);
       style->Colors[ImGuiCol_TitleBg]               = ImVec4(0.96f, 0.96f, 0.96f, 0.96f);
       style->Colors[ImGuiCol_TitleBgCollapsed]      = ImVec4(1.00f, 1.00f, 1.00f, 0.51f);
       style->Colors[ImGuiCol_TitleBgActive]         = ImVec4(0.96f, 0.96f, 0.96f, 0.96f);
       style->Colors[ImGuiCol_MenuBarBg]             = ImVec4(0.86f, 0.86f, 0.86f, 1.00f);
       style->Colors[ImGuiCol_ScrollbarBg]           = ImVec4(0.98f, 0.98f, 0.98f, 0.53f);
       style->Colors[ImGuiCol_ScrollbarGrab]         = ImVec4(0.69f, 0.69f, 0.69f, 1.00f);
       style->Colors[ImGuiCol_ScrollbarGrabHovered]  = ImVec4(0.59f, 0.59f, 0.59f, 1.00f);
       style->Colors[ImGuiCol_ScrollbarGrabActive]   = ImVec4(0.49f, 0.49f, 0.49f, 1.00f);
       style->Colors[ImGuiCol_CheckMark]             = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
       style->Colors[ImGuiCol_SliderGrab]            = ImVec4(0.24f, 0.52f, 0.88f, 1.00f);
       style->Colors[ImGuiCol_SliderGrabActive]      = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
       style->Colors[ImGuiCol_Button]                = ImColor(0,0,0,150);//ImVec4(0.26f, 0.59f, 0.98f, 0.40f);
       style->Colors[ImGuiCol_ButtonHovered]         = ImColor(0,0,0,150);//ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
       style->Colors[ImGuiCol_ButtonActive]          = ImColor(0,0,0,150);//ImVec4(0.06f, 0.53f, 0.98f, 1.00f);
       style->Colors[ImGuiCol_Header]                = ImVec4(0.26f, 0.59f, 0.98f, 0.31f);
       style->Colors[ImGuiCol_HeaderHovered]         = ImVec4(0.26f, 0.59f, 0.98f, 0.80f);
       style->Colors[ImGuiCol_HeaderActive]          = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
       style->Colors[ImGuiCol_ResizeGrip]            = ImVec4(1.00f, 1.00f, 1.00f, 0.50f);
       style->Colors[ImGuiCol_ResizeGripHovered]     = ImVec4(0.26f, 0.59f, 0.98f, 0.67f);
       style->Colors[ImGuiCol_ResizeGripActive]      = ImVec4(0.26f, 0.59f, 0.98f, 0.95f);
       style->Colors[ImGuiCol_TextSelectedBg]        = ImVec4(0.26f, 0.59f, 0.98f, 0.35f);

    
	
	    ImGui_ImplAndroid_Init();
        ImGui_ImplOpenGL3_Init(OBFUSCATE("#version 300 es"));  
	
	   
	        
        
	   
        ImGuiIO &io = ImGui::GetIO();
		io.AnimationSpeed = 1;
        io.ConfigWindowsMoveFromTitleBarOnly = true;
        io.IniFilename = NULL;

        static const ImWchar ranges[] =
{
    0x20, 0xFF,
    0x2010, 0x205E,
    0x0600, 0x06FF,
    0xFE00, 0xFEFF,   
    0,
};  


         
      
            static const ImWchar icons_ranges[] = { 0xf000, 0xf3ff, 0 };
            ImFontConfig icons_config;
			ImFontAtlas *fontAtlas = ImGui::GetIO().Fonts;
            ImFontConfig CustomFont;
            CustomFont.FontDataOwnedByAtlas = false;

            icons_config.MergeMode = true;
            icons_config.PixelSnapH = true;
            icons_config.OversampleH = 2.5;
            icons_config.OversampleV = 2.5;

			
			//io.Fonts->AddFontFromFileTTF("/storage/emulated/0/Download/agency_bold.ttf", 25.f, NULL, io.Fonts->GetGlyphRangesChineseFull());
			
            io.Fonts->AddFontFromMemoryTTF(const_cast<std::uint8_t*>(Custom), sizeof(Custom), 25.f, &CustomFont);
            io.Fonts->AddFontFromMemoryCompressedTTF(font_awesome_data, font_awesome_size, 30.0f, &icons_config, icons_ranges);
			Injector = io.Fonts->AddFontFromMemoryTTF((void *)Injector_data, Injector_size, 20.5f, NULL, &ranges[0]);
			Injector2 = io.Fonts->AddFontFromMemoryTTF((void *)Injector2_data, Injector2_size, 25.f, NULL, &ranges[0]);
            Social = io.Fonts->AddFontFromMemoryTTF((void *)Social_data, Social_size, 30.0f, NULL, io.Fonts->GetGlyphRangesDefault());
		    

			
			ImFontConfig cfg;
            cfg.SizePixels = ((float) density / 20.0f);
            io.Fonts->AddFontDefault(&cfg);

            memset(&Config, 0, sizeof(sConfig));

			
	    Config.Recc = 1.435f;
        Config.AimBot.Cross = 500.0f;
		AimSmooth = 1.0f;
   
              
               for (auto &i : items_data) {
            for (auto &item : i["Items"]) {
                int r, g, b;
                sscanf(item["itemTextColor"].get<std::string>().c_str(), "#%02X%02X%02X", &r, &g, &b);
                ItemColors[item["itemId"].get<int>()] = CREATE_COLOR(255, 255, 255, 255);
            }
        } 
		  
        initImGui = true;
    }


    ImGuiIO &io = ImGui::GetIO();
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame(glWidth, glHeight);
    ImGui::NewFrame();
	Colors::Text = ImColor(100,103,108,255);
    Colors::TextActive = ImColor(41,44,49,255);
    Colors::TextActiveNew = ImColor(255,255,255);
    Colors::TextNew = ImColor(255,255,255);
    Colors::FrameHovered = ImColor(255,255,255,255);
    Colors::FrameOpened = ImColor(255,255,255,255);

/*
 *  @date   : 2020/02/04
 *  @Creator : @Mrkaushikhaxor
 *  Https://t.me/KaushikCracking
 */

  #include "Kaushik/RGB.h"
	
 DrawESP(ImGui::GetBackgroundDrawList());
	   
	   
	   
	   
	
