/*
 *  @date   : 2020/02/04
 *  @Creator : @Mrkaushikhaxor
 *  Https://t.me/KaushikCracking
 */

#ifndef KAUSHIK_LOGIN_H
#define KAUSHIK_LOGIN_H


class Login {

};


#endif //

/*
 *  @date   : 2020/02/04
 *  @Creator : @Mrkaushikhaxor
 *  Https://t.me/KaushikCracking
 */
