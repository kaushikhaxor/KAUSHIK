#define GEngine_Offset 0xc4d2388 //UEngine
#define GEngine_Offset 0xc4b2da0 //UlocalPlayer
#define GNames_Offset 0x6d2cc1c
#define GUObject_Offset 0xc27e7f0
#define GNativeAndroidApp_Offset 0xbde0f88
#define CanvasMap_Offsets 0xc503a40
#define ProcessEvent_Offset 0x6f8c070
#define GetActorArray 0x8955498
#define Actors_Offset 0xA0
#define eglSwapBuffers 0xA7CD730
