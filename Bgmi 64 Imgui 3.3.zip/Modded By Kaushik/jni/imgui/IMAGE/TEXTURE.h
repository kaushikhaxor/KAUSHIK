#include "ImGui/stb_image.h"
#define STB_IMAGE_IMPLEMENTATION
//================================================================
#include "ImGui/IMAGE/MENU/Logo.h"
#include "ImGui/IMAGE/MENU/ROLLING.h"
//================================================================
#include "ImGui/IMAGE/ESP/Aim_off.h"
#include "ImGui/IMAGE/ESP/Aim_on.h"
#include "ImGui/IMAGE/ESP/Bot_off.h"
#include "ImGui/IMAGE/ESP/Bot_on.h"
#include "ImGui/IMAGE/ESP/Bt_off.h"
#include "ImGui/IMAGE/ESP/Bt_on.h"
#include "ImGui/IMAGE/ESP/Enemy_off.h"
#include "ImGui/IMAGE/ESP/Enemy_on.h"
#include "ImGui/IMAGE/ESP/AirDrop.h"
#include "ImGui/IMAGE/ESP/AirPlane.h"
#include "ImGui/IMAGE/ESP/LootBox.h"
#include "ImGui/IMAGE/ESP/WarnGrenade.h"
#include "ImGui/IMAGE/ESP/WarnMolly.h"
#include "ImGui/IMAGE/ESP/WarnSmoke.h"
#include "ImGui/IMAGE/ESP/WarnSton.h"
//================================================================
#include "ImGui/IMAGE/VEHICLE/VEHICLE.h"
#include "ImGui/IMAGE/VEHICLE/UTV.h"
#include "ImGui/IMAGE/VEHICLE/UAZ.h"
#include "ImGui/IMAGE/VEHICLE/TUKTUK.h"
#include "ImGui/IMAGE/VEHICLE/SNOWBIKE.h"
#include "ImGui/IMAGE/VEHICLE/SNOW_MOBILE.h"
#include "ImGui/IMAGE/VEHICLE/SCOOTER.h"
#include "ImGui/IMAGE/VEHICLE/RONY.h"
#include "ImGui/IMAGE/VEHICLE/PICKUP.h"
#include "ImGui/IMAGE/VEHICLE/MOTOCYCLE_CART.h"
#include "ImGui/IMAGE/VEHICLE/MOTOCYCLE.h"
#include "ImGui/IMAGE/VEHICLE/MIRADO_OPEN.h"
#include "ImGui/IMAGE/VEHICLE/MIRADO.h"
#include "ImGui/IMAGE/VEHICLE/MINI_BUS.h"
#include "ImGui/IMAGE/VEHICLE/LADA_NIVA.h"
#include "ImGui/IMAGE/VEHICLE/DACIA.h"
#include "ImGui/IMAGE/VEHICLE/BUGGY.h"
#include "ImGui/IMAGE/VEHICLE/BRDM.h"
#include "ImGui/IMAGE/VEHICLE/BIG_BOAT.h"
#include "ImGui/IMAGE/VEHICLE/AQUARAIL.h"
//================================================================
#include "ImGui/IMAGE/WEAPON/AKM.h"
#include "ImGui/IMAGE/WEAPON/AUG.h"
#include "ImGui/IMAGE/WEAPON/AWM.h"
#include "ImGui/IMAGE/WEAPON/CROSSBOW.h"
#include "ImGui/IMAGE/WEAPON/DBS.h"
#include "ImGui/IMAGE/WEAPON/DP28.h"
#include "ImGui/IMAGE/WEAPON/Desert_Eagle.h"
#include "ImGui/IMAGE/WEAPON/FIST.h"
#include "ImGui/IMAGE/WEAPON/Frag_Grenade.h"
#include "ImGui/IMAGE/WEAPON/G36C.h"
#include "ImGui/IMAGE/WEAPON/GROZA.h"
#include "ImGui/IMAGE/WEAPON/KAR98K.h"
#include "ImGui/IMAGE/WEAPON/M16A4.h"
#include "ImGui/IMAGE/WEAPON/M24.h"
#include "ImGui/IMAGE/WEAPON/M249.h"
#include "ImGui/IMAGE/WEAPON/M416.h"
#include "ImGui/IMAGE/WEAPON/M762.h"
#include "ImGui/IMAGE/WEAPON/MG3.h"
#include "ImGui/IMAGE/WEAPON/MINI14.h"
#include "ImGui/IMAGE/WEAPON/MK12.h"
#include "ImGui/IMAGE/WEAPON/MK14.h"
#include "ImGui/IMAGE/WEAPON/MK47.h"
#include "ImGui/IMAGE/WEAPON/MP5K.h"
#include "ImGui/IMAGE/WEAPON/Machete.h"
#include "ImGui/IMAGE/WEAPON/P18C.h"
#include "ImGui/IMAGE/WEAPON/P1911.h"
#include "ImGui/IMAGE/WEAPON/P92.h"
#include "ImGui/IMAGE/WEAPON/PAN.h"
#include "ImGui/IMAGE/WEAPON/PP19.h"
#include "ImGui/IMAGE/WEAPON/QBZ.h"
#include "ImGui/IMAGE/WEAPON/R1895.h"
#include "ImGui/IMAGE/WEAPON/R45.h"
#include "ImGui/IMAGE/WEAPON/S12K.h"
#include "ImGui/IMAGE/WEAPON/S1897.h"
#include "ImGui/IMAGE/WEAPON/S686.h"
#include "ImGui/IMAGE/WEAPON/SCARL.h"
#include "ImGui/IMAGE/WEAPON/SCORPION.h"
#include "ImGui/IMAGE/WEAPON/SKS.h"
#include "ImGui/IMAGE/WEAPON/SLR.h"
#include "ImGui/IMAGE/WEAPON/Sawed_off.h"
#include "ImGui/IMAGE/WEAPON/Smoke_Grenade.h"
#include "ImGui/IMAGE/WEAPON/TOMMY.h"
#include "ImGui/IMAGE/WEAPON/UMP45.h"
#include "ImGui/IMAGE/WEAPON/UZI.h"
#include "ImGui/IMAGE/WEAPON/VECTOR.h"
#include "ImGui/IMAGE/WEAPON/VSS.h"
#include "ImGui/IMAGE/WEAPON/WIN94.h"
//================================================================


//================================================================
    struct TextureInfo { ImTextureID textureId; int x; int y; int w; int h; };
    void DrawImage(int x, int y, int w, int h, ImTextureID Texture) {
    ImGui::GetForegroundDrawList()->AddImage(Texture, ImVec2(x, y), ImVec2(x + w, y + h));}
    
static struct Hand {
TextureInfo AKM;
TextureInfo AUG;
TextureInfo AWM;
TextureInfo CROSSBOW;
TextureInfo DBS;
TextureInfo DP28;
TextureInfo Desert_Eagle;
TextureInfo FIST;
TextureInfo Frag_Grenade;
TextureInfo G36C;
TextureInfo GROZA;
TextureInfo KAR98K;
TextureInfo M16A4;
TextureInfo M24;
TextureInfo M249;
TextureInfo M416;
TextureInfo M762;
TextureInfo MG3;
TextureInfo MINI14;
TextureInfo MK12;
TextureInfo MK14;
TextureInfo MK47;
TextureInfo MP5K;
TextureInfo Machete;
TextureInfo P18C;
TextureInfo P1911;
TextureInfo P92;
TextureInfo PAN;
TextureInfo PP19;
TextureInfo QBZ;
TextureInfo R1895;
TextureInfo R45;
TextureInfo S12K;
TextureInfo S1897;
TextureInfo S686;
TextureInfo SCARL;
TextureInfo SCORPION;
TextureInfo SKS;
TextureInfo SLR;
TextureInfo Sawed_off;
TextureInfo Smoke_Grenade;
TextureInfo TOMMY;
TextureInfo UMP45;
TextureInfo UZI;
TextureInfo VECTOR;
TextureInfo VSS;
TextureInfo WIN94;
} hand;




    
    
//===========| 𝗜𝗠𝗔𝗚𝗘 𝗙𝗥𝗢𝗠 𝗦𝗧𝗢𝗥𝗔𝗚𝗘 
    
    static TextureInfo textureInfo;
    TextureInfo createTexture(char *ImagePath) {
    int w, h, n;
    stbi_uc *data = stbi_load(ImagePath, &w, &h, &n, 0);
    GLuint texture;
    glGenTextures(1, &texture);
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    if (n == 3) {
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, w, h, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
    } else {
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
    }stbi_image_free(data);
    textureInfo.textureId = reinterpret_cast<ImTextureID>((GLuint *) texture);
    textureInfo.w = w;
    textureInfo.h = h;
    return textureInfo;}

//===========| 𝗜𝗠𝗔𝗚𝗘 𝗙𝗥𝗢𝗠 𝗕𝗬𝗧𝗘 𝗔𝗥𝗥𝗔𝗬
    
    TextureInfo CreateTexture(const unsigned char* buf, int len) {
    TextureInfo image;
    unsigned char* image_data = stbi_load_from_memory(buf, len, &image.w, &image.h, NULL, 0);
    if (image_data == NULL) {perror("File does not exist");}
    GLuint image_texture;
    glGenTextures(1, &image_texture);
    glBindTexture(GL_TEXTURE_2D, image_texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    #if defined(GL_UNPACK_ROW_LENGTH) && !defined(__EMSCRIPTEN__)
    glPixelStorei(GL_UNPACK_ROW_LENGTH, 0);
    #endif
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, image.w, image.h, 0, GL_RGBA, GL_UNSIGNED_BYTE, image_data);
    stbi_image_free(image_data);
    image.textureId = (ImTextureID)image_texture;
    return image;}
    
//==============| 𝗧𝗘𝗫𝗧𝗨𝗥𝗘 𝗗𝗘𝗙𝗜𝗡𝗘
    
TextureInfo Logo;
TextureInfo ROLLING;
//=====================================
TextureInfo Aim_off;
TextureInfo Aim_on;
TextureInfo Bt_off;
TextureInfo Bt_on;
TextureInfo Bot_off;
TextureInfo Bot_on;
TextureInfo Enemy_off;
TextureInfo Enemy_on;
TextureInfo AirPlane;
TextureInfo AirDrop;
TextureInfo LootBox;
TextureInfo WarnGrenade;
TextureInfo WarnMolly;
TextureInfo WarnSton;
TextureInfo WarnSmoke;
//=====================================
TextureInfo VEHICLE;
TextureInfo UTV;
TextureInfo UAZ;
TextureInfo TUKTUK;
TextureInfo SNOWBIKE;
TextureInfo SNOW_MOBILE;
TextureInfo SCOOTER;
TextureInfo RONY;
TextureInfo PICKUP;
TextureInfo MOTOCYCLE_CART;
TextureInfo MOTOCYCLE;
TextureInfo MIRADO_OPEN;
TextureInfo MIRADO;
TextureInfo LADA_NIVA;
TextureInfo DACIA;
TextureInfo BUGGY;
TextureInfo BRDM;
TextureInfo AQUARAIL;
TextureInfo BIG_BOAT;
TextureInfo MINI_BUS;
//=====================================


//==============| 𝗜𝗠𝗔𝗚𝗘 𝗗𝗔𝗧𝗔 / 𝗜𝗠𝗔𝗚𝗘 𝗣𝗔𝗧𝗛
    
void InitTexture() {
Logo = CreateTexture(Logo_data, sizeof(Logo_data));
ROLLING = CreateTexture(ROLLING_data, sizeof(ROLLING_data));
//=============================================================================
Aim_off = CreateTexture(Aim_off_data, sizeof(Aim_off_data));
Aim_on = CreateTexture(Aim_on_data, sizeof(Aim_on_data));
Bt_off = CreateTexture(Bt_off_data, sizeof(Bt_off_data));
Bt_on = CreateTexture(Bt_on_data, sizeof(Bt_on_data));
Bot_off = CreateTexture(Bot_off_data, sizeof(Bot_off_data));
Bot_on = CreateTexture(Bot_on_data, sizeof(Bot_on_data));
Enemy_off = CreateTexture(Enemy_off_data, sizeof(Enemy_off_data));
Enemy_on = CreateTexture(Enemy_on_data, sizeof(Enemy_on_data));
AirDrop = CreateTexture(AirDrop_data, sizeof(AirDrop_data));
AirPlane = CreateTexture(AirPlane_data, sizeof(AirPlane_data));
LootBox = CreateTexture(LootBox_data, sizeof(LootBox_data));
WarnGrenade = CreateTexture(WarnGrenade_data, sizeof(WarnGrenade_data));
WarnMolly = CreateTexture(WarnMolly_data, sizeof(WarnMolly_data));
WarnSmoke = CreateTexture(WarnSmoke_data, sizeof(WarnSmoke_data));
WarnSton = CreateTexture(WarnSton_data, sizeof(WarnSton_data));
//=============================================================================
VEHICLE = CreateTexture(VEHICLE_data, sizeof(VEHICLE_data));
UTV = CreateTexture(UTV_DATA, sizeof(UTV_DATA));
UAZ = CreateTexture(UAZ_DATA, sizeof(UAZ_DATA));
TUKTUK = CreateTexture(TUKTUK_DATA, sizeof(TUKTUK_DATA));
SNOWBIKE = CreateTexture(SNOWBIKE_DATA, sizeof(SNOWBIKE_DATA));
SNOW_MOBILE = CreateTexture(SNOW_MOBILE_DATA, sizeof(SNOW_MOBILE_DATA));
SCOOTER = CreateTexture(SCOOTER_DATA, sizeof(SCOOTER_DATA));
RONY = CreateTexture(RONY_DATA, sizeof(RONY_DATA));
PICKUP = CreateTexture(PICKUP_DATA, sizeof(PICKUP_DATA));
MOTOCYCLE_CART = CreateTexture(MOTOCYCLE_CART_DATA, sizeof(MOTOCYCLE_CART_DATA));
MOTOCYCLE = CreateTexture(MOTOCYCLE_DATA, sizeof(MOTOCYCLE_DATA));
MIRADO_OPEN = CreateTexture(MIRADO_OPEN_DATA, sizeof(MIRADO_OPEN_DATA));
MIRADO = CreateTexture(MIRADO_DATA, sizeof(MIRADO_DATA));
MINI_BUS = CreateTexture(MINI_BUS_DATA, sizeof(MINI_BUS_DATA));
LADA_NIVA = CreateTexture(LADA_NIVA_DATA, sizeof(LADA_NIVA_DATA));
DACIA = CreateTexture(DACIA_DATA, sizeof(DACIA_DATA));
BUGGY = CreateTexture(BUGGY_DATA, sizeof(BUGGY_DATA));
BRDM = CreateTexture(BRDM_DATA, sizeof(BRDM_DATA));
AQUARAIL = CreateTexture(AQUARAIL_DATA, sizeof(AQUARAIL_DATA));
BIG_BOAT = CreateTexture(BIG_BOAT_DATA, sizeof(BIG_BOAT_DATA));
//=============================================================================
hand.AKM = CreateTexture(AKM_data, sizeof(AKM_data));
hand.AUG = CreateTexture(AUG_data, sizeof(AUG_data));
hand.AWM = CreateTexture(AWM_data, sizeof(AWM_data));
hand.CROSSBOW = CreateTexture(CROSSBOW_data, sizeof(CROSSBOW_data));
hand.DBS = CreateTexture(DBS_data, sizeof(DBS_data));
hand.DP28 = CreateTexture(DP28_data, sizeof(DP28_data));
hand.Desert_Eagle = CreateTexture(Desert_Eagle_data, sizeof(Desert_Eagle_data));
hand.FIST = CreateTexture(FIST_data, sizeof(FIST_data));
hand.Frag_Grenade = CreateTexture(Frag_Grenade_data, sizeof(Frag_Grenade_data));
hand.G36C = CreateTexture(G36C_data, sizeof(G36C_data));
hand.GROZA = CreateTexture(GROZA_data, sizeof(GROZA_data));
hand.KAR98K = CreateTexture(KAR98K_data, sizeof(KAR98K_data));
hand.M16A4 = CreateTexture(M16A4_data, sizeof(M16A4_data));
hand.M24 = CreateTexture(M24_data, sizeof(M24_data));
hand.M249 = CreateTexture(M249_data, sizeof(M249_data));
hand.M416 = CreateTexture(M416_data, sizeof(M416_data));
hand.M762 = CreateTexture(M762_data, sizeof(M762_data));
hand.MG3 = CreateTexture(MG3_data, sizeof(MG3_data));
hand.MINI14 = CreateTexture(MINI14_data, sizeof(MINI14_data));
hand.MK12 = CreateTexture(MK12_data, sizeof(MK12_data));
hand.MK14 = CreateTexture(MK14_data, sizeof(MK14_data));
hand.MK47 = CreateTexture(MK47_data, sizeof(MK47_data));
hand.MP5K = CreateTexture(MP5K_data, sizeof(MP5K_data));
hand.Machete = CreateTexture(Machete_data, sizeof(Machete_data));
hand.P18C = CreateTexture(P18C_data, sizeof(P18C_data));
hand.P1911 = CreateTexture(P1911_data, sizeof(P1911_data));
hand.P92 = CreateTexture(P92_data, sizeof(P92_data));
hand.PAN = CreateTexture(PAN_data, sizeof(PAN_data));
hand.PP19 = CreateTexture(PP19_data, sizeof(PP19_data));
hand.QBZ = CreateTexture(QBZ_data, sizeof(QBZ_data));
hand.R1895 = CreateTexture(R1895_data, sizeof(R1895_data));
hand.R45 = CreateTexture(R45_data, sizeof(R45_data));
hand.S12K = CreateTexture(S12K_data, sizeof(S12K_data));
hand.S1897 = CreateTexture(S1897_data, sizeof(S1897_data));
hand.S686 = CreateTexture(S686_data, sizeof(S686_data));
hand.SCARL = CreateTexture(SCARL_data, sizeof(SCARL_data));
hand.SCORPION = CreateTexture(SCORPION_data, sizeof(SCORPION_data));
hand.SKS = CreateTexture(SKS_data, sizeof(SKS_data));
hand.SLR = CreateTexture(SLR_data, sizeof(SLR_data));
hand.Sawed_off = CreateTexture(Sawed_off_data, sizeof(Sawed_off_data));
hand.Smoke_Grenade = CreateTexture(Smoke_Grenade_data, sizeof(Smoke_Grenade_data));
hand.TOMMY = CreateTexture(TOMMY_data, sizeof(TOMMY_data));
hand.UMP45 = CreateTexture(UMP45_data, sizeof(UMP45_data));
hand.UZI = CreateTexture(UZI_data, sizeof(UZI_data));
hand.VECTOR = CreateTexture(VECTOR_data, sizeof(VECTOR_data));
hand.VSS = CreateTexture(VSS_data, sizeof(VSS_data));
hand.WIN94 = CreateTexture(WIN94_data, sizeof(WIN94_data));
//=============================================================================

}
