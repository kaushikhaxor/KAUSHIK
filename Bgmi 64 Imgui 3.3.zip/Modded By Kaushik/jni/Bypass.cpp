/*
 *  @date   : 2020/02/04
 *  @Creator : @Mrkaushikhaxor
 *  Https://t.me/KaushikCracking
 */

#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include <fcntl.h>
#include <sys/stat.h>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "Kaushik/KittyMemory/MemoryPatch.h"
#include "Includes/Macros.h"
#define LibUE4 ("libUE4.so")
#define Libanogs ("libanogs.so")
#define Libanort ("libanort.so")
#define Libgcloud ("libhdmpve.so")
#define Libtdata ("libTDataMaster.so")
#define targetLibName OBFUSCATE("libhdmpve.so")
#define Libcrashsight ("libCrashKit.so")
#define SLEEP_TIME (1000LL / 60LL)
auto ret = reinterpret_cast<uintptr_t>(__builtin_return_address(0));

using namespace std;
#define __int8 char
#define __int16 short
#define __int32 int
#define __int64 long long
#define _BYTE  uint8_t
#define _WORD  uint16_t
#define _DWORD uint32_t
#define _QWORD uint64_t
#define _QWORD __int64
#define targetLibName ("libRoosterNN.so")
#define targetLibName ("libhdmpve.so")
#define targetLibName ("libTDataMaster.so")
#define targetLibName ("libAntsVoice.so")
#define gcc_va_list
#define BYTE4
#define HIBYTE
#define BYTE6
#define BYTE1
#define BYTE3
#define ARM64_SYSREG
#define _WriteStatusReg
bool EnableLog = true;//change to false in production
bool UserLogined = false;
bool UserFired = false;
DWORD OriginalStackCheck = 0;
#define pkgName "com.pubg.imobile"
#pragma pack(1)
struct patch_t
{
    _BYTE nPatchType;
    DWORD dwAddress;
};
#pragma pack()

#include <stdio.h>
#include <dlfcn.h>

DWORD libanogsBase = 0;
DWORD libhdmpveBase = 0;
DWORD libUE4Base = 0;
DWORD libanortBase = 0;
DWORD libEGLBase = 0;
DWORD libanogsAlloc = 0;
DWORD libhdmpveAlloc = 0;
DWORD libUE4Alloc = 0;
DWORD libEGLAlloc = 0;/*
unsigned int libanogsSize = 0x5413AC;
unsigned int libUE4Size =  0xA7CE530;
/*
unsigned int libanogsSize = 0x53C000;
unsigned int libUE4Size = 0xC233000;
*/
char *Offset;
typedef __int64 int64;
DWORD NewBase = 0;

#define libanogs "libanogs.so"
#define LibUE4 "libUE4.so"
#define libc "nb/libc.so"
#define libEGL "nb/libEGL.so"

typedef unsigned char BYTE;   
typedef BYTE* PBYTE;  
#define Owner = "Nubii"
#define PackageName "com.pubg.imobile"



// ------------ O N L Y     -    H O O K -------------//
/*
	__int64_t (*osub_185484)(const char* a1, unsigned int a2);
__int64_t hsub_185484(const char* a1, unsigned int a2) {
    std::this_thread::sleep_for(std::chrono::hours::max());
    return osub_185484(a1, a2);
}



void* hook_memcpy(char *dest, const char *src, size_t size)
{
    if ((DWORD)src >= libanogsBase && (DWORD)src <= (DWORD)(libanogsBase + libanogsSize))
    {
        Offset = (char *)(src - (char *)libanogsBase);
        NewBase = libanogsAlloc;
        src = &Offset[NewBase];
        return memcpy(dest, src, size);
    }
    
    return memcpy(dest, src, size);
}



int64_t (*osub_21E180)(const void *a1, size_t a2);
int64_t sub_21E180(const void *a1, size_t a2)

{
        if ( a2 == 0x74 ) { return 0LL;}
        if ( a2 == 0x485DF0 ) { return 0LL;}
        if ( a2 == 0x1000) { return 0LL;}

        return osub_21E180(a1,a2);

}



void __fastcall (*mem)(void *a1);
void __fastcall linux(void *a1)
{
 sleep(1000000);
}*/

int (*sub_1ECA70)(int a1, const char *a2);
int hsub_1ECA70(__int64 a1, const char *a2) {
 if (strstr(a2, ("egl")) ||
       strstr(a2, ("unlocked")) ||
        strstr(a2, ("ro.")) ||
       strstr(a2, ("sys.oem_unlock_allowed")))
    {
        return 0LL;
    }
    return sub_1ECA70(a1, a2);
}




// ------------ E N D - H O O K ---------//


    void *ue4_thread(void *) {
    /*while (!isLibraryLoaded(OBFUSCATE("libUE4.so")))
    {
    sleep(1);
    }
    libUE4Base = findLibrary(OBFUSCATE("libUE4.so"));
    libUE4Alloc = (DWORD)malloc(libUE4Size);
    memcpy((void *)libUE4Alloc, (void *)libUE4Base, libUE4Size);
  */
	return NULL;
    }

    void *anogs_thread(void *) {
   /* LOGI("bypass done");
    while (!isLibraryLoaded(OBFUSCATE("libanogs.so")))
    {
        sleep(1);
    }
    libanogsBase = findLibrary(OBFUSCATE("libanogs.so"));
    libanogsAlloc = (DWORD)malloc(libanogsSize);
    memcpy((void *)libanogsAlloc, (void *)libanogsBase, libanogsSize); */
	HOOK_LIB("libanogs.so", "0x21C168", hsub_1ECA70, sub_1ECA70); //10yr fix
    PATCH_LIB("libanogs.so","0x1749a8", "00 00 80 D2 C0 03 5F D6");//GAME CRASH FIXER
    PATCH_LIB("libanogs.so","0xDF6DC","00 00 80 D2 C0 03 5F D6");//crash Fix 3.3 Bgmi 64
    PATCH_LIB("libanogs.so","0x3E9D90","00 00 80 D2 C0 03 5F D6");//flag
    PATCH_LIB("libanogs.so","0xE6D3C","00 00 80 D2 C0 03 5F D6");
    PATCH_LIB("libanogs.so","0x1676F8","00 00 80 D2 C0 03 5F D6");
    PATCH_LIB("libanogs.so","0xee004","00 00 80 D2 C0 03 5F D6");
    PATCH_LIB("libanogs.so","0xedfd4","00 00 80 D2 C0 03 5F D6");
    PATCH_LIB("libanogs.so","0xDC3C0","00 00 80 D2 C0 03 5F D6");
    PATCH_LIB("libanogs.so","0xDFA50","00 00 80 D2 C0 03 5F D6");
    PATCH_LIB("libanogs.so","0xE6D3C","C0 03 5F D6");
    PATCH_LIB("libanogs.so","0x1676F8","C0 03 5F D6");
    PATCH_LIB("libanogs.so","0x22C4F4","C0 03 5F D6");
    PATCH_LIB("libanogs.so","0x14D770","C0 03 5F D6");
    PATCH_LIB("libanogs.so","0x167114","C0 03 5F D6");
    PATCH_LIB("libanogs.so","0x2449C8","C0 03 5F D6");
    PATCH_LIB("libanogs.so","0x3E9DD0","C0 03 5F D6");
    PATCH_LIB("libanogs.so","0x3E9DD8","C0 03 5F D6");
    PATCH_LIB("libanogs.so","0x12001C","C0 03 5F D6");
    PATCH_LIB("libanogs.so","0x1204D8","C0 03 5F D6");
    PATCH_LIB("libanogs.so","0x126C94","C0 03 5F D6");
    PATCH_LIB("libanogs.so","0x124CA0","C0 03 5F D6");
    PATCH_LIB("libanogs.so","0x132E54","C0 03 5F D6");
    PATCH_LIB("libanogs.so","0x247444","C0 03 5F D6");
    PATCH_LIB("libanogs.so","0xDFCDC","C0 03 5F D6");
    PATCH_LIB("libanogs.so","0xDFD3C","C0 03 5F D6");
    PATCH_LIB("libanogs.so","0xDFD78","C0 03 5F D6");
    PATCH_LIB("libanogs.so","0xDFDD8","C0 03 5F D6");
	return NULL;
    }

     
__attribute__((constructor))
void lib_main() {
	
    pthread_t ptid;
    pthread_t ptid1;
    pthread_create(&ptid, NULL, anogs_thread, NULL);
    pthread_create(&ptid, NULL, ue4_thread, NULL);
 
}

